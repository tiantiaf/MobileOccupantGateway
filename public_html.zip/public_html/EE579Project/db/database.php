<?php
	$host = "localhost";
	$user = 'buildjn6_frank';
	$pwd = 'ee579';
	$db = 'buildjn6_EE579Project';
	$port = 3306;
?>