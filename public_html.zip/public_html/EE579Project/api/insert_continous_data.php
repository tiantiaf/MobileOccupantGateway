<?php
$$_GET[];
$_GET[];
$_GET[];
$_GET[];
$_GET[];
?>