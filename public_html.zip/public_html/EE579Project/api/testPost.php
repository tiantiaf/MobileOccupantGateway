<?php
	$test = $_POST['test'];
	echo "$test";
?>