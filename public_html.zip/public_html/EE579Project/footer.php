<div id="footer">
	<div class="container">
		<p>
			EE579Final Project By: Tiantian Feng, Zhongxiang Ye &amp; Xuejiao Wang
		</p>
	</div>
</div>