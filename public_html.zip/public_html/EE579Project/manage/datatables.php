<?
include('../db/dbhelper.php');

$data = getDatatable($_GET['tablename']);

?>