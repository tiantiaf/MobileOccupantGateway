<?php
	$array = array(
  		'username' => 'Dayday',
  		'password' => '123456',
		'user_id'  => 1
	);
	echo json_encode($array);
?>