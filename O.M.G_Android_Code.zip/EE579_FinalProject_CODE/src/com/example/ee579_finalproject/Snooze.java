package com.example.ee579_finalproject;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.Vibrator;
import android.os.PowerManager.WakeLock;

public class Snooze extends Service {

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
	}
	
	@Override
	@Deprecated
	public void onStart(Intent intent, int startId) {
		// TODO Auto-generated method stub
		super.onStart(intent, startId);
		
		
		String surveyID = intent.getStringExtra("survey_id");
		
    	SharedPreferences push_prefs = getApplicationContext().getSharedPreferences("PUSH_TYPE", Context.MODE_PRIVATE); // get the email saved in the preference
    	String push_type = push_prefs.getString("PUSH_TYPE", "");
    	//SharedPreferences.Editor editor = push_prefs.edit();      
	    //editor.putString("PUSH_TYPE", "5"); 
	    //editor.commit(); 
        
    	int ntsurvey_ID = Integer.parseInt(surveyID);
		int ntpush_Type = Integer.parseInt(push_type);
		
		System.out.println(ntsurvey_ID);
		
		SharedPreferences duration_prefs = this.getSharedPreferences("PUSH_DURATION", Context.MODE_PRIVATE); // get the email saved in the preference
        String push_duration = duration_prefs.getString("PUSH_DURATION", "");
        int ntpush_Duration = Integer.parseInt(push_duration);
        int durationTime = 0;
        
		
		if(ntpush_Duration == 1){
			durationTime = 1;
		} else if (ntpush_Duration == 2) {
			durationTime = 5;
		} else if (ntpush_Duration == 3) {
			durationTime = 15;
		} else if (ntpush_Duration == 4) {
			durationTime = 30;
		}
		

		if (!(ntsurvey_ID == 0)) {
			NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
			Intent notificationIntent = new Intent(getApplicationContext(), NotificationHomePage.class);
			//notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			notificationIntent.removeExtra("survey_id");
			notificationIntent.putExtra("survey_id", surveyID);
			//notification.flags |= Notification.FLAG_AUTO_CANCEL;
			//System.out.println(strntsurvey_ID);
			//System.out.println(strntsurvey_ID);
			PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0,
					notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
			
			int icon = R.drawable.ic_notif;
			String ticketText = "New survey available";
			long when = System.currentTimeMillis();
			//Do whatever you need right here
			
			Notification notification = new Notification(icon, ticketText, when);
			PowerManager pm = (PowerManager)getSystemService(Context.POWER_SERVICE);
			
			if (ntpush_Type == 1) {
				WakeLock mWakelock = pm.newWakeLock(PowerManager.ACQUIRE_CAUSES_WAKEUP |PowerManager.SCREEN_DIM_WAKE_LOCK, "SimpleTimer");
				mWakelock.acquire();
				Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
				vibrator.vibrate(1000 * durationTime);
				notification.defaults = Notification.DEFAULT_SOUND;
				notification.setLatestEventInfo(getApplicationContext(), "New Survey Available",
						"Tap here to do the survey!!", pendingIntent);
				//	notification.defaults=Notification.DEFAULT_VIBRATE;
				notificationManager.notify(123, notification);
				mWakelock.release();
				
			} else if (ntpush_Type == 2) {
				WakeLock mWakelock = pm.newWakeLock(PowerManager.ACQUIRE_CAUSES_WAKEUP |PowerManager.SCREEN_DIM_WAKE_LOCK, "SimpleTimer");
				mWakelock.acquire();
				Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
				vibrator.vibrate(1000 * durationTime);
				notification.setLatestEventInfo(getApplicationContext(), "New Survey Available",
						"Tap here to do the survey!!", pendingIntent);
				
				//	notification.defaults=Notification.DEFAULT_VIBRATE;
				notificationManager.notify(123, notification);
				mWakelock.release();
				
			} else if (ntpush_Type == 3) {
				WakeLock mWakelock = pm.newWakeLock(PowerManager.ACQUIRE_CAUSES_WAKEUP |PowerManager.SCREEN_BRIGHT_WAKE_LOCK, "SimpleTimer");
				mWakelock.acquire();
				notification.defaults |= Notification.DEFAULT_LIGHTS;
				
				notification.ledOnMS = ntpush_Duration * 1000; 
				notification.ledOffMS = 1000;
				notification.flags |= Notification.FLAG_SHOW_LIGHTS;
				notification.setLatestEventInfo(getApplicationContext(), "New Survey Available",
						"Tap here to do the survey!!", pendingIntent);
				//	notification.defaults=Notification.DEFAULT_VIBRATE;
				notificationManager.notify(123, notification);
				mWakelock.release();
				
			}
			
			
    	    stopSelf();
			
		}
	}

}
