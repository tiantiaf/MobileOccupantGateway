package com.example.ee579_finalproject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.widget.Toast;

public class ProximityService extends Service{
	int n = 0;
	private BroadcastReceiver receiver;
	private LocationManager locationManager;
    private static final String PROX_ALERT_INTENT = "com.example.ee579_finalproject.ProximityAlert"; // PLEASE CHECK - ORIGINAL: com.example.proximitytryout2.ProximityAlert
    private static final long POINT_RADIUS = 25; // in Meters
    private static final long PROX_ALERT_EXPIRATION = 3600000; // TODO - It will expire in 1 hour (SERVICE is restarted)
    
	public static final String EMAIL_KEY = "EMAIL_KEY";
    private static final String POINT_LATITUDE_KEY = "POINT_LATITUDE_KEY";
    private static final String POINT_LONGITUDE_KEY = "POINT_LONGITUDE_KEY";
    public static final String POINT_LOCATION_KEY = "POINT_LOCATION_KEY";
    public static final String POINT_LOCATION_SURVEY = "POINT_LOCATION_SURVEY";
    
    private static int iteration = 0;
    ArrayList <PendingIntent> proximityIntentList = new ArrayList<PendingIntent>();
    //PendingIntent proximityIntent = null;
    
	public ProximityService() {
	}

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}
	
	@Override
	public void onCreate() {
		// Create the RECEIVER for proximity alert - TODO: check if need to place here or at the onStart() method
		receiver = new ProximityIntentReceiver();
		locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
    	IntentFilter filter = new IntentFilter(PROX_ALERT_INTENT);
    	registerReceiver(receiver, filter); // create receiver with PROXIMITY ALERT filter
		Toast.makeText(this, "Proximity Service Created", Toast.LENGTH_LONG).show();
		
		/*
    	double lat;
    	double lng;
    	float radius = 50f;
    	long expiration = -1;
     	MyDBAdapter db = new MyDBAdapter(this);
        Cursor cursor;
        
        db.read();
        cursor = db.getAllEntries();
        boolean go = cursor.moveToFirst();
        while(cursor.isAfterLast() != true){
            lat = cursor.getInt(MyDBAdapter.LATITUDE_COLUMN)/1E6;
            lng = cursor.getInt(MyDBAdapter.LONGITUDE_COLUMN)/1E6;
            String what = cursor.getString(MyDBAdapter.ICON_COLUMN);
            String how = cursor.getString(MyDBAdapter.TYPE_COLUMN);
            String proximitys = "com.apps.ProximityService" + n;
            IntentFilter filter = new IntentFilter(proximitys);
            registerReceiver(mybroadcast, filter );

            Intent intent = new Intent(proximitys);

            intent.putExtra("alert", what);
            intent.putExtra("type", how);
            PendingIntent proximityIntent = PendingIntent.getBroadcast(this, n, intent, PendingIntent.FLAG_CANCEL_CURRENT);
            locationManager.addProximityAlert(lat, lng, radius, expiration, proximityIntent);
            //sendBroadcast(new Intent(intent));

            n++;
            cursor.moveToNext();
        }
        db.close();
        cursor.close();
        */
	}

	@Override
	public void onDestroy() {
		// TODO - need to remove Proximity Receiver - PLEASE CHECK!
		Toast.makeText(this, "Proximity Service Stopped", Toast.LENGTH_LONG).show();
		unregisterReceiver(receiver);
		
		// removing the obsolete proximity alert pending intent
		if(!proximityIntentList.isEmpty()){
			Iterator<PendingIntent> intentIter = proximityIntentList.iterator();
			while(intentIter.hasNext())
			{
			    PendingIntent myIntent = intentIter.next();
				locationManager.removeProximityAlert(myIntent);
			}
			proximityIntentList.clear();
		}
	}
	
	@Override
	public void onStart(Intent intent, int startid) {
		if(intent != null){ // TODO - PLEASE CHECK
			// find out the calling agent of the service
			Bundle extras = intent.getExtras();
			if (extras != null) {
				String callingStatus = extras.getString("STATUS");
				Toast.makeText(this, "Calling Status: " + callingStatus, Toast.LENGTH_LONG).show();
			}
		
			// remove the proximity alert for old location before adding new one
			if(!proximityIntentList.isEmpty()){
				Iterator<PendingIntent> intentIter = proximityIntentList.iterator();
				while(intentIter.hasNext())
				{
				    PendingIntent myIntent = intentIter.next();
					locationManager.removeProximityAlert(myIntent);
				}
				proximityIntentList.clear();
			}
			
			// TODO - add the location by querying server
	        SharedPreferences prefs = this.getSharedPreferences("SAVEDEMAIL", Context.MODE_PRIVATE); // get the email saved in the preference
	        String userEmail = prefs.getString(EMAIL_KEY, "");
			//String userEmail = "saketsrivastav79@gmail.com";
			if(userEmail != null && userEmail != ""){
	    		try{
	    			//Toast.makeText(this, "Query email: " + userEmail, Toast.LENGTH_LONG).show();
	    			String requestTarget = "http://building-occupant-gateway.com/api/get_surveys_for_user.php?email=" + userEmail;
	    			new QueryLocation().execute(requestTarget); // execute the request to the server
	    			Toast.makeText(this, "Proximity Service Started with email: " + userEmail, Toast.LENGTH_LONG).show();
	    		}catch(Exception e){
	    			e.printStackTrace();
	    		}
			}else{
				Toast.makeText(this, "Proximity NOT Service Started", Toast.LENGTH_LONG).show();
			}
			//addProximityAlert((float) 34.158852, (float) -118.31298, "Home");
			/*
			if(intent != null && intent.getStringExtra(POINT_LATITUDE_KEY) != null && intent.getStringExtra(POINT_LONGITUDE_KEY) != null){
				Float latitude = Float.parseFloat(intent.getStringExtra(POINT_LATITUDE_KEY));
				Float longitude = Float.parseFloat(intent.getStringExtra(POINT_LONGITUDE_KEY));
				String location = intent.getStringExtra(POINT_LOCATION_KEY);
				addProximityAlert(latitude, longitude, location);
			}
			*/
			
			/*
			// testing shared preference
			float[] testLocation = new float[2];
			testLocation = retrievelocationFromPreferences();
			Toast.makeText(this, "Shared Test; Lat: " + testLocation[0] + "; Long: " + testLocation[1], Toast.LENGTH_LONG).show();
			*/
		}
	}
	
    // WEB REQUEST PART - Fetching the Survey Location & ID
    public static DefaultHttpClient getThreadSafeClient() {
		DefaultHttpClient client = new DefaultHttpClient();
		ClientConnectionManager mgr = client.getConnectionManager();
		HttpParams params = client.getParams();
		client = new DefaultHttpClient(new ThreadSafeClientConnManager(params, mgr.getSchemeRegistry()), params);
	
		return client;
	}
	
    // Request survey location & ID to the server
	private class QueryLocation extends AsyncTask<String, Void, String> {
		protected void onPreExecute (){
		}
		
		@Override
		protected String doInBackground(String... inputString) {
			// request music from Servlet
        	String resultString = new String();        		
        	try{
        		int TIMEOUT_MILLISEC = 10000;
        		HttpParams httpParams = new BasicHttpParams(); 
        		HttpConnectionParams.setConnectionTimeout(httpParams, TIMEOUT_MILLISEC); 
        		HttpConnectionParams.setSoTimeout(httpParams, TIMEOUT_MILLISEC);
        		HttpClient client = getThreadSafeClient();
        		HttpGet request = new HttpGet(inputString[0]);
	        	//client.execute(request);
	        		
	        	HttpResponse response = client.execute(request); 
	        	HttpEntity he = response.getEntity();
	        	InputStream is = he.getContent();
	        	BufferedReader br = new BufferedReader(new InputStreamReader(is));
	        	resultString = br.readLine();
	        	response.getEntity().consumeContent();
	        	is.close();
        	}catch(Exception e){
        		e.printStackTrace();
        	}
        	
        	return resultString;
		}
		
		@Override
		protected void onPostExecute(String resultString) {
    		try{
    			// get & parse the JSON
    			String tempStr = "";
    			JSONObject myJson = new JSONObject(resultString);
    			JSONArray surveyJsonArray = myJson.getJSONArray("data");
    			
    			// add the survey location& ID to the Proximity Alert
				for(int walk = 0; walk < surveyJsonArray.length(); walk++){
					JSONObject elementJson = surveyJsonArray.getJSONObject(walk);
					String mySurveyID = elementJson.getString("survey_id");
					String[] mySurveyLongLat = elementJson.getString("geodata").split(",");

					tempStr += "*" + mySurveyID + "*\n";
					tempStr += "*" + mySurveyLongLat[0] + "*\n";
					tempStr += "*" + mySurveyLongLat[1] + "*\n";
					if(walk == 0){
						// Keep track for the first addition
						iteration = 0;
					}
					
					// Add the survey location to the proximity alert
	    			addProximityAlert(Float.parseFloat(mySurveyLongLat[0]), Float.parseFloat(mySurveyLongLat[1]), "Location", mySurveyID);
				}

				/*
				// NOTES - used to check if the JSON is received properly or not
    			Intent intent = new Intent(ProximityService.this, DisplayActivity.class);
    			intent.setType("text/plain");
    			intent.putExtra(android.content.Intent.EXTRA_TEXT, tempStr);
    			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); // TODO - NEED TO REMOVE
    			startActivity(intent); 
    			*/
    		}catch(Exception e){
    			e.printStackTrace();
    		}
		}
	}
	
    private void addProximityAlert(Float latitude, Float longitude, String locationStr, String locationSurveyID) {
    	/*
        //SharedPreferences prefs = this.getSharedPreferences(getClass().getSimpleName(), Context.MODE_MULTI_PROCESS);
        //float latitude = prefs.getFloat(POINT_LATITUDE_KEY, 0);
        //float longitude = prefs.getFloat(POINT_LONGITUDE_KEY, 0);
        
        //latitude = (float) 34.1590942;
        //longitude = (float) -118.31270677;
        */
        
    	//Toast.makeText(this, ProximityAlertActivity.class.getName(), Toast.LENGTH_SHORT).show();
    	Intent intent = new Intent(PROX_ALERT_INTENT);
    	intent.putExtra(POINT_LOCATION_KEY, locationStr); // put the name of the location to the intent
    	intent.putExtra(POINT_LOCATION_SURVEY, locationSurveyID); //put the survey ID to the intent
    	
    	// TODO - check if require to specify request code - TEST IF WORKING OR NOT
    	PendingIntent proximityIntent = null;
    	if(iteration == 0){
    		// First addition - cancel the current pending intent
    		proximityIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT);
    	}else{
    		proximityIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_ONE_SHOT);
    	}
    	locationManager.addProximityAlert(
    			latitude, // the latitude of the central point of the alert region
    			longitude, // the longitude of the central point of the alert region
    			POINT_RADIUS, // the radius of the central point of the alert region, in meters
    			PROX_ALERT_EXPIRATION, // time for this proximity alert, in milliseconds, or -1 to indicate no expiration
    			proximityIntent // will be used to generate an Intent to fire when entry to or exit from the alert region is detected
    	);
    	
    	// add to array list for reference
    	proximityIntentList.add(proximityIntent);
    	iteration++;
    	
    	// Find the distance to the newly added survey location
        Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        float distance = 0;
        if (location != null) {
            Location target = new Location("POINT_LOCATION");
            target.setLatitude(latitude);
            target.setLongitude(longitude);
            distance = location.distanceTo(target);
        }
        
        /*
        // testing shared content
        saveCoordinatesInPreferences(latitude, longitude);
        */
        
        // DEBUG purpose - print message (VERY IMPORTANT: getApplicationContext())
    	Toast.makeText(getApplicationContext(), "Latitude = " + latitude + "; Longitude = " + longitude + "; distance = " + distance, Toast.LENGTH_LONG).show();
    }
}
    /*
    private void saveCoordinatesInPreferences(float latitude, float longitude) {
        SharedPreferences prefs = this.getSharedPreferences(getClass().getSimpleName(), Context.MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = prefs.edit();
        prefsEditor.putFloat(POINT_LATITUDE_KEY, latitude);
        prefsEditor.putFloat(POINT_LONGITUDE_KEY, longitude);
        prefsEditor.commit();
    }
    
    private float[] retrievelocationFromPreferences() {
        SharedPreferences prefs = this.getSharedPreferences(getClass().getSimpleName(), Context.MODE_PRIVATE);
        float[] location = new float[2];
        location[0] = prefs.getFloat(POINT_LATITUDE_KEY, 0);
        location[1] = prefs.getFloat(POINT_LONGITUDE_KEY, 0);
        return location;
    }
    */
	
	/*
	public class ProximityIntentReceiver extends BroadcastReceiver{
		private static final int NOTIFICATION_ID = 1000;
    
		@Override
		public void onReceive(Context arg0, Intent arg1) {
			String key = LocationManager.KEY_PROXIMITY_ENTERING;

			Boolean entering = arg1.getBooleanExtra(key, false);
			String here = arg1.getExtras().getString("alert");
			String happy = arg1.getExtras().getString("type");
			
			if(entering){
			}

			NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
			PendingIntent pendingIntent = PendingIntent.getActivity(arg0, 0, arg1, 0);        
			Notification notification = createNotification();
			notification.setLatestEventInfo(arg0, "Proximity Alert!", "You are approaching a " + here + " marker.", pendingIntent);
			notificationManager.notify(NOTIFICATION_ID, notification);
		}

		private Notification createNotification() {
			Notification notification = new Notification();

			notification.icon = R.drawable.ic_launcher;
			notification.when = System.currentTimeMillis();

         	notification.flags |= Notification.FLAG_AUTO_CANCEL;
         	notification.flags |= Notification.FLAG_SHOW_LIGHTS;

         	notification.defaults |= Notification.DEFAULT_VIBRATE;
         	notification.defaults |= Notification.DEFAULT_LIGHTS;

          	notification.ledARGB = Color.WHITE;
           	notification.ledOnMS = 1500;
          	notification.ledOffMS = 1500;

          	return notification;
		}
	}
	*/