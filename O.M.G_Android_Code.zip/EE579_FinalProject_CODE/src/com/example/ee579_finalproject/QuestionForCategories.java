package com.example.ee579_finalproject;

import java.util.ArrayList;

public class QuestionForCategories {
	public ArrayList<String> questionType = new ArrayList<String>();
	public ArrayList<String> questionText = new ArrayList<String>();
	public ArrayList<String> questionID = new ArrayList<String>();
	public ArrayList<String> optionID = new ArrayList<String>();
	public ArrayList<String> relatedType = new ArrayList<String>();
	public ArrayList<String> relatedText = new ArrayList<String>();
	public ArrayList<String> relatedID = new ArrayList<String>();
	public ArrayList<String> relatedOptionID = new ArrayList<String>();
			
	public QuestionForCategories(){
		
	}
}
