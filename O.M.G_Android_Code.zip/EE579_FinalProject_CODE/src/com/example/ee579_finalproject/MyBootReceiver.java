package com.example.ee579_finalproject;

import java.util.Calendar;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.util.Log;

public class MyBootReceiver extends BroadcastReceiver {
	  // Restart service every 30 seconds
	  // private static final long REPEAT_TIME = 1000 * 30;

	  @Override
	  public void onReceive(Context context, Intent intent) {
		  // First called -> start the proximity alert service
		  
		  if(Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())){
				 Intent intent1=new Intent(context,Alarmreceiver.class);
				 intent1.setAction("arui.alarm.action");
				 PendingIntent sender=PendingIntent.getBroadcast(context, 0, intent1, 0);
				 long firsttime=SystemClock.elapsedRealtime();
				 AlarmManager am=(AlarmManager) context.getSystemService(context.ALARM_SERVICE);
				 am.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP,firsttime,10*1000,sender);
				 
				 //Toast.makeText(context, "first Broad", Toast.LENGTH_LONG).show();
			 }
		  Intent proximityService = new Intent(context, ProximityService.class);
		  context.startService(proximityService);
		  // Create the alarm
		  AlarmManager service = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
		  Intent serviceStartIntent = new Intent(context, MyStartServiceReceiver.class);
		  PendingIntent pendingServiceStart = PendingIntent.getBroadcast(context, 0, serviceStartIntent, PendingIntent.FLAG_CANCEL_CURRENT);
		  	    
		  // Restart the proximity service every 1 hour
		  Calendar cal = Calendar.getInstance();
		  cal.add(Calendar.MINUTE, 1);
	    
		  // Fetch every 1 hours
		  // InexactRepeating allows Android to optimize the energy consumption
		  service.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), AlarmManager.INTERVAL_HOUR, pendingServiceStart);
	  }
} 