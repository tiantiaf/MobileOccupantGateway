package com.example.ee579_finalproject;

import com.robocatapps.thermodosdk.Thermodo;
import com.robocatapps.thermodosdk.ThermodoFactory;
import com.robocatapps.thermodosdk.ThermodoListener;


import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class TemperatureActivity extends Activity implements ThermodoListener{
	private Thermodo mThermodo;
	private TextView mTemperatureTextView;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_temperature);

		mTemperatureTextView = (TextView) findViewById(R.id.temperatureTextView);
		mThermodo = ThermodoFactory.getThermodoInstance(this);
		mThermodo.setThermodoListener(this);
		mThermodo.start();
	}
	
	@Override
	public void onErrorOccurred(int arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStartedMeasuring() {
		// TODO Auto-generated method stub
		Toast.makeText(this, "Started measuring", Toast.LENGTH_SHORT).show();
		
	}

	@Override
	public void onStoppedMeasuring() {
		// TODO Auto-generated method stub
		Toast.makeText(this, "ThermodoSensor unpluged", Toast.LENGTH_SHORT).show();
		mTemperatureTextView.setText("ThermodoSensor is unpluged.Please plug in to continue");
		
	}

	@Override
	public void onTemperatureMeasured(float temperature) {
		// TODO Auto-generated method stub
		mTemperatureTextView.setText(Float.toString(temperature));
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		mThermodo.start();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		mThermodo.stop();
	}


}
