package com.example.ee579_finalproject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.Vibrator;
import android.util.Log;
import android.widget.Toast;

public class NotificationService extends Service {
	private BroadcastReceiver receiver;
	private NotificationManager nm;
	public static final String EMAIL_KEY = "EMAIL_KEY";
	private JSONObject resultJsonObject;
	private Notification notification;
	private static final int uniqueID = 12345;
	String data, str;
	String strntsurvey_ID;
	String strntpush_ID;
	String strntDefaultSurvey;
	String strntpush_Duration;
	int nisurvey_ID;
	String user;
	private int durationTime;
	
	//private static final String POINT_LOCATION_KEY = "POINT_LOCATION_KEY";
    //public static final String POINT_LOCATION_SURVEY = "POINT_LOCATION_SURVEY";
	
	
	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		//receiver = new MyBootReceiver();
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		Toast.makeText(this, "onDestroy", Toast.LENGTH_SHORT).show();
	}

	@Override
	@Deprecated
	public void onStart(Intent intent, int startId) {
		// TODO Auto-generated method stub
		super.onStart(intent, startId);
		SharedPreferences prefs = this.getSharedPreferences("SAVEDEMAIL", Context.MODE_PRIVATE); // get the email saved in the preference
        String userEmail = prefs.getString(EMAIL_KEY, "");
        
        SharedPreferences push_prefs = this.getSharedPreferences("PUSH_TYPE", Context.MODE_PRIVATE); // get the email saved in the preference
        String push_type = push_prefs.getString("PUSH_TYPE", "");
        
        user = userEmail;
        
        Log.i("data", user);
		
        if(user != null && user != ""){
		new HttpGetTask().execute();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Toast.makeText(this, data, Toast.LENGTH_SHORT).show();
		/*
		if(data != null && data.startsWith("\ufeff"))
        {
			data =  data.substring(1);
        }*/
		
		if (data == null) {
			return;
		}
        
		Log.i("data", data);

		String start1 = "\"push_survey_id\"";
		String start2 = "\"push_type\"";
		String start3 = "\"default_survey\"";
		String start4 = "\"push_duration\"";
		
		int st1 = data.indexOf(start1);
		int st2 = data.indexOf(start2);
		int st3 = data.indexOf(start3);
		int st4 = data.indexOf(start4);
		
		Log.i("data", Integer.toString(st1));
		int i = data.indexOf('}');
		strntsurvey_ID = data.substring(st1 + 18, st2 - 2);
		strntpush_ID   = data.substring(st2 + 13, st3 - 2);
		strntDefaultSurvey = data.substring(st3 + 18, st4 - 2);
		strntpush_Duration = data.substring(st4 + 17, data.length() - 3);
		
		Log.i("Notification", strntsurvey_ID);
		Log.i("Notification", strntpush_ID);
		Log.i("Notification", strntDefaultSurvey);
		Log.i("Notification", strntpush_Duration);
		
		// Notification feature
		
		int ntsurvey_ID = Integer.parseInt(strntsurvey_ID);
		int ntpush_Type = Integer.parseInt(strntpush_ID);
		int ntdefault_Survey = Integer.parseInt(strntDefaultSurvey);
		int ntpush_Duration = Integer.parseInt(strntpush_Duration);
		
		// Store Default survey into the shared preference
		SharedPreferences defalut_prefs = this.getSharedPreferences("DEFAULT_SURVEY", Context.MODE_PRIVATE); // get the email saved in the preference
        //String currentDefaulSurvey = defalut_prefs.getString("DEFAULT_SURVEY", "");
        
		SharedPreferences.Editor deault_editor = defalut_prefs.edit();      
		deault_editor.putString("DEFAULT_SURVEY", strntDefaultSurvey); 
		deault_editor.commit(); 
		
		// Store Duration into the shared preference
		SharedPreferences duration_prefs = this.getSharedPreferences("PUSH_DURATION", Context.MODE_PRIVATE); // get the email saved in the preference
        //String currentDefaulSurvey = defalut_prefs.getString("DEFAULT_SURVEY", "");
        
		SharedPreferences.Editor duration_editor = duration_prefs.edit();      
		duration_editor.putString("PUSH_DURATION", strntpush_Duration); 
		duration_editor.commit();
		
		if(ntpush_Duration == 1){
			durationTime = 1;
		} else if (ntpush_Duration == 2) {
			durationTime = 5;
		} else if (ntpush_Duration == 3) {
			durationTime = 15;
		} else if (ntpush_Duration == 4) {
			durationTime = 30;
		}
		
		
		if (!(ntsurvey_ID == 0)) {
			
			SharedPreferences.Editor editor = push_prefs.edit();      
		    editor.putString("PUSH_TYPE", strntpush_ID); 
		    editor.commit(); 
			NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
			Intent notificationIntent = new Intent(this, NotificationHomePage.class);
			notificationIntent.removeExtra("survey_id");
			notificationIntent.putExtra("survey_id", strntsurvey_ID);
			
			PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
					notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
			
			int icon = R.drawable.ic_notif;
			String ticketText = "New survey available";
			long when = System.currentTimeMillis();
			//Do whatever you need right here
			
			Notification notification = new Notification(icon, ticketText, when);
			PowerManager pm = (PowerManager)getSystemService(Context.POWER_SERVICE);
			
			if (ntpush_Type == 1) {
				WakeLock mWakelock = pm.newWakeLock(PowerManager.ACQUIRE_CAUSES_WAKEUP |PowerManager.SCREEN_DIM_WAKE_LOCK, "SimpleTimer");
				mWakelock.acquire();
				Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
				v.vibrate(1000 * durationTime);
				notification.defaults = Notification.DEFAULT_SOUND;
				
				notification.setLatestEventInfo(this, "New Survey Available",
						"Tap here to do the survey!!", pendingIntent);
				notificationManager.notify(123, notification);
				mWakelock.release();
			} else if (ntpush_Type == 2) {
				WakeLock mWakelock = pm.newWakeLock(PowerManager.ACQUIRE_CAUSES_WAKEUP |PowerManager.SCREEN_DIM_WAKE_LOCK, "SimpleTimer");
				mWakelock.acquire();
				Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
				v.vibrate(1000 * durationTime);
				notification.setLatestEventInfo(this, "New Survey Available",
						"Tap here to do the survey!!", pendingIntent);
				
				//	notification.defaults=Notification.DEFAULT_VIBRATE;
				notificationManager.notify(123, notification);
				mWakelock.release();
			} else if (ntpush_Type == 3) {
				WakeLock mWakelock = pm.newWakeLock(PowerManager.ACQUIRE_CAUSES_WAKEUP |PowerManager.SCREEN_BRIGHT_WAKE_LOCK, "SimpleTimer");
				notification.defaults |= Notification.DEFAULT_LIGHTS;
				
				notification.ledOnMS = ntpush_Duration * 1000; 
				notification.ledOffMS = 1000;
				notification.flags |= Notification.FLAG_SHOW_LIGHTS;
				notification.flags |= Notification.FLAG_INSISTENT;
				mWakelock.acquire();
				notification.setLatestEventInfo(this, "New Survey Available",
						"Tap here to do the survey!!", pendingIntent);
				//	notification.defaults=Notification.DEFAULT_VIBRATE;
				notificationManager.notify(123, notification);
				mWakelock.release();
			}
			
			stopSelf();
			
		}
        }
	}

	private class HttpGetTask extends AsyncTask<Void, Void, String> {

		private String TAG = "HttpGetTask";

		private String USER_NAME = user;
		private String URL = "http://building-occupant-gateway.com/EE579Project/api/get_push_notification.php?email="
				+ USER_NAME;

		@Override
		protected String doInBackground(Void... params) {
			// String data = "";
			HttpURLConnection httpUrlConnection = null;

			try {
				httpUrlConnection = (HttpURLConnection) new URL(URL)
						.openConnection();

				InputStream in = new BufferedInputStream(
						httpUrlConnection.getInputStream());

				data = readStream(in);

			} catch (MalformedURLException exception) {
				Log.e(TAG, "MalformedURLException");
			} catch (IOException exception) {
				Log.e(TAG, "IOException");
			} finally {
				if (null != httpUrlConnection)
					httpUrlConnection.disconnect();
			}
			return data;
		}

		@Override
		protected void onPostExecute(String result) {
			// mTextView.setText(result);
			str = result;
		}

		private String readStream(InputStream in) {
			BufferedReader reader = null;
			StringBuffer data = new StringBuffer("");
			try {
				reader = new BufferedReader(new InputStreamReader(in));
				String line = "";
				while ((line = reader.readLine()) != null) {
					data.append(line);
				}
			} catch (IOException e) {
				Log.e(TAG, "IOException");
			} finally {
				if (reader != null) {
					try {
						reader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			return data.toString();
		}
	}
}
