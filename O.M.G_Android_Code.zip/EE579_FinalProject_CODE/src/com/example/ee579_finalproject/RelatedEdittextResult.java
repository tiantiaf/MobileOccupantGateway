package com.example.ee579_finalproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class RelatedEdittextResult {
	public EditText commentEdit;
	
	public RelatedEdittextResult(){
		
	}
	
	public void addEdittextComponent(final Context context, View encloseView, String componentQuestion, Object[] resultPointer){     
    	LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View edittextView = inflater.inflate(R.layout.edittext_layout, null);
		
        // get the enclosed component - FOR INSERTION
		LinearLayout testingAdd = (LinearLayout) encloseView.findViewById(R.id.encloseLayout);
        
        TextView editTextview = (TextView) edittextView.findViewById(R.id.edittextQuestion);
        editTextview.setText(componentQuestion);
        
        commentEdit = (EditText) edittextView.findViewById(R.id.edittextSpace);
        commentEdit.clearFocus();
        //this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        
        resultPointer[1] = commentEdit;
        
        // check for previous view
		int count = testingAdd.getChildCount();
		for(int walk = 1; walk < count; walk++){
			testingAdd.removeViewAt(walk);
		}
        
        // add the component to the view
		testingAdd.addView(edittextView);	
	}
}
