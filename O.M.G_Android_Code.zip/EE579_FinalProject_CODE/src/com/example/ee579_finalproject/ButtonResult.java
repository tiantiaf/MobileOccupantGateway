package com.example.ee579_finalproject;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ButtonResult {
	public Button[] componentButtons;
	private int[] buttonColors = {Color.RED, Color.MAGENTA, Color.LTGRAY, Color.CYAN, Color.BLUE};
	private boolean[] optPressed = {false, false, false, false, false};

	public ButtonResult(){
		
	}
	
	public Button[] addButtonComponents(final Context context, LinearLayout currentLayout, String componentQuestion){        
    	LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View questionView = inflater.inflate(R.layout.checkboxquestion_layout, null);
    
        // do the question parsing (semicolon delimited)
        String[] questionParsed = componentQuestion.split(";");
        
        // add the check box question
        TextView questionTextView = (TextView) questionView.findViewById(R.id.checkboxQuestion);
        questionTextView.setText(questionParsed[0]);
        currentLayout.addView(questionView);
        
        // add the check box components
        int buttonCount = questionParsed.length - 1;
        componentButtons = new Button[buttonCount];
        for(int walk = 0; walk < componentButtons.length; walk++){
    	   componentButtons[walk] = addButtonComponent(context, currentLayout, questionParsed[walk + 1], buttonColors[walk]);
    	   
        }
        
        
      if(componentButtons.length == 5)
      {
    	  	componentButtons[0].setOnClickListener(new OnClickListener() {
			
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					optPressed[0] = !optPressed[0];
					if (optPressed[0] == true) 
	                {
						componentButtons[0].setBackgroundColor(buttonColors[0]);
	                    for(int num = 1; num < componentButtons.length;num++){
	                    	//componentButtons[num].setEnabled(false);
	                    	//componentButtons[num].setClickable(false);
	                    	componentButtons[num].setBackgroundColor(Color.GRAY);
	                    	//componentCheckBox[0].setEnabled(true);
	                    	optPressed[num] = false;
	                    }
	                } else {
	                	for(int num = 0; num < componentButtons.length;num++){
	                    	componentButtons[num].setEnabled(true);
	                    	componentButtons[num].setClickable(true);
	                    	componentButtons[num].setBackgroundColor(buttonColors[num]);
	                    	//componentCheckBox[0].setEnabled(true);
	                    }
					}
				}
			});
    	  	
    	  	componentButtons[1].setOnClickListener(new OnClickListener() {
    			
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					optPressed[1] = !optPressed[1];
					if (optPressed[1] == true) 
	                {
						componentButtons[1].setBackgroundColor(buttonColors[1]);
						for(int num = 0; num < 1; num++){
							//componentButtons[num].setEnabled(false);
	                    	//componentButtons[num].setClickable(false);
	                    	componentButtons[num].setBackgroundColor(Color.GRAY);
	                    	optPressed[num] = false;
	                    }
						
	                    for(int num = 2; num < componentButtons.length; num++){
	                    	//componentButtons[num].setEnabled(false);
	                    	//componentButtons[num].setClickable(false);
	                    	componentButtons[num].setBackgroundColor(Color.GRAY);
	                    	optPressed[num] = false;
	                    	
	                    }
	                } else {
	                	for(int num = 0; num < componentButtons.length;num++){
	                    	componentButtons[num].setEnabled(true);
	                    	componentButtons[num].setClickable(true);
	                    	componentButtons[num].setBackgroundColor(buttonColors[num]);
	                    	
	                    }
					}
				}
			});
    	  	
    	  	componentButtons[2].setOnClickListener(new OnClickListener() {
    			
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					optPressed[2] = !optPressed[2];
					if (optPressed[2] == true) 
	                {
						componentButtons[2].setBackgroundColor(buttonColors[2]);
						for(int num = 0; num < 2; num++){
							//componentButtons[num].setEnabled(false);
	                    	//componentButtons[num].setClickable(false);
	                    	componentButtons[num].setBackgroundColor(Color.GRAY);
	                    	optPressed[num] = false;
	                    }
						
	                    for(int num = 3; num < componentButtons.length;num++){
	                    	//componentButtons[num].setEnabled(false);
	                    	//componentButtons[num].setClickable(false);
	                    	componentButtons[num].setBackgroundColor(Color.GRAY);
	                    	optPressed[num] = false;
	                    	
	                    }
	                } else {
	                	for(int num = 0; num < componentButtons.length;num++){
	                    	componentButtons[num].setEnabled(true);
	                    	componentButtons[num].setClickable(true);
	                    	componentButtons[num].setBackgroundColor(buttonColors[num]);
	                    	
	                    }
					}
				}
			});

    	  	componentButtons[3].setOnClickListener(new OnClickListener() {
    			
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					optPressed[3] = !optPressed[3];
					if (optPressed[3] == true) 
	                {
						componentButtons[3].setBackgroundColor(buttonColors[3]);
						for(int num = 0; num < 3; num++){
							//componentButtons[num].setEnabled(false);
	                    	//componentButtons[num].setClickable(false);
	                    	componentButtons[num].setBackgroundColor(Color.GRAY);
	                    	optPressed[num] = false;
	                    }
						
	                    for(int num = 4; num < componentButtons.length;num++){
	                    	//componentButtons[num].setEnabled(false);
	                    	//componentButtons[num].setClickable(false);
	                    	componentButtons[num].setBackgroundColor(Color.GRAY);
	                    	optPressed[num] = false;
	                    	
	                    }
	                } else {
	                	for(int num = 0; num < componentButtons.length;num++){
	                    	componentButtons[num].setEnabled(true);
	                    	componentButtons[num].setClickable(true);
	                    	componentButtons[num].setBackgroundColor(buttonColors[num]);
	                    	
	                    }
					}
				}
			});
    	  	
    	  	componentButtons[4].setOnClickListener(new OnClickListener() {
    			
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					optPressed[4] = !optPressed[4];
					if (optPressed[4] == true) 
	                {
						componentButtons[4].setBackgroundColor(buttonColors[4]);
						for(int num = 0; num < 4; num++){
							//componentButtons[num].setEnabled(false);
	                    	//componentButtons[num].setClickable(false);
	                    	componentButtons[num].setBackgroundColor(Color.GRAY);
	                    	optPressed[num] = false;
	                    }
						
	                } else {
	                	for(int num = 0; num < componentButtons.length;num++){
	                    	//componentButtons[num].setEnabled(true);
	                    	//componentButtons[num].setClickable(true);
	                    	componentButtons[num].setBackgroundColor(buttonColors[num]);
	                    	
	                    }
					}
				}
			});
    	  	
    	  	
                 
        }
        return componentButtons;
        
	}
	
    private Button addButtonComponent(Context context, LinearLayout currentLayout, String componentQuestion, int buttonColor){
    	LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View componentView = inflater.inflate(R.layout.button5_layout, null);
        
        Button componentButton = (Button) componentView.findViewById(R.id.button_layout);
        componentButton.setBackgroundColor(buttonColor);
        componentButton.setText(componentQuestion);
        currentLayout.addView(componentView);
        
		return componentButton;
    }
}
