package com.example.ee579_finalproject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.achartengine.GraphicalView;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

import com.example.ee579_finalproject.Point;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.AsyncTask;
import android.os.BatteryManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.LinearLayout;

public class LightActivity extends Activity implements SensorEventListener,
		OnClickListener {

	TextView textDirection;
	TextView textReading;
	private Button startButton, doneButton, stopButton;
	float sensorValueSum = 0;
	float sensorValueAve = 0;
	float readingCount = 0;
	private LinearLayout layout;
	private static GraphicalView view;
	private LineGraph line = new LineGraph();
	private SensorManager asm, sm;
	Sensor Light, accelerometer;
	boolean started;
	long a, b, c;
	int bl;
	boolean isCharging;
	int y = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.light_layout);
		sm = (SensorManager) getSystemService(SENSOR_SERVICE);
		/*asm = (SensorManager) getSystemService(SENSOR_SERVICE);
		accelerometer = asm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		asm.registerListener(this, accelerometer,
				SensorManager.SENSOR_DELAY_NORMAL);*/
		if (sm.getSensorList(Sensor.TYPE_LIGHT).size() != 0) {
			Light = sm.getDefaultSensor(Sensor.TYPE_LIGHT);
		//	accelerometer = asm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		} else {
			textReading.setText("No Light Sensor");
		}
	/*	asm.registerListener(this, accelerometer,
				SensorManager.SENSOR_DELAY_NORMAL);*/
		textReading = (TextView) findViewById(R.id.reading);
		textReading.setText("0");
		startButton = (Button) findViewById(R.id.lightstartbutton);
		startButton.setText("Start");
		stopButton = (Button) findViewById(R.id.lightstopbutton);
		stopButton.setText("stop");
		doneButton = (Button) findViewById(R.id.lightdonebutton);
		doneButton.setText("done");
		layout = (LinearLayout) findViewById(R.id.chart);
		startButton.setOnClickListener(this);
		stopButton.setOnClickListener(this);
		doneButton.setOnClickListener(this);
		startButton.setEnabled(true);
		stopButton.setEnabled(false);
		doneButton.setEnabled(false);
		view = line.getView(this);
		layout.addView(view);
		this.registerReceiver(this.mBatInfoReceiver, new IntentFilter(
				Intent.ACTION_BATTERY_CHANGED));

	}

	BroadcastReceiver mBatInfoReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context ctxt, Intent intent) {
			// TODO Auto-generated method stub
			int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
			int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
			isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING
					|| status == BatteryManager.BATTERY_STATUS_FULL;
			bl = level;
		}
	};

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.lightstartbutton:
			Runner runner1 = new Runner();
			Runner2 runner2 = new Runner2();
			if (bl >= 50 || isCharging == true) {
			//	asm.registerListener(this, accelerometer,
			//			SensorManager.SENSOR_DELAY_NORMAL);
			//	if ((-1 < a && a < 1) && (-1 < b && b < 1) && (7 < c && c < 10)) {
					startButton.setEnabled(false);
					stopButton.setEnabled(true);
					doneButton.setEnabled(true);
					started = true;
					sm.registerListener(this, Light,
							SensorManager.SENSOR_DELAY_NORMAL);
					runner1.start();
					runner2.start();
			/*	} else {
					Toast.makeText(this,
							"Please place your device flat on the dest",
							Toast.LENGTH_SHORT).show();
					break;
				}*/
			} else {
				Toast.makeText(this, "Warning:Low battery!!!Can't do that!!",
						Toast.LENGTH_SHORT).show();
				break;
			}
			break;
		case R.id.lightstopbutton:
			started = false;
			startButton.setEnabled(true);
			stopButton.setEnabled(false);
			doneButton.setEnabled(false);
		//	asm.unregisterListener(this);
			sm.unregisterListener(this);
			textReading.setText(String.valueOf((int) sensorValueAve));
			sensorValueSum = 0;
			sensorValueAve = 0;
			readingCount = 0;
			break;
		case R.id.lightdonebutton:
			started = false;
			Intent resultData2 = new Intent();
			resultData2.putExtra("lightValue", sensorValueAve + "");
			setResult(Activity.RESULT_OK, resultData2);
			finish();
			break;
		default:
			break;

		}
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		// TODO Auto-generated method stub
		Sensor source = event.sensor;

		 if (source.equals(Light) && started) {
			if (bl >= 50) {

				float currentReading = event.values[0];
				// lightMeter.setProgress((int)currentReading);
				readingCount++;
				sensorValueSum += currentReading;
				sensorValueAve = (sensorValueSum / readingCount);
				textReading.setText(String.valueOf(currentReading));
			} else {
				Toast.makeText(this, "Warning:Low battery!!!",
						Toast.LENGTH_SHORT).show();
			}
		}
	}

	class Runner extends Thread {

		public void run() {
			// TODO Auto-generated method stub
			while (started) {
				if (bl >= 50) {
					Double x = Double.parseDouble(textReading.getText()
							.toString());
					y++;
					Point data = new Point(x, y);
					line.addNewData(data, x);
					view.postInvalidate();
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}

			}
		}
	}

	class Runner2 extends Thread {
		public void run() {
			// TODO Auto-generated method stub
			while (started) {
				try {
					Thread.sleep(60000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			//	String strToSent = textReading.toString() + " " + bl;
			//	Log.d("Light and battery", strToSent);
			//	new SendToServer().execute(strToSent);
			}

		}

	}

	
}