package com.example.ee579_finalproject;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class CheckboxResult4 {
	public CheckBox[] componentCheckBox;
//	String choice_NUM;
	public CheckboxResult4(){
		
	}
	
	public Object[] addCheckboxComponent(final Context context, final View encloseView, final LinearLayout currentLayout, String componentQuestion, final String relatedType, final String relatedText){        
		int resultLength = 0;
		if(!relatedText.equals("")){
			if(relatedType.equals(MainActivity.CHECKBOX_TYPE)||relatedType.equals(MainActivity.CHECKBOX_TYPE1)){
				String[] questionParsed1 = relatedText.split(";");
				resultLength =resultLength+questionParsed1.length;
				
				
			}else if(relatedType.equals(MainActivity.LIKERT_TYPE) || relatedType.equals(MainActivity.EDITTEXT_TYPE)){
				String[] questionParsed1 = relatedText.split(";");
				resultLength = resultLength+1;
			
			}
		
		
		}else{
			resultLength=5;
		}
		Log.d("LENGTH", resultLength + "");
		final Object[] resultPointer = new Object[resultLength];
		LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View questionView = inflater.inflate(R.layout.checkboxquestion_layout, null);
    // int walk;
	// int walk2;
        
        // do the question parsing (semicolon delimited)
        String[] questionParsed = componentQuestion.split(";");

        // add the check box question
        TextView questionTextView = (TextView) questionView.findViewById(R.id.checkboxQuestion);
        questionTextView.setText(questionParsed[0]);
        currentLayout.addView(questionView);
        int checkBoxCount = questionParsed.length - 1;


        resultPointer[0]=questionTextView;
        // add the check box components

      //  resultLength=resultLength+checkBoxCount-1;
        if(relatedType.equals("") && relatedText.equals("")){
        	componentCheckBox = new CheckBox[checkBoxCount];
            for(int walk = 0; walk < componentCheckBox.length; walk++){
            	componentCheckBox[walk] = addCheckBoxComponent(context, currentLayout, questionParsed[walk + 1]);
            	resultPointer[walk + 1] = componentCheckBox[walk];
            }
           // if(componentCheckBox[0].isChecked()){
            if(componentCheckBox.length==4)
            {
              componentCheckBox[0].setOnCheckedChangeListener(new OnCheckedChangeListener() {

      			@Override
      			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
      				// TODO Auto-generated method stub

                      if (componentCheckBox[0].isChecked() == true) 
                      {
                    	  componentCheckBox[1].setChecked(false);
                    	  componentCheckBox[2].setChecked(false);
                    	  componentCheckBox[3].setChecked(false); 
                  
                  }
                      
      			}
      			
              });
              componentCheckBox[1].setOnCheckedChangeListener(new OnCheckedChangeListener() {

      			@Override
      			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
      				// TODO Auto-generated method stub

                      if (componentCheckBox[1].isChecked() == true) 
                      {
                    	  componentCheckBox[0].setChecked(false);
                    	  componentCheckBox[2].setChecked(false);
                    	  componentCheckBox[3].setChecked(false); 
                      }
                      
      			}
      			
              });
              componentCheckBox[2].setOnCheckedChangeListener(new OnCheckedChangeListener() {

      			@Override
      			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
      				// TODO Auto-generated method stub

                      if (componentCheckBox[2].isChecked() == true) 
                      {
                    	  componentCheckBox[1].setChecked(false);
                    	  componentCheckBox[0].setChecked(false);
                    	  componentCheckBox[3].setChecked(false); 
                  }    
      			}
      			
              });
              componentCheckBox[3].setOnCheckedChangeListener(new OnCheckedChangeListener() {

      			@Override
      			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
      				// TODO Auto-generated method stub

                      if (componentCheckBox[3].isChecked() == true) 
                      {
                    	  componentCheckBox[1].setChecked(false);
                    	  componentCheckBox[2].setChecked(false);
                    	  componentCheckBox[0].setChecked(false); 
                      }
                      
      			}
      			
              });
            }
            else  if(componentCheckBox.length==3)
            {
              componentCheckBox[0].setOnCheckedChangeListener(new OnCheckedChangeListener() {

      			@Override
      			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
      				// TODO Auto-generated method stub

                      if (componentCheckBox[0].isChecked() == true) 
                      {
                    	  componentCheckBox[1].setChecked(false);
                    	  componentCheckBox[2].setChecked(false);
                    	
                      }
                      
      			}
      			
              });
              componentCheckBox[1].setOnCheckedChangeListener(new OnCheckedChangeListener() {

      			@Override
      			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
      				// TODO Auto-generated method stub

                      if (componentCheckBox[1].isChecked() == true) 
                      {
                    	  componentCheckBox[0].setChecked(false);
                    	  componentCheckBox[2].setChecked(false);
                    	  
                      }
                      
      			}
      			
              });
              componentCheckBox[2].setOnCheckedChangeListener(new OnCheckedChangeListener() {

      			@Override
      			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
      				// TODO Auto-generated method stub

                      if (componentCheckBox[2].isChecked() == true) 
                      {
                    	  componentCheckBox[1].setChecked(false);
                    	  componentCheckBox[0].setChecked(false);
                    	
                    } 
                      
      			}
      			
              });
             
            }
            else
            {
                componentCheckBox[0].setOnCheckedChangeListener(new OnCheckedChangeListener() {

        			@Override
        			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
        				// TODO Auto-generated method stub

                        if (componentCheckBox[0].isChecked() == true) 
                        {
                        	componentCheckBox[1].setChecked(false);
                      	 
                    } 
                        
        			}
        			
                });
                componentCheckBox[1].setOnCheckedChangeListener(new OnCheckedChangeListener() {

        			@Override
        			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
        				// TODO Auto-generated method stub

                        if (componentCheckBox[1].isChecked() == true) 
                        {
                        	componentCheckBox[0].setChecked(false);
                      	  
                    } 
                        
        			}
        			
                });
            }
        }
        
        else{
   		
       if(checkBoxCount==4){
           final LinearLayout encloseLayout = (LinearLayout) encloseView.findViewById(R.id.encloseLayout);
    	   View componentView1 = inflater.inflate(R.layout.checkbox_layout, null);
           final CheckBox componentCheckBox1 = (CheckBox) componentView1.findViewById(R.id.checkboxLayout);
           componentCheckBox1.setText(questionParsed[1]);
           currentLayout.addView(componentView1);

           View componentView2 = inflater.inflate(R.layout.checkbox_layout, null);
           final CheckBox componentCheckBox2 = (CheckBox) componentView2.findViewById(R.id.checkboxLayout);
           componentCheckBox2.setText(questionParsed[2]);
           currentLayout.addView(componentView2);

           View componentView3 = inflater.inflate(R.layout.checkbox_layout, null);
           final CheckBox componentCheckBox3 = (CheckBox) componentView3.findViewById(R.id.checkboxLayout);
           componentCheckBox3.setText(questionParsed[3]);
           currentLayout.addView(componentView3);

           View componentView4 = inflater.inflate(R.layout.checkbox_layout, null);
           final CheckBox componentCheckBox4 = (CheckBox) componentView4.findViewById(R.id.checkboxLayout);
           componentCheckBox4.setText(questionParsed[4]);
 
           encloseLayout.addView(componentView4);
           currentLayout.addView(encloseView);
          // currentLayout.addView(componentView4);
           
           int progress=1;
      		if(relatedType.equals("") && relatedText.equals("")){
				// NO related question asked - not adding anything else to the response
      		}else{
				addRelatedComponent(context, progress, encloseView, currentLayout, relatedType, relatedText, resultPointer);
      		//progress=4;
      		}  
      		 progress=2;
       		if(relatedType.equals("") && relatedText.equals("")){
				// NO related question asked - not adding anything else to the response
       		}else{
				addRelatedComponent(context, progress, encloseView, currentLayout, relatedType, relatedText, resultPointer);
       		//progress=4;
       		}  
           
           componentCheckBox3.setOnCheckedChangeListener(new OnCheckedChangeListener() {

   			@Override
   			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
   				// TODO Auto-generated method stub

                   if (componentCheckBox3.isChecked() == true) 
                   {	
                   	
                	   	componentCheckBox2.setChecked(false);
                       //	componentCheckBox2.setEnabled(false);
                		componentCheckBox1.setChecked(false);
                		componentCheckBox4.setChecked(false);
                     
                       int progress=1;
               		if(relatedType.equals("") && relatedText.equals("")){
   					// NO related question asked - not adding anything else to the response
               		}else{
   					addRelatedComponent(context, progress, encloseView, currentLayout, relatedType, relatedText, resultPointer);
               		//progress=4;
               		}     
               		
               }else{	
       	//	progress=4;
            	   
                   int progress=2;
           		if(relatedType.equals("") && relatedText.equals("")){
   				// NO related question asked - not adding anything else to the response
           		}else{
   				addRelatedComponent(context, progress, encloseView, currentLayout, relatedType, relatedText, resultPointer);
           		//progress=4;
           		}  
               }
                   
   			}
   			
           });
           componentCheckBox2.setOnCheckedChangeListener(new OnCheckedChangeListener() {

      			@Override
      			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
      				// TODO Auto-generated method stub

                      if (componentCheckBox2.isChecked() == true) 
                      {	
                    		componentCheckBox1.setChecked(false);
                    		componentCheckBox3.setChecked(false);
                    		componentCheckBox4.setChecked(false);
                  		
                  }
                      
      			}
      			
              });
           componentCheckBox1.setOnCheckedChangeListener(new OnCheckedChangeListener() {

     			@Override
     			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
     				// TODO Auto-generated method stub

                     if (componentCheckBox1.isChecked() == true) 
                     {	
                    	 componentCheckBox3.setChecked(false);
                 		componentCheckBox2.setChecked(false);
                 		componentCheckBox4.setChecked(false);
                 		
                 }
                     
     			}
     			
             });
           componentCheckBox4.setOnCheckedChangeListener(new OnCheckedChangeListener() {

     			@Override
     			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
     				// TODO Auto-generated method stub

                     if (componentCheckBox4.isChecked() == true) 
                     {	
                    	 componentCheckBox1.setChecked(false);
                 		componentCheckBox3.setChecked(false);
                 		componentCheckBox2.setChecked(false);
                 		
                 }
                     
     			}
     			
             });
           
       }else if(checkBoxCount==3){
           final LinearLayout encloseLayout = (LinearLayout) encloseView.findViewById(R.id.encloseLayout);
    	   View componentView1 = inflater.inflate(R.layout.checkbox_layout, null);
           final CheckBox componentCheckBox1 = (CheckBox) componentView1.findViewById(R.id.checkboxLayout);
           componentCheckBox1.setText(questionParsed[1]);
           currentLayout.addView(componentView1);
           View componentView2 = inflater.inflate(R.layout.checkbox_layout, null);
           final CheckBox componentCheckBox2 = (CheckBox) componentView2.findViewById(R.id.checkboxLayout);
           componentCheckBox2.setText(questionParsed[2]);
           currentLayout.addView(componentView2);
           
           View componentView3 = inflater.inflate(R.layout.checkbox_layout, null);
           final CheckBox componentCheckBox3 = (CheckBox) componentView3.findViewById(R.id.checkboxLayout);
           componentCheckBox3.setText(questionParsed[3]);
          // currentLayout.addView(componentView4);
           resultPointer[0]=componentCheckBox1;
           encloseLayout.addView(componentView3);
           currentLayout.addView(encloseView);
           int progress=1;
      		if(relatedType.equals("") && relatedText.equals("")){
				// NO related question asked - not adding anything else to the response
      		}else{
				addRelatedComponent(context, progress, encloseView, currentLayout, relatedType, relatedText, resultPointer);
      		//progress=4;
      		}   
      		 progress=2;
       		if(relatedType.equals("") && relatedText.equals("")){
				// NO related question asked - not adding anything else to the response
       		}else{
				addRelatedComponent(context, progress, encloseView, currentLayout, relatedType, relatedText, resultPointer);
       		//progress=4;
       		}   
           componentCheckBox3.setOnCheckedChangeListener(new OnCheckedChangeListener() {

   			@Override
   			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
   				// TODO Auto-generated method stub

                   if (componentCheckBox3.isChecked() == true) 
                   {	
                   	
               
                	   componentCheckBox2.setChecked(false);
               		  componentCheckBox1.setChecked(false);
               		

                     
                       int progress=1;
               		if(relatedType.equals("") && relatedText.equals("")){
   					// NO related question asked - not adding anything else to the response
               		}else{
   					addRelatedComponent(context, progress, encloseView, currentLayout, relatedType, relatedText, resultPointer);
               		//progress=4;
               		}     
               		
               }else{	
 
                   int progress=2;
           		if(relatedType.equals("") && relatedText.equals("")){
   				// NO related question asked - not adding anything else to the response
           		}else{
   				addRelatedComponent(context, progress, encloseView, currentLayout, relatedType, relatedText, resultPointer);
           		//progress=4;
           		}  
               }
                   
   			}
   			
           });
           componentCheckBox2.setOnCheckedChangeListener(new OnCheckedChangeListener() {

      			@Override
      			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
      				// TODO Auto-generated method stub

                      if (componentCheckBox2.isChecked() == true) 
                      {	
                    	  componentCheckBox1.setChecked(false);
                  		componentCheckBox3.setChecked(false);
                  		
                  }
                      
      			}
      			
              });
           componentCheckBox1.setOnCheckedChangeListener(new OnCheckedChangeListener() {

     			@Override
     			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
     				// TODO Auto-generated method stub

                     if (componentCheckBox1.isChecked() == true) 
                     {	
                    	 componentCheckBox3.setChecked(false);
                 		componentCheckBox2.setChecked(false);
                 		
                 }
                     
     			}
     			
             });
         
         
       }else if(checkBoxCount==2){
           final LinearLayout encloseLayout = (LinearLayout) encloseView.findViewById(R.id.encloseLayout);
    	   View componentView1 = inflater.inflate(R.layout.checkbox_layout, null);
           final CheckBox componentCheckBox1 = (CheckBox) componentView1.findViewById(R.id.checkboxLayout);
           componentCheckBox1.setText(questionParsed[1]);
           currentLayout.addView(componentView1);
           
           View componentView2 = inflater.inflate(R.layout.checkbox_layout, null);
           final CheckBox componentCheckBox2 = (CheckBox) componentView2.findViewById(R.id.checkboxLayout);
           componentCheckBox2.setText(questionParsed[2]);
           resultPointer[0]=componentCheckBox1;
        //   componentCheckBox1.setChecked(true);
    	 //  componentCheckBox2.setChecked(true);
           encloseLayout.addView(componentView2);
           currentLayout.addView(encloseView);
           int progress=1;
      		if(relatedType.equals("") && relatedText.equals("")){
				// NO related question asked - not adding anything else to the response
      		}else{
				addRelatedComponent(context, progress, encloseView, currentLayout, relatedType, relatedText, resultPointer);
      		//progress=4;
      		}   
      		 progress=2;
       		if(relatedType.equals("") && relatedText.equals("")){
				// NO related question asked - not adding anything else to the response
       		}else{
				addRelatedComponent(context, progress, encloseView, currentLayout, relatedType, relatedText, resultPointer);
       		//progress=4;
       		}   
           componentCheckBox1.setOnCheckedChangeListener(new OnCheckedChangeListener() {

   			@Override
   			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
   				// TODO Auto-generated method stub

                   if (componentCheckBox1.isChecked() == true) 
                   {	
                	   componentCheckBox2.setChecked(false);
               		
                       int progress=1;
               		if(relatedType.equals("") && relatedText.equals("")){
   					// NO related question asked - not adding anything else to the response
               		}else{
   					addRelatedComponent(context, progress, encloseView, currentLayout, relatedType, relatedText, resultPointer);
               		//progress=4;
               		}     
               		
               }else{	
            	  
            	//   componentCheckBox3.setChecked(true);
                   int progress=2;
           		if(relatedType.equals("") && relatedText.equals("")){
   				// NO related question asked - not adding anything else to the response
           		}else{
   				addRelatedComponent(context, progress, encloseView, currentLayout, relatedType, relatedText, resultPointer);
           		//progress=4;
           		}  
               }
                   
   			}
   			
           });
           componentCheckBox2.setOnCheckedChangeListener(new OnCheckedChangeListener() {

      			@Override
      			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
      				// TODO Auto-generated method stub

                      if (componentCheckBox2.isChecked() == true) 
                      {	

                    	  componentCheckBox1.setChecked(false);
                  		
                  }
                      
      			}
      			
              });
           encloseLayout.addView(componentView2);
           currentLayout.addView(encloseView);

       }
     //  return resultPointer;
        }
		return resultPointer;
       
        
      
	}
	
    private CheckBox addCheckBoxComponent(Context context, LinearLayout currentLayout, String componentQuestion){
    	LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View componentView = inflater.inflate(R.layout.checkbox_layout, null);
        
        CheckBox componentCheckBox = (CheckBox) componentView.findViewById(R.id.checkboxLayout);
        componentCheckBox.setText(componentQuestion);
        currentLayout.addView(componentView);
        
		return componentCheckBox;
    }
    public void addRelatedComponent(Context context, int progress, View encloseView, LinearLayout currentLayout, String relatedType, String relatedText, Object[] resultPointer){
    	// BELOW is the code to add title component as Related question
    	//LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //View titleView = inflater.inflate(R.layout.title_layout, null);
        //TextView titleTextView = (TextView) titleView.findViewById(R.id.titletext);
		//LinearLayout testingAdd = (LinearLayout) encloseView.findViewById(R.id.encloseLayout);
		
		// TODO - adding likert & check box as related question
		//CheckboxResult myCheckbox = new CheckboxResult();
		//myCheckbox.addCheckboxComponent(context, currentLayout, "Hello; 1;2;3");
		//RelatedLikertResult myRelatedLikert = new RelatedLikertResult();
		//myRelatedLikert.addLikertComponent(context, encloseView, "Testing Related");
		
		/*
		int count = testingAdd.getChildCount();
		for(int walk = 1; walk < count; walk++){
			testingAdd.removeViewAt(walk);
		}
		*/
        if(progress ==1){
        	//titleTextView.setText("Related Question to Bad Response");
    		//testingAdd.addView(titleView);
        	if(relatedType.equals(MainActivity.CHECKBOX_TYPE)){
        		RelatedCheckboxResult myRelatedCheckbox = new RelatedCheckboxResult();
        		myRelatedCheckbox.addCheckboxComponent(context, encloseView, relatedText, resultPointer);
        	}else if(relatedType.equals(MainActivity.CHECKBOX_TYPE1)){
            		RelatedCheckboxResult1 myRelatedCheckbox1 = new RelatedCheckboxResult1();
            		myRelatedCheckbox1.addCheckboxComponent(context, encloseView, relatedText, resultPointer);
        	}else if(relatedType.equals(MainActivity.LIKERT_TYPE)){
        		RelatedLikertResult1 myRelatedLikert1 = new RelatedLikertResult1();
        		myRelatedLikert1.addLikertComponent(context, encloseView, relatedText, resultPointer);
        	}else if(relatedType.equals(MainActivity.EDITTEXT_TYPE)){
        		RelatedEdittextResult myRelatedEdittext = new RelatedEdittextResult();
        		myRelatedEdittext.addEdittextComponent(context, encloseView, relatedText, resultPointer);
        	}
    		//RelatedLikertResult myRelatedLikert = new RelatedLikertResult();
    		//myRelatedLikert.addLikertComponent(context, encloseView, "Bad");
        }else{
        	// remove the related question
    		LinearLayout testingAdd = (LinearLayout) encloseView.findViewById(R.id.encloseLayout);
    		int count = testingAdd.getChildCount();
    		for(int walk = 1; walk < count; walk++){
    			testingAdd.removeViewAt(walk);
    		}
    		
    		//Log.d("SIZE", resultPointer.size() + "");
    		//for(int walk = 1; walk < resultPointer.size(); walk++){
    		//	resultPointer.remove(walk);
    		//}
        }
        /*
        else{
        	//titleTextView.setText("Related Question to Good Response");
    		//testingAdd.addView(titleView);
        	if(relatedType.equals(MainActivity.CHECKBOX_TYPE)){
        		RelatedCheckboxResult myRelatedCheckbox = new RelatedCheckboxResult();
        		myRelatedCheckbox.addCheckboxComponent(context, encloseView, relatedText);
        	}else if(relatedType.equals(MainActivity.LIKERT_TYPE)){
        		RelatedLikertResult myRelatedLikert = new RelatedLikertResult();
        		myRelatedLikert.addLikertComponent(context, encloseView, relatedText);
        	}
    		//RelatedLikertResult myRelatedLikert = new RelatedLikertResult();
    		//myRelatedLikert.addLikertComponent(context, encloseView, "Good");
        }
        */
    }
    
}
