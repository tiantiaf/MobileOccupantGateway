package com.example.ee579_finalproject;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.Vibrator;
import android.os.PowerManager.WakeLock;
import android.view.View;
import android.widget.Button;

public class NotificationHomePage extends Activity {
	
	private Button notificationTakeButton, notificationSnoozeButton, 
					notificationSnooze15MinButton, notificationCancelButton;
	private String surveyID;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		
		setContentView(R.layout.nofication_home);
		
		Intent intent = getIntent();
		surveyID = intent.getStringExtra("survey_id");
		
		SharedPreferences push_prefs = getApplicationContext().getSharedPreferences("PUSH_TYPE", Context.MODE_PRIVATE); // get the email saved in the preference
    	String push_type = push_prefs.getString("PUSH_TYPE", "");
        
    	int ntsurvey_ID = Integer.parseInt(surveyID);
		int ntpush_Type = Integer.parseInt(push_type);
		
		NotificationManager mgr = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
		mgr.cancel(123);
		
		
		notificationTakeButton = (Button) this.findViewById(R.id.notification_take);
		notificationSnoozeButton = (Button) this.findViewById(R.id.notification_snooze);
		notificationSnooze15MinButton = (Button) this.findViewById(R.id.notification_snooze_15min);
		notificationCancelButton = (Button) this.findViewById(R.id.notification_cancel);
		
		if (ntpush_Type == 5) {
			//notificationSnoozeButton.setEnabled(false);
			//notificationSnoozeButton.setVisibility(View.INVISIBLE);
		}
		
		Button.OnClickListener takeSurveyListener = new Button.OnClickListener(){
	        public void onClick(View v){    
	        	
	        	Intent surveyIntent = new Intent(getApplicationContext(), MainActivity.class);
	        	surveyIntent.removeExtra("survey_id");
	        	surveyIntent.putExtra("survey_id", surveyID);
	        	startActivity(surveyIntent);
	        	NotificationHomePage.this.finish();
	        }    
	  
	    };
	    
	    Button.OnClickListener snoozeSurveyListener = new Button.OnClickListener(){
	        @SuppressLint("NewApi")
			public void onClick(View v){  
	        	
	        	Intent intent1 = new Intent(getApplicationContext(), SnoozeReceiver.class);
				intent1.setAction("snooze.alarm.action");
				intent1.putExtra("survey_id", surveyID);
				
				SharedPreferences push_prefs = getApplicationContext().getSharedPreferences("PUSH_TYPE", Context.MODE_PRIVATE); // get the email saved in the preference
		    	String push_type = push_prefs.getString("PUSH_TYPE", "");
		    	SharedPreferences.Editor editor = push_prefs.edit();      
			    editor.putString("PUSH_TYPE", "5"); 
			    editor.commit(); 
				
				PendingIntent sender = PendingIntent.getBroadcast(getApplicationContext(), 0, intent1, 0);
				long firsttime  = SystemClock.elapsedRealtime();
				AlarmManager am = (AlarmManager) getApplicationContext().getSystemService(getApplicationContext().ALARM_SERVICE);
				am.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 10*1000, sender);
	        	
	        	/*
	        	SharedPreferences push_prefs = getApplicationContext().getSharedPreferences("PUSH_TYPE", Context.MODE_PRIVATE); // get the email saved in the preference
	        	String push_type = push_prefs.getString("PUSH_TYPE", "");
	            
	        	int ntsurvey_ID = Integer.parseInt(surveyID);
				int ntpush_Type = Integer.parseInt(push_type);
				System.out.println(ntsurvey_ID);
				

				if (!(ntsurvey_ID == 0)) {
					NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
					Intent notificationIntent = new Intent(getApplicationContext(), NotificationHomePage.class);
					//notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					notificationIntent.removeExtra("survey_id");
					notificationIntent.putExtra("survey_id", surveyID);
					//notification.flags |= Notification.FLAG_AUTO_CANCEL;
					//System.out.println(strntsurvey_ID);
					//System.out.println(strntsurvey_ID);
					PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0,
							notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
					
					int icon = R.drawable.ic_notif;
					String ticketText = "New survey available";
					long when = System.currentTimeMillis() + 60 * 1000;
					//Do whatever you need right here
					
					Notification notification = new Notification(icon, ticketText, when);
					PowerManager pm = (PowerManager)getSystemService(Context.POWER_SERVICE);
					
					if (ntpush_Type == 1) {
						WakeLock mWakelock = pm.newWakeLock(PowerManager.ACQUIRE_CAUSES_WAKEUP |PowerManager.SCREEN_DIM_WAKE_LOCK, "SimpleTimer");
						mWakelock.acquire();
						Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
						vibrator.vibrate(500);
						notification.defaults = Notification.DEFAULT_SOUND;
						notification.setLatestEventInfo(getApplicationContext(), "New Survey Available",
								"Tap here to do the survey!!", pendingIntent);
						//	notification.defaults=Notification.DEFAULT_VIBRATE;
						notificationManager.notify(123, notification);
						mWakelock.release();
						
					} else if (ntpush_Type == 2) {
						WakeLock mWakelock = pm.newWakeLock(PowerManager.ACQUIRE_CAUSES_WAKEUP |PowerManager.SCREEN_DIM_WAKE_LOCK, "SimpleTimer");
						mWakelock.acquire();
						Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
						vibrator.vibrate(500);
						notification.setLatestEventInfo(getApplicationContext(), "New Survey Available",
								"Tap here to do the survey!!", pendingIntent);
						
						//	notification.defaults=Notification.DEFAULT_VIBRATE;
						notificationManager.notify(123, notification);
						mWakelock.release();
						
					} else if (ntpush_Type == 3) {
						WakeLock mWakelock = pm.newWakeLock(PowerManager.ACQUIRE_CAUSES_WAKEUP |PowerManager.SCREEN_BRIGHT_WAKE_LOCK, "SimpleTimer");
						mWakelock.acquire();
						notification.setLatestEventInfo(getApplicationContext(), "New Survey Available",
								"Tap here to do the survey!!", pendingIntent);
						//	notification.defaults=Notification.DEFAULT_VIBRATE;
						notificationManager.notify(123, notification);
						mWakelock.release();
						
					}
					
				}
	        	
	    	    SharedPreferences.Editor editor = push_prefs.edit();      
	    	    editor.putString("PUSH_TYPE", Integer.toString(5)); 
	    	    editor.commit(); */
	    	    
	    	    NotificationHomePage.this.finish();
	        	
	        }    
	  
	    };
	    
	    Button.OnClickListener snoozeSurvey15MinListener = new Button.OnClickListener(){
	        @SuppressLint("NewApi")
			public void onClick(View v){  
	        	
	        	Intent intent1 = new Intent(getApplicationContext(), SnoozeReceiver.class);
				intent1.setAction("snooze.alarm.action");
				intent1.putExtra("survey_id", surveyID);
				
				SharedPreferences push_prefs = getApplicationContext().getSharedPreferences("PUSH_TYPE", Context.MODE_PRIVATE); // get the email saved in the preference
		    	String push_type = push_prefs.getString("PUSH_TYPE", "");
		    	SharedPreferences.Editor editor = push_prefs.edit();      
			    editor.putString("PUSH_TYPE", "6"); 
			    editor.commit(); 
				
				PendingIntent sender = PendingIntent.getBroadcast(getApplicationContext(), 0, intent1, 0);
				long firsttime  = SystemClock.elapsedRealtime();
				AlarmManager am = (AlarmManager) getApplicationContext().getSystemService(getApplicationContext().ALARM_SERVICE);
				am.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 30*1000, sender);
	        	
	    	    NotificationHomePage.this.finish();
	        	
	        }    
	  
	    };
	    
	    Button.OnClickListener cancelSurveyListener = new Button.OnClickListener(){
	        public void onClick(View v){    
	        	
	        	SharedPreferences push_prefs = getApplicationContext().getSharedPreferences("PUSH_TYPE", Context.MODE_PRIVATE); // get the email saved in the preference
	        	String push_type = push_prefs.getString("PUSH_TYPE", "");
	        	SharedPreferences.Editor editor = push_prefs.edit();      
	    	    editor.putString("PUSH_TYPE", "7"); 
	    	    editor.commit(); 
	        	
	        	Intent surveyIntent = new Intent(getApplicationContext(), MainActivity.class);
	        	surveyIntent.removeExtra("survey_id");
	        	surveyIntent.putExtra("survey_id", surveyID);
	        	startActivity(surveyIntent);
	        	
	        	
	        	NotificationHomePage.this.finish();
	        }    
	  
	    };
		
		notificationTakeButton.setOnClickListener(takeSurveyListener);
		notificationSnoozeButton.setOnClickListener(snoozeSurveyListener);
		notificationSnooze15MinButton.setOnClickListener(snoozeSurvey15MinListener);
		notificationCancelButton.setOnClickListener(cancelSurveyListener);
		
	}
	
	
}
