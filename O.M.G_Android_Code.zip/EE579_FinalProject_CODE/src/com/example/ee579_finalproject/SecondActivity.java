package com.example.ee579_finalproject;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Toast;

public class SecondActivity extends Activity {
    String segmentTitle = "Thermal Comfort";
    CheckBox[] componentCheck;
    String checkboxQuestion = "Which of the following do you personally adjust or control in your workspace? (check all that apply)";
    String[] componentQuestion = {"Window blinds or shades",
    							  "Operable window",
    							  "Thermostat",
    							  "Portable Heater",
    							  "Permanent Heater",
    							  "Room air-conditioning unit",
    							  "Portable fan",
    							  "Ceiling fan",
    							  "Adjustable air vent in wall or ceiling",
    							  "Adjustable floor air vent"};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_second);
		
		// get the current layout
        ScrollView secondScroll = (ScrollView)findViewById(R.id.secondScroll);
        LinearLayout currentLayout = (LinearLayout)secondScroll.findViewById(R.id.secondLayout);
        
        // add the title
        View titleView = getLayoutInflater().inflate(R.layout.title_layout, null);
        TextView titleTextView = (TextView) titleView.findViewById(R.id.titletext);
        titleTextView.setText(segmentTitle);
        currentLayout.addView(titleView);
        
        // add the question & check boxes
        View questionView = getLayoutInflater().inflate(R.layout.checkboxquestion_layout, null);
        TextView questionTextView = (TextView) questionView.findViewById(R.id.checkboxQuestion);
        questionTextView.setText(checkboxQuestion);
        currentLayout.addView(questionView);
        componentCheck = new CheckBox[componentQuestion.length];
        for(int walk = 0; walk < componentQuestion.length; walk++){
        	componentCheck[walk] = addCheckBoxComponent(currentLayout, componentQuestion[walk]);
        }
        
        // add the button
        View buttonView = getLayoutInflater().inflate(R.layout.button_layout, null);
        Button nextsubmitButton = (Button) buttonView.findViewById(R.id.nextsubmitButton);
        nextsubmitButton.setText("Next >>");
        nextsubmitButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				/*
	        	String result = "";
		        for(int walk = 0; walk < componentQuestion.length; walk++){
		        	if(componentCheck[walk].isChecked()){
		        		result += componentQuestion[walk] + "; ";
		        	}
		        }
				Toast.makeText(SecondActivity.this, result, Toast.LENGTH_LONG).show();
				*/
				
				Intent goToNextActivity = new Intent(getApplicationContext(), ThirdActivity.class);
				startActivity(goToNextActivity);
			}
		});
        currentLayout.addView(buttonView);
	}
	
    public CheckBox addCheckBoxComponent(LinearLayout currentLayout, String componentQuestion){
        View componentView = getLayoutInflater().inflate(R.layout.checkbox_layout, null);
        CheckBox componentCheckBox = (CheckBox) componentView.findViewById(R.id.checkboxLayout);
        componentCheckBox.setText(componentQuestion);
        currentLayout.addView(componentView);
		return componentCheckBox;
    }

	/*
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.second, menu);
		return true;
	}
	*/
}
