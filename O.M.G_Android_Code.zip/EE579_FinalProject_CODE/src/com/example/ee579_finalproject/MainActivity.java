package com.example.ee579_finalproject;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.entity.BasicHttpEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



import android.R.integer;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.MediaScannerConnectionClient;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings.Secure;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Application;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Toast;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN)
public class MainActivity extends Activity {
    private static final String POINT_LOCATION_KEY = "POINT_LOCATION_KEY";
    public static final String POINT_LOCATION_SURVEY = "POINT_LOCATION_SURVEY";
    
	public static final String LIKERT_TYPE = "likert";
	public static final String LIKERT_TYPE_5 = "likert5";
	public static final String BUTTON_TYPE5 = "button5";
	public static final String CHECKBOX_TYPE = "checkbox";
	public static final String CHECKBOX_TYPE1 = "checkbox1";
	public static final String CHECKBOX_TYPE2 = "checkbox2";
	public static final String CHECKBOX_TYPE3 = "checkbox3";
	public static final String CHECKBOX_TYPE4 = "checkbox4";
	public static final String CHECKBOX_TYPE5 = "checkbox5";
	public static final String EDITTEXT_TYPE = "edittext";
	public static final String EMAIL_KEY = "EMAIL_KEY";
	public static final String USERID_KEY = "USERID_KEY";
	private static final int CAMERA_REQUEST = 1888; 
	private static final int LIGHT_REQUEST = 2888; 
	private static final int TEMPERATURE_REQUEST = 3888; 
	public JSONObject myJson = null;
    public JSONObject myJsonResult = null;
    public JSONArray myResultArray = null;
    public String currentUserID = "";
    public String currentEmailID = "";
	public static String emailForService = "";
	public  String databk;
    TextView titleText;
    ImageView progressImage;
    LikertResult[] componentSeek;
    int currentSurveyID = 1;
    int id;
    
    // TODO - light sensor reading
    //SensorManager sensorManager = null;
    //Sensor lightSensor = null;
    
    // variables to handle questions
    int totalCategories = 0;
    String[] segmentTitle;
    QuestionForCategories[] segmentQuestion;
    ArrayList<Object> responsePointer = null;
    ArrayList<Object> responsePointer1 = null;
    public static final int MEDIA_TYPE_IMAGE = 1;
    private Uri fileUri;
    
//	private String mDeviceID;
	
    /*
    // Hard coded data for testing dynamic layout
    String segmentTitle = "Office Layout";
    String[] componentQuestion = {"How satisfied are you with the amount of space available for individual work and storage?", 
    							  "How satisfied are you with the level of visual privacy?", 
    							  "How satisfied are you with ease of interaction with co-workers?", 
    							  "Overall, does the office layout enhance or interfere with your ability to get your job done?"};
	*/
    
    private Object addComponent(String typeValue, String textValue, LinearLayout currentLayout, String relatedType, String relatedText){
    	if(typeValue.equals(LIKERT_TYPE)){
    		// add the Likert scale
    		View encloseView = getLayoutInflater().inflate(R.layout.enclose_layout, null);
    		LikertResult myLikert = new LikertResult();
    		Object[] resultSeekValue = myLikert.addLikertComponent(this, encloseView, currentLayout, textValue, relatedType, relatedText);
        	return resultSeekValue;
    	}
    	
    	//	Tiantian's code added here
    	else if(typeValue.equals(LIKERT_TYPE_5)){
    		// add the Likert scale
    		View encloseView = getLayoutInflater().inflate(R.layout.enclose_layout, null);
    		LikertResult5 myLikert = new LikertResult5();
    		Object[] resultSeekValue = myLikert.addLikertComponent(this, encloseView, currentLayout, textValue, relatedType, relatedText);
        	return resultSeekValue;
    	}
    	
    	else if(typeValue.equals(BUTTON_TYPE5)){
    		// add the Button choice
    		ButtonResult myButton = new ButtonResult();
    		Button[] resultButtonValue = myButton.addButtonComponents(this, currentLayout, textValue);
        	return resultButtonValue;
    	}
    	
    	else if(typeValue.equals(CHECKBOX_TYPE)){
    		CheckboxResult myCheckbox = new CheckboxResult();
    		CheckBox[] resultCheckValue = myCheckbox.addCheckboxComponent(this, currentLayout, textValue);
        	return resultCheckValue;
    	}else if(typeValue.equals(EDITTEXT_TYPE)){
    		EdittextResult myEdittext = new EdittextResult();
    		EditText resultEdittext = myEdittext.addEdittextComponent(this, currentLayout, textValue);
    		return resultEdittext;
    	}else if(typeValue.equals(CHECKBOX_TYPE1)){
    		CheckboxResult1 myCheckbox1 = new CheckboxResult1();
    		CheckBox[] resultCheckValue1 = myCheckbox1.addCheckboxComponent(this, currentLayout, textValue);
        	return resultCheckValue1;
    	}else if(typeValue.equals(CHECKBOX_TYPE2)){
    		View encloseView = getLayoutInflater().inflate(R.layout.enclose_layout, null);
    		CheckboxResult2 myCheckbox2 = new CheckboxResult2();
    		Object[] resultCheckValue2 = myCheckbox2.addCheckboxComponent(this, encloseView, currentLayout, textValue, relatedType, relatedText);
        	return resultCheckValue2;
    	}else if(typeValue.equals(CHECKBOX_TYPE3)){
    		View encloseView = getLayoutInflater().inflate(R.layout.enclose_layout, null);
    		CheckboxResult3 myCheckbox3 = new CheckboxResult3();
    		Object[] resultCheckValue3 = myCheckbox3.addCheckboxComponent(this, encloseView, currentLayout, textValue, relatedType, relatedText);
        	return resultCheckValue3;
    	}else if(typeValue.equals(CHECKBOX_TYPE4)){
    		View encloseView = getLayoutInflater().inflate(R.layout.enclose_layout, null);
    		CheckboxResult4 myCheckbox4 = new CheckboxResult4();
    		Object[] resultCheckValue4 = myCheckbox4.addCheckboxComponent(this, encloseView, currentLayout, textValue, relatedType, relatedText);
        	return resultCheckValue4;
    	}else if(typeValue.equals(CHECKBOX_TYPE5)){
    		View encloseView = getLayoutInflater().inflate(R.layout.enclose_layout, null);
    		CheckboxResult5 myCheckbox5 = new CheckboxResult5();
    		Object[] resultCheckValue5 = myCheckbox5.addCheckboxComponent(this, encloseView, currentLayout, textValue, relatedType, relatedText);
        	return resultCheckValue5;
    	}
		return null;    	
    }
        

    private void updateScreenforDemo(String resultString){
    	// get the current layout
        ScrollView mainScroll = (ScrollView)findViewById(R.id.mainScroll);
        final LinearLayout currentLayout = (LinearLayout)mainScroll.findViewById(R.id.mainLayout);
        
        // remove the current entry before updating screen
    	currentLayout.removeAllViews();
        
        // add the category title
        View titleView = getLayoutInflater().inflate(R.layout.title_layout, null);
        TextView titleTextView = (TextView) titleView.findViewById(R.id.titletext);
        titleTextView.setText("Demo Mode");
        currentLayout.addView(titleView);
        
        // add the application logo
        View logoimageView = getLayoutInflater().inflate(R.layout.imageview_layout, null);
        ImageView logoView = (ImageView) logoimageView.findViewById(R.id.imageviewLayout);
        logoView.setImageResource(R.drawable.submit_logo);
        logoView.setPadding(0, 25, 0, 25);
        //logoView.setGravity(Gravity.CENTER);
        currentLayout.addView(logoView);
        
        // add the description text
        View describetextView = getLayoutInflater().inflate(R.layout.textview_layout, null);
        TextView messageText = (TextView) describetextView.findViewById(R.id.textviewLayout);
        messageText.setText("Please select one of the following location to start the survey demo.");
        messageText.setGravity(Gravity.CENTER);
        messageText.setPadding(100, 10, 100, 10);
        currentLayout.addView(describetextView);
        
 		try{
 			// get & parse the JSON
 			String tempStr = "";
 			JSONObject myJson = new JSONObject(resultString);
 			JSONArray surveyJsonArray = myJson.getJSONArray("data");
 			
 			// add the survey location& ID to the Proximity Alert
			for(int walk = 0; walk < surveyJsonArray.length(); walk++){
				tempStr = "";
				JSONObject elementJson = surveyJsonArray.getJSONObject(walk);
				final String mySurveyID = elementJson.getString("survey_id");
				String[] mySurveyLongLat = elementJson.getString("geodata").split(",");

				// create the button text
				// tempStr += "*" + mySurveyID + "*\n";
				tempStr += "Location: " + mySurveyLongLat[0] + ", ";
				tempStr += mySurveyLongLat[1] + "";
				
				// add Demo ID text
		        View idtextView = getLayoutInflater().inflate(R.layout.textview_layout, null);
		        TextView idText = (TextView) idtextView.findViewById(R.id.textviewLayout);
		        idText.setText("Survey ID : " + mySurveyID);
		        idText.setGravity(Gravity.CENTER);
		        idText.setPadding(0, 40, 0, 0);
		        currentLayout.addView(idtextView);
				
		        // add the Demo Button
		        View buttonView = getLayoutInflater().inflate(R.layout.demobutton_layout, null);
		        Button demoButton = (Button) buttonView.findViewById(R.id.nextsubmitButton);
		        demoButton.setText(tempStr);
		        demoButton.setPadding(0, 0, 0, 0);
		        demoButton.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						notificationDemo(mySurveyID);
					}
				});
		        currentLayout.addView(buttonView);
			}
			
			// add no survey Demo text
	        View idtextView = getLayoutInflater().inflate(R.layout.textview_layout, null);
	        TextView idText = (TextView) idtextView.findViewById(R.id.textviewLayout);
	        idText.setText("Press the following button to display the no survey screen");
	        idText.setGravity(Gravity.CENTER);
	        idText.setPadding(0, 40, 0, 0);
	        currentLayout.addView(idtextView);
			
	        // add the no survey Demo Button
	        View buttonView = getLayoutInflater().inflate(R.layout.demobutton_layout, null);
	        Button demoButton = (Button) buttonView.findViewById(R.id.nextsubmitButton);
	        demoButton.setText("No Survey Screen");
	        demoButton.setPadding(0, 0, 0, 0);
	        demoButton.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					totalCategories = 0;
					updateScreen(0);
				}
			});
	        currentLayout.addView(buttonView);
 		}catch(Exception e){
 			e.printStackTrace();
 		}
    }

	private void notificationDemo(String demoSurveyID){
		try {
			Thread.sleep(10000);
			Integer.parseInt("10");
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	//	new HttpGetTask().execute();
	//	int i=databk.indexOf(":\"");
	//	strntsurvey_ID=databk.substring(i+2,i+3);
    	// Notification feature
	//	ntsurvey_ID=Integer.parseInt(strntsurvey_ID);
	//	if(ntsurvey_ID==0){
    	Intent openMainIntent = new Intent(this, MainActivity.class);
    	openMainIntent.putExtra(POINT_LOCATION_KEY, "Location"); // Put the location on the intent
    	openMainIntent.putExtra(POINT_LOCATION_SURVEY, demoSurveyID); // Put the survey ID on the intent
    	PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, openMainIntent, PendingIntent.FLAG_ONE_SHOT);

    	// Build notification
    	Bitmap myIcon = BitmapFactory.decodeResource(this.getResources(), R.drawable.ic_launcher);
    	Notification myNotification = new Notification.Builder(this)
	        .setContentTitle("New survey is available")
	        //.setContentText("")
	        .setContentIntent(pendingIntent)
	        .setTicker("New survey is available")
	        .setLargeIcon(myIcon)
	        .setAutoCancel(true)
	        .setSmallIcon(R.drawable.ic_notif).build();
	        //.addAction(0, "Open", pendingIntent)
	        //.addAction(0, "Ignore", pendingIntent)
	        //.addAction(0, "Snooze", pendingIntent).build();
    	NotificationManager notificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
    
    	// Hide the notification after its selected
    	myNotification.defaults |= Notification.DEFAULT_ALL;
    	//myNotification.flags |= Notification.FLAG_AUTO_CANCEL;
    	notificationManager.notify(0, myNotification);
	//	}
    }
    
	
    // Request survey location & ID to the server
 	private class QueryLocation extends AsyncTask<String, Void, String> {
		private ProgressDialog loadingDialog;
 		
 		protected void onPreExecute (){
 			loadingDialog = ProgressDialog.show(MainActivity.this, "Loading the Survey Data", "Please Wait...");
 		}
 		
 		@Override
 		protected String doInBackground(String... inputString) {
 			// request music from Servlet
         	String resultString = new String();    
         	try{
         		int TIMEOUT_MILLISEC = 10000;
         		HttpParams httpParams = new BasicHttpParams(); 
         		HttpConnectionParams.setConnectionTimeout(httpParams, TIMEOUT_MILLISEC); 
         		HttpConnectionParams.setSoTimeout(httpParams, TIMEOUT_MILLISEC);
         		HttpClient client = getThreadSafeClient();
         		HttpGet request = new HttpGet(inputString[0]);
 	        	//client.execute(request);
 	        		
 	        	HttpResponse response = client.execute(request); 
 	        	HttpEntity he = response.getEntity();
 	        	InputStream is = he.getContent();
 	        	BufferedReader br = new BufferedReader(new InputStreamReader(is));
 	        	resultString = br.readLine();
 	        	response.getEntity().consumeContent();
 	        	is.close();
 
         	}catch(Exception e){
         		e.printStackTrace();
         	}
         	
         	return resultString;
 		}
 		
 		@Override
 		protected void onPostExecute(String resultString) {
 			loadingDialog.dismiss();
 			updateScreenforDemo(resultString);
            
 		}
 	}
    
    private void updateScreenforSubmission(){
    	// get the current layout
        ScrollView mainScroll = (ScrollView)findViewById(R.id.mainScroll);
        final LinearLayout currentLayout = (LinearLayout)mainScroll.findViewById(R.id.mainLayout);
        
        // remove the current entry before updating screen
    	currentLayout.removeAllViews();
        
        // add the category title
        View titleView = getLayoutInflater().inflate(R.layout.title_layout, null);
        TextView titleTextView = (TextView) titleView.findViewById(R.id.titletext);
        titleTextView.setText("Thank you");
        currentLayout.addView(titleView);
        
        // add the application logo
        View logoimageView = getLayoutInflater().inflate(R.layout.imageview_layout, null);
        ImageView logoView = (ImageView) logoimageView.findViewById(R.id.imageviewLayout);
        logoView.setImageResource(R.drawable.submit_logo);
        logoView.setPadding(0, 175, 0, 25);
        //logoView.setGravity(Gravity.CENTER);
        currentLayout.addView(logoView);
        
        // add the description text
        View describetextView = getLayoutInflater().inflate(R.layout.textview_layout, null);
        TextView messageText = (TextView) describetextView.findViewById(R.id.textviewLayout);
        messageText.setText("You response has been recorded.\nThank you for you participation.");
        messageText.setGravity(Gravity.CENTER);
        messageText.setPadding(100, 10, 100, 10);
        currentLayout.addView(describetextView);
        
    }
    
    private void updateScreenforEmail(){
    	// get the current layout
        ScrollView mainScroll = (ScrollView)findViewById(R.id.mainScroll);
        final LinearLayout currentLayout = (LinearLayout)mainScroll.findViewById(R.id.mainLayout);
        
        // remove the current entry before updating screen
    	currentLayout.removeAllViews();
        
        // add the category title
        View titleView = getLayoutInflater().inflate(R.layout.title_layout, null);
        TextView titleTextView = (TextView) titleView.findViewById(R.id.titletext);
        titleTextView.setText("Please enter your email address");
        currentLayout.addView(titleView);
        
        // add the edit text
        View edittextView = getLayoutInflater().inflate(R.layout.edittext_layout, null);
        TextView commentText = (TextView) edittextView.findViewById(R.id.edittextQuestion);
        final EditText commentEdit = (EditText) edittextView.findViewById(R.id.edittextSpace);
        //commentEdit.clearFocus();
        //this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        commentText.setText("Email address: ");
        String storedEmail = retrieveEmailFromPreferences();
        if(storedEmail != ""){
        	commentEdit.setText(storedEmail);
        }        
        currentLayout.addView(edittextView);
        
        // add the button (next & submit)
        View buttonView = getLayoutInflater().inflate(R.layout.button_layout, null);
        Button submitButton = (Button) buttonView.findViewById(R.id.nextsubmitButton);
        if(storedEmail != ""){
            submitButton.setText("Change Email Address");
        }else{
        	submitButton.setText("Set Email Address");
        }
        submitButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				 String emailInput = commentEdit.getText().toString();
				 
				saveEmailInPreferences(emailInput);
				
				// hide the keyboard after user submit the email address
				((InputMethodManager) MainActivity.this.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(commentEdit.getWindowToken(), 0);
				
				// register user to the server
    			String requestTarget = "http://building-occupant-gateway.com/EE579Project/api/update_user_id.php?email=" + emailInput;
    			String requestTarget1 = "http://building-occupant-gateway.com/EE579Project/api/add_push_email.php?email=" + emailInput;
    			// TODO - get & save the user id
    			new AddEmailToServer().execute(requestTarget);
    			new FetchFromServer().execute(requestTarget1);
    			
			}
		});
        currentLayout.addView(buttonView);
        
        // add the description text
        View describetextView = getLayoutInflater().inflate(R.layout.textview_layout, null);
        TextView messageText = (TextView) describetextView.findViewById(R.id.textviewLayout);
        messageText.setText("NOTE: We collect your email to generate a unique user ID for every survey respondent. Please be advised that your email address will be kept confidential.");
        messageText.setGravity(Gravity.CENTER);
        messageText.setPadding(100, 10, 100, 10);
        currentLayout.addView(describetextView);
    }
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {  
    	/*
    	if (requestCode == CAMERA_REQUEST) {
            if (resultCode == RESULT_OK) {
                // Image captured and saved to fileUri specified in the Intent
                Toast.makeText(this, "Image saved to:\n" + data.getData(), Toast.LENGTH_LONG).show();
            } else if (resultCode == RESULT_CANCELED) {
                // User cancelled the image capture
            } else {
                // Image capture failed, advise user
            }
        }
        */

    	if(data == null){
            Toast.makeText(this, "Data is NULL", Toast.LENGTH_LONG).show();
    	}
    	
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK && data != null) { 
            //Toast.makeText(this, "Image saved to:\n" + data.getData(), Toast.LENGTH_LONG).show();
            Bitmap photo = (Bitmap) data.getExtras().get("data"); 
            //storePhoto(photo);
            writeFileToInternalStorage(this, photo);
            //imageView.setImageBitmap(photo);
			//Intent intent = new Intent(MainActivity.this, ImageDisplayActivity.class);
			//intent.putExtra("data", photo);
			//startActivity(intent); 
        } else if (requestCode == LIGHT_REQUEST && resultCode == RESULT_OK) {  
        	String readingValue = data.getExtras().getString("lightValue");
        	Toast.makeText(this, "Receive result from light sensor; value = " + readingValue, Toast.LENGTH_LONG).show();
        	
        	try {
				// building JSON response
	    	    JSONObject tempObj = new JSONObject();
				tempObj.put("question_id", "0");
				tempObj.put("related_question_id", "-1");
				tempObj.put("question_type", "s");
				tempObj.put("response", readingValue);
	    	    myResultArray.put(tempObj);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
    } 
    
    public void storePhoto(Bitmap myBitmap){
    	String fileName = Long.toString(System.currentTimeMillis()) + ".jpg";
    	String path = Environment.getExternalStorageDirectory().toString();
    	OutputStream fOut = null;
    	File file = new File(path, fileName);
    	try {
			fOut = new FileOutputStream(file);
	    	myBitmap.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
	    	
	    	fOut.flush();
	    	fOut.close();

	    	String imageURL = MediaStore.Images.Media.insertImage(getContentResolver(), file.getAbsolutePath(), file.getName(), file.getName());
	    	Toast.makeText(this, "URL: " + imageURL, Toast.LENGTH_LONG).show();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    /* // TODO - PLEASE CHECK
    public static void scanFile(Context context, String path, String mimeType ) {
        Client client = new Client(path, mimeType);
        MediaScannerConnection connection = new MediaScannerConnection(context, client);
        client.connection = connection;
        connection.connect();
    }

    private static final class Client implements MediaScannerConnectionClient {
        private final String path;
        private final String mimeType;
        MediaScannerConnection connection;

        public Client(String path, String mimeType) {
            this.path = path;
            this.mimeType = mimeType;
        }

        @Override
        public void onMediaScannerConnected() {
            connection.scanFile(path, mimeType);
        }

        @Override
        public void onScanCompleted(String path, Uri uri) {
            connection.disconnect();

    }
    */
    
    /*
    public File bitmapToFile(Bitmap bmp){
    	try
    	{
    		int size;
    		ByteArrayOutputStream bos = new ByteArrayOutputStream(size);
    		bmp.compress(Bitmap.CompressFormat.PNG, 80, bos);
    		byte[] bArr = bos.toByteArray();
    		bos.flush();
    		bos.close();
     
    		FileOutputStream fos = openFileOutput("mdroid.png", Context.MODE_WORLD_WRITEABLE);
    		fos.write(bArr);
    		fos.flush();
    		fos.close();
     
    		File mFile= new File(getFilesDir().getAbsolutePath(), "mdroid.png");
    
    		return mFile;
    	}catch (FileNotFoundException e){
    		e.printStackTrace();
    		return null;
    	}catch (IOException e){
    		e.printStackTrace();
    		return null;
    	}
    }
    */
    
    public void writeFileToInternalStorage(Context context, Bitmap outputImage) {
        String fileName = Long.toString(System.currentTimeMillis()) + ".jpg";

        FileOutputStream fos = null;
		try {
			fos = context.openFileOutput(fileName, Context.MODE_WORLD_WRITEABLE);
	        boolean status = outputImage.compress(CompressFormat.JPEG, 90, fos);
	        if(status == true){
	        	Toast.makeText(context, "Photo already saved.", Toast.LENGTH_LONG).show();
	        }else{
	        	Toast.makeText(context, "Photo CANNOT be saved.", Toast.LENGTH_LONG).show();
	        }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    private void activateLightSensor(){
    	Intent lightIntent = new Intent(MainActivity.this, LightActivity.class);
    	startActivityForResult(lightIntent, LIGHT_REQUEST);
    }
    private void activateTemperatureSensor(){
    	Intent temperatureIntent = new Intent(MainActivity.this, TemperatureActivity.class);
    	startActivityForResult(temperatureIntent, TEMPERATURE_REQUEST);
    }
    	
    private void updateScreen(final int currentIteration){
    	// get the current layout
        ScrollView mainScroll = (ScrollView)findViewById(R.id.mainScroll);
        final LinearLayout currentLayout = (LinearLayout)mainScroll.findViewById(R.id.mainLayout);
        
        // remove the current entry before updating screen
    	currentLayout.removeAllViews();
        
        if(totalCategories <= 0){
        	// don't have survey for current session - add the category title
            View titleView = getLayoutInflater().inflate(R.layout.title_layout, null);
            TextView titleTextView = (TextView) titleView.findViewById(R.id.titletext);
            titleTextView.setText("There is no survey associated to your location.");
            currentLayout.addView(titleView);
            
            // add the application logo
            View logoimageView = getLayoutInflater().inflate(R.layout.imageview_layout, null);
            ImageView logoView = (ImageView) logoimageView.findViewById(R.id.imageviewLayout);
            logoView.setImageResource(R.drawable.submit_logo);
            logoView.setPadding(0, 175, 0, 25);
            //logoView.setGravity(Gravity.CENTER);
            currentLayout.addView(logoView);
            
            // print message
            View messageView = getLayoutInflater().inflate(R.layout.message_layout, null);
            TextView messageTextView = (TextView) messageView.findViewById(R.id.messageLayoutTextView);
            messageTextView.setText("There is no survey associated to your location.\nPlease check back later.");
            messageTextView.setGravity(Gravity.CENTER);
            currentLayout.addView(messageView);
        	return;
        }
        
        if(currentIteration <= totalCategories - 1){
        	// add the category title
	        View titleView = getLayoutInflater().inflate(R.layout.title_layout, null);
	        TextView titleTextView = (TextView) titleView.findViewById(R.id.titletext);
	        titleTextView.setText(segmentTitle[currentIteration]);
	        currentLayout.addView(titleView);
	        
	        // add the question components (all question for the specified category)
			Iterator<String> typeIter = segmentQuestion[currentIteration].questionType.iterator();
			Iterator<String> textIter = segmentQuestion[currentIteration].questionText.iterator();
			Iterator<String> relatedTypeIter = segmentQuestion[currentIteration].relatedType.iterator();
			Iterator<String> relatedTextIter = segmentQuestion[currentIteration].relatedText.iterator();
			while(typeIter.hasNext())
			{
			    String typeValue = typeIter.next();
			    String textValue = textIter.next();
			    String relatedType = relatedTypeIter.next();
			    String relatedText = relatedTextIter.next();
				Object pointerToResult = addComponent(typeValue, textValue, currentLayout, relatedType, relatedText);
				responsePointer.add(pointerToResult);
			}
        }else{
        	// add the category title
	        View titleView = getLayoutInflater().inflate(R.layout.title_layout, null);
	        TextView titleTextView = (TextView) titleView.findViewById(R.id.titletext);
	        titleTextView.setText("Submit the Response");
	        currentLayout.addView(titleView);
        }

        /*
        // add the Likert scale
        View encloseView = null;
        View middleView = null;
        componentSeek = new LikertResult[componentQuestion.length];
        for(int walk = 0; walk < componentQuestion.length; walk++){
            encloseView = getLayoutInflater().inflate(R.layout.enclose_layout, null);
            
        	componentSeek[walk] = new LikertResult(); // NOTE: search why need new?
        	componentSeek[walk].addLikertComponent(this, encloseView, currentLayout, componentQuestion[walk]);
        	//componentSeek[walk] = addLikertComponent(currentLayout, componentQuestion[walk]);
        }
        */
        
        // add the button (next & submit)
        View buttonView = getLayoutInflater().inflate(R.layout.button_layout, null);
        Button nextsubmitButton = (Button) buttonView.findViewById(R.id.nextsubmitButton);
        View cameraButtonView = getLayoutInflater().inflate(R.layout.button_layout, null);
        Button cameraButton = (Button) cameraButtonView.findViewById(R.id.nextsubmitButton);
        View TButtonView = getLayoutInflater().inflate(R.layout.button_layout, null);
        Button TButton = (Button) TButtonView.findViewById(R.id.nextsubmitButton);
        View lightButtonView = getLayoutInflater().inflate(R.layout.button_layout, null);
        Button lightButton = (Button) lightButtonView.findViewById(R.id.nextsubmitButton);
        
        if(currentIteration >= totalCategories){
        	// print LIGHT SENSOR message at the screen
        	/*
            View lightMessageView = getLayoutInflater().inflate(R.layout.textview_layout, null);
            
            TextView lightMessageText = (TextView) lightMessageView.findViewById(R.id.textviewLayout);
            
            lightMessageText.setText("You can press the \"light sensor\" button below to provide us ambience light condition sensor reading.");
            lightMessageText.setGravity(Gravity.CENTER);
            lightMessageText.setPadding(100, 10, 100, 10);
            currentLayout.addView(lightMessageView);
            
            // add light sensor button
            lightButton.setText("Light Sensor");
            lightButton.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					activateLightSensor();
				}
			});
            currentLayout.addView(lightButtonView);*/
        	/*
           
            View TMessageView = getLayoutInflater().inflate(R.layout.textview_layout, null);
            TextView TMessageText = (TextView) TMessageView.findViewById(R.id.textviewLayout);
            TMessageText.setText("You can press the \"temperature sensor\" button below to provide us temperature reading.");
            TMessageText.setGravity(Gravity.CENTER);
            TMessageText.setPadding(100, 10, 100, 10);
            currentLayout.addView(TMessageView);
            
            // add light sensor button
            TButton.setText("Temperature Sensor");
            TButton.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					activateTemperatureSensor();
				}
			});
            currentLayout.addView(TButtonView);*/
            
        	// print CAMERA message at the screen
            View messageView = getLayoutInflater().inflate(R.layout.textview_layout, null);
            TextView messageText = (TextView) messageView.findViewById(R.id.textviewLayout);
            messageText.setText("You can press the \"camera\" button below to provide us photo feedback.");
            messageText.setGravity(Gravity.CENTER);
            messageText.setPadding(100, 10, 100, 10);
            currentLayout.addView(messageView);
            
            // add camera button
            cameraButton.setText("Camera");
            cameraButton.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					activateCamera();
				}
			});
            currentLayout.addView(cameraButtonView);
            
        	// print SUBMIT message at the screen
            View submitMessageView = getLayoutInflater().inflate(R.layout.textview_layout, null);
            TextView submitMessageText = (TextView) submitMessageView.findViewById(R.id.textviewLayout);
            submitMessageText.setText("you can press \"submit\" button below to submit your survey response.");
            submitMessageText.setGravity(Gravity.CENTER);
            submitMessageText.setPadding(100, 10, 100, 10);
            currentLayout.addView(submitMessageView);
            
            // add submit button
        	nextsubmitButton.setText("Submit");
			Toast.makeText(this, "Thank you for your participation!", Toast.LENGTH_LONG).show();
        }else{
        	nextsubmitButton.setText("Submit");
        }
        nextsubmitButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				
		        if(currentIteration >= totalCategories){
		        	// TODO - last question answered (submit the answer to server)
					//Intent goToResultActivity = new Intent(getApplicationContext(), ForthActivity.class);
					//startActivity(goToResultActivity);
					//totalCategories = 0;
		        	
		        	// Encapsulate the JSON array inside JSON object
		    		try{
						myJsonResult.put("result", myResultArray);
					}catch (JSONException e){
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		    		
		    		// stop the light sensor activity
		        	// sensorManager.unregisterListener(lightSensorEventListener);
		    		
		    		// send the response to the server
					String strToSent = myJsonResult.toString();
					Log.d("JSONresult", strToSent);
					new SendToServer().execute(strToSent);
		        }else{
		        	// get the response first
		    		Iterator<String> typeIter = segmentQuestion[currentIteration].questionType.iterator();
		    		Iterator<String> IDIter = segmentQuestion[currentIteration].questionID.iterator();
		    		Iterator<String> optionIDIter = segmentQuestion[currentIteration].optionID.iterator();
		    		Iterator<String> relatedTypeIter = segmentQuestion[currentIteration].relatedType.iterator();
		    		Iterator<String> relatedIDIter = segmentQuestion[currentIteration].relatedID.iterator();
		    		Iterator<String> relatedOptionIDIter = segmentQuestion[currentIteration].relatedOptionID.iterator();
		    		Iterator<Object> responseIter = responsePointer.iterator();
		    		
		    		//String tempResult = "";
		    		while(typeIter.hasNext())
		    		{
		    			String currentType = typeIter.next();
		    			//Log.d("TYPE", currentType);
		    			if(currentType.equals(LIKERT_TYPE)){
		    				Object[] seekResultArray = (Object[]) responseIter.next();
		    				//Iterator<Object> seekResultIter = seekResultArray.iterator();
		    			    int	a=seekResultArray.length;
		    				//while(seekResultIter.hasNext()){
	    					SeekBar seekResult = (SeekBar) seekResultArray[0];
		    				int seekValue = seekResult.getProgress();
		    				boolean seekEnable = seekResult.isEnabled();
		    				optionIDIter.next();
		    				
				    	    try {
			    				// building JSON response
					    	    JSONObject tempObj = new JSONObject();
								tempObj.put("question_id", IDIter.next());
								tempObj.put("related_question_id", "-1");
								tempObj.put("question_type", "l");
								
								if(seekEnable == true){
									tempObj.put("response", seekValue);
								}else{
									tempObj.put("response", "999");
								}
								
					    	    myResultArray.put(tempObj);
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					    	 
				    	    // get the related response
				    	    String currentRelatedType = relatedTypeIter.next();
				    	    String currentRelatedID = relatedIDIter.next();
				    	    String currentRelatedOptionID = relatedOptionIDIter.next();
				    	    if(currentRelatedType.equals(CHECKBOX_TYPE) && seekResultArray.length > 1 && seekValue != 3){
			    				String[] resultOptionId = currentRelatedOptionID.split(";");
			    				for(int walk = 1; walk < seekResultArray.length; walk++){			    	    		
			    					CheckBox relatedCheck = (CheckBox) seekResultArray[walk];
				    	    		if(relatedCheck.isChecked()){
				    					//tempResult += resultOptionId[walk] + ", ";
							    	    try {
						    				// building JSON response
								    	    JSONObject tempObj = new JSONObject();
											tempObj.put("question_id", "-1");
											tempObj.put("related_question_id", currentRelatedID);
											tempObj.put("question_type", "rs");
											tempObj.put("response", "o_" + resultOptionId[walk - 1]);
								    	    myResultArray.put(tempObj);
										} catch (JSONException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
				    	    		}
				    	    	}
				    	    }else if(currentRelatedType.equals(CHECKBOX_TYPE1) && seekResultArray.length > 1 && seekValue != 3){
			    				String[] resultOptionId = currentRelatedOptionID.split(";");
			    				for(int walk = 1; walk < seekResultArray.length; walk++){			    	    		
			    					CheckBox relatedCheck = (CheckBox) seekResultArray[walk];
				    	    		if(relatedCheck.isChecked()){
				    					//tempResult += resultOptionId[walk] + ", ";
							    	    try {
						    				// building JSON response
								    	    JSONObject tempObj = new JSONObject();
											tempObj.put("question_id", "-1");
											tempObj.put("related_question_id", currentRelatedID);
											tempObj.put("question_type", "rm");
											tempObj.put("response", "o_" + resultOptionId[walk - 1]);
								    	    myResultArray.put(tempObj);
										} catch (JSONException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
				    	    		}
				    	    	}
				    	    }else if(currentRelatedType.equals(LIKERT_TYPE) && seekResultArray.length > 1 && seekValue != 3){
		    					SeekBar relatedSeekResult = (SeekBar) seekResultArray[1];
			    				int relatedSeekValue = relatedSeekResult.getProgress();
			    				boolean relatedSeekEnable = relatedSeekResult.isEnabled();
			    				
					    	    try {
				    				// building JSON response
						    	    JSONObject tempObj = new JSONObject();
									tempObj.put("question_id", "-1");
									tempObj.put("related_question_id", currentRelatedID);
									tempObj.put("question_type", "rl");
									
									if(relatedSeekEnable == true){
										tempObj.put("response", relatedSeekValue);
									}else{
										tempObj.put("response", "999");
									}
									
						    	    myResultArray.put(tempObj);
								} catch (JSONException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
				    	    }else if(currentRelatedType.equals(EDITTEXT_TYPE) && seekResultArray.length > 1 && seekValue != 3){
			    				EditText relatedEdittextResult = (EditText) seekResultArray[1];
			    				String relatedInputValue = relatedEdittextResult.getText().toString();
			    				
					    	    try {
				    				// building JSON response
						    	    JSONObject tempObj = new JSONObject();
									tempObj.put("question_id", "-1");
									tempObj.put("related_question_id", currentRelatedID);
									tempObj.put("question_type", "rt");
									tempObj.put("response", relatedInputValue);
						    	    myResultArray.put(tempObj);
								} catch (JSONException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
				    	    }
				    	    
		    			}
		    			
		    			//	Tiantian's code added here
		    			else if(currentType.equals(LIKERT_TYPE_5)){
		    				Object[] seekResultArray = (Object[]) responseIter.next();
		    				
		    			    int	a=seekResultArray.length;
		    				//while(seekResultIter.hasNext()){
	    					SeekBar seekResult = (SeekBar) seekResultArray[0];
		    				int seekValue = seekResult.getProgress();
		    				boolean seekEnable = seekResult.isEnabled();
		    				optionIDIter.next();
		    				
				    	    try {
			    				// building JSON response
					    	    JSONObject tempObj = new JSONObject();
								tempObj.put("question_id", IDIter.next());
								tempObj.put("related_question_id", "-1");
								tempObj.put("question_type", "l5");
								
								if(seekEnable == true){
									tempObj.put("response", seekValue);
								}else{
									tempObj.put("response", "999");
								}
								
					    	    myResultArray.put(tempObj);
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
					    	 
				    	    // get the related response
				    	    String currentRelatedType = relatedTypeIter.next();
				    	    String currentRelatedID = relatedIDIter.next();
				    	    String currentRelatedOptionID = relatedOptionIDIter.next();
				    	    if(currentRelatedType.equals(CHECKBOX_TYPE) && seekResultArray.length > 1 && seekValue != 3){
			    				String[] resultOptionId = currentRelatedOptionID.split(";");
			    				for(int walk = 1; walk < seekResultArray.length; walk++){			    	    		
			    					CheckBox relatedCheck = (CheckBox) seekResultArray[walk];
				    	    		if(relatedCheck.isChecked()){
				    					//tempResult += resultOptionId[walk] + ", ";
							    	    try {
						    				// building JSON response
								    	    JSONObject tempObj = new JSONObject();
											tempObj.put("question_id", "-1");
											tempObj.put("related_question_id", currentRelatedID);
											tempObj.put("question_type", "rs");
											tempObj.put("response", "o_" + resultOptionId[walk - 1]);
								    	    myResultArray.put(tempObj);
										} catch (JSONException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
				    	    		}
				    	    	}
				    	    }else if(currentRelatedType.equals(CHECKBOX_TYPE1) && seekResultArray.length > 1 && seekValue != 3){
			    				String[] resultOptionId = currentRelatedOptionID.split(";");
			    				for(int walk = 1; walk < seekResultArray.length; walk++){			    	    		
			    					CheckBox relatedCheck = (CheckBox) seekResultArray[walk];
				    	    		if(relatedCheck.isChecked()){
				    					//tempResult += resultOptionId[walk] + ", ";
							    	    try {
						    				// building JSON response
								    	    JSONObject tempObj = new JSONObject();
											tempObj.put("question_id", "-1");
											tempObj.put("related_question_id", currentRelatedID);
											tempObj.put("question_type", "rm");
											tempObj.put("response", "o_" + resultOptionId[walk - 1]);
								    	    myResultArray.put(tempObj);
										} catch (JSONException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
				    	    		}
				    	    	}
				    	    }else if(currentRelatedType.equals(LIKERT_TYPE) && seekResultArray.length > 1 && seekValue != 3){
		    					SeekBar relatedSeekResult = (SeekBar) seekResultArray[1];
			    				int relatedSeekValue = relatedSeekResult.getProgress();
			    				boolean relatedSeekEnable = relatedSeekResult.isEnabled();
			    				
					    	    try {
				    				// building JSON response
						    	    JSONObject tempObj = new JSONObject();
									tempObj.put("question_id", "-1");
									tempObj.put("related_question_id", currentRelatedID);
									tempObj.put("question_type", "rl");
									
									if(relatedSeekEnable == true){
										tempObj.put("response", relatedSeekValue);
									}else{
										tempObj.put("response", "999");
									}
									
						    	    myResultArray.put(tempObj);
								} catch (JSONException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
				    	    }else if(currentRelatedType.equals(EDITTEXT_TYPE) && seekResultArray.length > 1 && seekValue != 3){
			    				EditText relatedEdittextResult = (EditText) seekResultArray[1];
			    				String relatedInputValue = relatedEdittextResult.getText().toString();
			    				
					    	    try {
				    				// building JSON response
						    	    JSONObject tempObj = new JSONObject();
									tempObj.put("question_id", "-1");
									tempObj.put("related_question_id", currentRelatedID);
									tempObj.put("question_type", "rt");
									tempObj.put("response", relatedInputValue);
						    	    myResultArray.put(tempObj);
								} catch (JSONException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
				    	    }
				    	    
		    			}
		    			
		    			
		    			else if(currentType.equals(BUTTON_TYPE5)){
		    				String localQuestionID = IDIter.next();
		    				String rawOptionId = optionIDIter.next();
		    				String[] resultOptionId = rawOptionId.split(";");
		    				Button[] buttonResult = (Button[]) responseIter.next();
		    				int[] buttonColor = {Color.RED, Color.MAGENTA, Color.WHITE, Color.CYAN, Color.BLUE};
		    				boolean isButtonSelected = false;
		    				//tempResult += "c - " + IDIter.next() + " - ";
		    				
		    				for (int i = 0; i < buttonResult.length; i++) {
		    					Drawable background = buttonResult[i].getBackground();
			    				ColorDrawable colorDrawable = (ColorDrawable) background;
			    				buttonColor[i] = colorDrawable.getColor();
			    				if (buttonColor[i] == Color.GRAY) {
			    					isButtonSelected = true;
								}
							}
		    				
		    				
		    				
		    				if (!isButtonSelected) {
		    					try {
				    				// building JSON response
						    	    JSONObject tempObj = new JSONObject();
									tempObj.put("question_id", localQuestionID);
									tempObj.put("related_question_id", "-1");
									tempObj.put("question_type", "b5");
									tempObj.put("response", "o_" + 0 );
						    	    myResultArray.put(tempObj);
								} catch (JSONException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							} else{
								
								for(int walk = 0; walk < buttonResult.length; walk++){
									
									Log.i("BUTTON_RESULT", "Here");
									
				    				if(buttonColor[walk] != Color.GRAY){
				    					//tempResult += resultOptionId[walk] + ", ";
							    	    try {
						    				// building JSON response
							    	    	Log.i("BUTTON_RESULT", "Here");
								    	    JSONObject tempObj = new JSONObject();
											tempObj.put("question_id", localQuestionID);
											tempObj.put("related_question_id", "-1");
											tempObj.put("question_type", "b5");
											tempObj.put("response", "o_" + (walk + 1) );
								    	    myResultArray.put(tempObj);
										} catch (JSONException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
				    				}
			    				}
								
							}
		    				
		    				// related question
				    	    relatedTypeIter.next();
				    	    relatedIDIter.next();
				    	    relatedOptionIDIter.next();
		    				//tempResult += "\n";
		    			}
		    			
		    			
		    			else if(currentType.equals(CHECKBOX_TYPE)){
		    				String localQuestionID = IDIter.next();
		    				String rawOptionId = optionIDIter.next();
		    				String[] resultOptionId = rawOptionId.split(";");
		    				CheckBox[] checkResult = (CheckBox[]) responseIter.next();
		    				//tempResult += "c - " + IDIter.next() + " - ";
		    				
		    				for(int walk = 0; walk < checkResult.length; walk++){
			    				if(checkResult[walk].isChecked()){
			    					//tempResult += resultOptionId[walk] + ", ";
						    	    try {
					    				// building JSON response
							    	    JSONObject tempObj = new JSONObject();
										tempObj.put("question_id", localQuestionID);
										tempObj.put("related_question_id", "-1");
										tempObj.put("question_type", "s");
										tempObj.put("response", "o_" + resultOptionId[walk]);
							    	    myResultArray.put(tempObj);
									} catch (JSONException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
			    				}
		    				}
		    				
		    				// related question
				    	    relatedTypeIter.next();
				    	    relatedIDIter.next();
				    	    relatedOptionIDIter.next();
		    				//tempResult += "\n";
		    			}else if(currentType.equals(CHECKBOX_TYPE1)){
			    				String localQuestionID = IDIter.next();
			    				String rawOptionId = optionIDIter.next();
			    				String[] resultOptionId = rawOptionId.split(";");
			    				CheckBox[] checkResult = (CheckBox[]) responseIter.next();
			    				//tempResult += "c - " + IDIter.next() + " - ";
			    				
			    				for(int walk = 0; walk < checkResult.length; walk++){
				    				if(checkResult[walk].isChecked()){
				    					//tempResult += resultOptionId[walk] + ", ";
							    	    try {
						    				// building JSON response
								    	    JSONObject tempObj = new JSONObject();
											tempObj.put("question_id", localQuestionID);
											tempObj.put("related_question_id", "-1");
											tempObj.put("question_type", "m");
											tempObj.put("response", "o_" + resultOptionId[walk]);
								    	    myResultArray.put(tempObj);
										} catch (JSONException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
				    				}
			    				}
			    				
			    				// related question
					    	    relatedTypeIter.next();
					    	    relatedIDIter.next();
					    	    relatedOptionIDIter.next();
		    			}else if(currentType.equals(CHECKBOX_TYPE2)){
		    				String localQuestionID = IDIter.next();
		    				String rawOptionId = optionIDIter.next();
		    				String[] resultOptionId = rawOptionId.split(";");
		    				//CheckBox[] checkResult = (CheckBox[]) responseIter.next();
		    				Object[] seekResultArray1 = (Object[]) responseIter.next();
		    				//optionIDIter.next();
		    				boolean check1 = false;	
		    				//System.out.print(seekResultArray1.length);
		    				for(int walk = 1; walk < 5; walk++){
		    					CheckBox Checkbox = (CheckBox) seekResultArray1[walk];
			    				if(Checkbox.isChecked()){
			    					//tempResult += resultOptionId[walk] + ", ";
						    	    try {
					    				// building JSON response
							    	    JSONObject tempObj = new JSONObject();
										tempObj.put("question_id", localQuestionID);
										tempObj.put("related_question_id", "-1");
										tempObj.put("question_type", "s");
										tempObj.put("response", "o_" + resultOptionId[walk]);
							    	    myResultArray.put(tempObj);
							    	   
									} catch (JSONException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
			    				}
			    				
		    				}
		    				CheckBox Checkbox = (CheckBox) seekResultArray1[1];
		    				if(Checkbox.isChecked()){
		    					check1=true;
		    				}else{
		    					check1 = false;
		    				}
		    				// related question
		    			//	Object[] seekResultArray1 = (Object[]) responseIter.next();
		    				String currentRelatedType = relatedTypeIter.next();
				    	    String currentRelatedID = relatedIDIter.next();
				    	    String currentRelatedOptionID = relatedOptionIDIter.next();
				    	 //   CheckBox[] checkResult1 = (CheckBox[]) responseIter.next();
				    	  //  CheckBox[] checkResult2 = (CheckBox[]) responseIter.next();
				    	    if(currentRelatedType.equals(CHECKBOX_TYPE)&&check1&&seekResultArray1.length>4){

			    				String[] resultOptionId1 = currentRelatedOptionID.split(";");
			    				
			    				for(int walk = 6; walk < seekResultArray1.length; walk++){			    	    		
			    					CheckBox relatedCheck = (CheckBox) seekResultArray1[walk];
				    	    		if(relatedCheck.isChecked()){
				    					//tempResult += resultOptionId[walk] + ", ";
							    	    try {
						    				// building JSON response
								    	    JSONObject tempObj = new JSONObject();
											tempObj.put("question_id", "-1");
											tempObj.put("related_question_id", currentRelatedID);
											tempObj.put("question_type", "rs");
											tempObj.put("response", "o_" + resultOptionId1[walk - 1]);
								    	    myResultArray.put(tempObj);
										} catch (JSONException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
				    	    		}
			    				}
				    	    	
				    	    }else if(currentRelatedType.equals(CHECKBOX_TYPE1)&&check1&&seekResultArray1.length>4){
			    				String[] resultOptionId1 = currentRelatedOptionID.split(";");
			    				for(int walk = 6; walk < seekResultArray1.length; walk++){			    	    		
			    					CheckBox relatedCheck = (CheckBox) seekResultArray1[walk];
				    	    		if(relatedCheck.isChecked()){
				    					//tempResult += resultOptionId[walk] + ", ";
							    	    try {
						    				// building JSON response
								    	    JSONObject tempObj = new JSONObject();
											tempObj.put("question_id", "-1");
											tempObj.put("related_question_id", currentRelatedID);
											tempObj.put("question_type", "rm");
											tempObj.put("response", "o_" + resultOptionId1[walk - 1]);
								    	    myResultArray.put(tempObj);
										} catch (JSONException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
				    	    		}
			    				}
				    	    	
				    	    }else if(currentRelatedType.equals(LIKERT_TYPE)&&check1&&seekResultArray1.length>4){
		    					SeekBar relatedSeekResult = (SeekBar) seekResultArray1[6];
			    				int relatedSeekValue = relatedSeekResult.getProgress();
			    				boolean relatedSeekEnable = relatedSeekResult.isEnabled();
			    				
					    	    try {
				    				// building JSON response
						    	    JSONObject tempObj = new JSONObject();
									tempObj.put("question_id", "-1");
									tempObj.put("related_question_id", currentRelatedID);
									tempObj.put("question_type", "rl");
									
									if(relatedSeekEnable == true){
										tempObj.put("response", relatedSeekValue);
									}else{
										tempObj.put("response", "999");
									}
									
						    	    myResultArray.put(tempObj);
								} catch (JSONException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
				    	    }else if(currentRelatedType.equals(EDITTEXT_TYPE)&&check1&&seekResultArray1.length>4){
				    	    	
			    				EditText relatedEdittextResult = (EditText) seekResultArray1[6];
			    				String relatedInputValue = relatedEdittextResult.getText().toString();
			    				
					    	    try {
				    				// building JSON response
						    	    JSONObject tempObj = new JSONObject();
									tempObj.put("question_id", "-1");
									tempObj.put("related_question_id", currentRelatedID);
									tempObj.put("question_type", "rt");
									tempObj.put("response", relatedInputValue);
						    	    myResultArray.put(tempObj);
								} catch (JSONException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
				    	    
				    	    }
		    			}else if(currentType.equals(CHECKBOX_TYPE3)){
		    				String localQuestionID = IDIter.next();
		    				String rawOptionId = optionIDIter.next();
		    				String[] resultOptionId = rawOptionId.split(";");
		    				//CheckBox[] checkResult = (CheckBox[]) responseIter.next();
		    				Object[] seekResultArray1 = (Object[]) responseIter.next();
		    				//optionIDIter.next();
		    				boolean check1 = false;	
		    				//System.out.print(seekResultArray1.length);
		    				for(int walk = 1; walk < 5; walk++){
		    					CheckBox Checkbox = (CheckBox) seekResultArray1[walk];
			    				if(Checkbox.isChecked()){
			    					//tempResult += resultOptionId[walk] + ", ";
						    	    try {
					    				// building JSON response
							    	    JSONObject tempObj = new JSONObject();
										tempObj.put("question_id", localQuestionID);
										tempObj.put("related_question_id", "-1");
										tempObj.put("question_type", "s");
										tempObj.put("response", "o_" + resultOptionId[walk]);
							    	    myResultArray.put(tempObj);
							    	   
									} catch (JSONException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
			    				}
			    				
		    				}
		    				CheckBox Checkbox = (CheckBox) seekResultArray1[2];
		    				if(Checkbox.isChecked()){
		    					check1=true;
		    				}else{
		    					check1 = false;
		    				}
		    				// related question
		    			//	Object[] seekResultArray1 = (Object[]) responseIter.next();
		    				String currentRelatedType = relatedTypeIter.next();
				    	    String currentRelatedID = relatedIDIter.next();
				    	    String currentRelatedOptionID = relatedOptionIDIter.next();
				    	 //   CheckBox[] checkResult1 = (CheckBox[]) responseIter.next();
				    	  //  CheckBox[] checkResult2 = (CheckBox[]) responseIter.next();
				    	    if(currentRelatedType.equals(CHECKBOX_TYPE)&&check1&&seekResultArray1.length>4){

			    				String[] resultOptionId1 = currentRelatedOptionID.split(";");
			    				
			    				for(int walk = 6; walk < seekResultArray1.length; walk++){			    	    		
			    					CheckBox relatedCheck = (CheckBox) seekResultArray1[walk];
				    	    		if(relatedCheck.isChecked()){
				    					//tempResult += resultOptionId[walk] + ", ";
							    	    try {
						    				// building JSON response
								    	    JSONObject tempObj = new JSONObject();
											tempObj.put("question_id", "-1");
											tempObj.put("related_question_id", currentRelatedID);
											tempObj.put("question_type", "rs");
											tempObj.put("response", "o_" + resultOptionId1[walk - 1]);
								    	    myResultArray.put(tempObj);
										} catch (JSONException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
				    	    		}
			    				}
				    	    	
				    	    }else if(currentRelatedType.equals(CHECKBOX_TYPE1)&&check1&&seekResultArray1.length>4){
			    				String[] resultOptionId1 = currentRelatedOptionID.split(";");
			    				for(int walk = 6; walk < seekResultArray1.length; walk++){			    	    		
			    					CheckBox relatedCheck = (CheckBox) seekResultArray1[walk];
				    	    		if(relatedCheck.isChecked()){
				    					//tempResult += resultOptionId[walk] + ", ";
							    	    try {
						    				// building JSON response
								    	    JSONObject tempObj = new JSONObject();
											tempObj.put("question_id", "-1");
											tempObj.put("related_question_id", currentRelatedID);
											tempObj.put("question_type", "rm");
											tempObj.put("response", "o_" + resultOptionId1[walk - 1]);
								    	    myResultArray.put(tempObj);
										} catch (JSONException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
				    	    		}
			    				}
				    	    	
				    	    }else if(currentRelatedType.equals(LIKERT_TYPE)&&check1&&seekResultArray1.length>4){
		    					SeekBar relatedSeekResult = (SeekBar) seekResultArray1[6];
			    				int relatedSeekValue = relatedSeekResult.getProgress();
			    				boolean relatedSeekEnable = relatedSeekResult.isEnabled();
			    				
					    	    try {
				    				// building JSON response
						    	    JSONObject tempObj = new JSONObject();
									tempObj.put("question_id", "-1");
									tempObj.put("related_question_id", currentRelatedID);
									tempObj.put("question_type", "rl");
									
									if(relatedSeekEnable == true){
										tempObj.put("response", relatedSeekValue);
									}else{
										tempObj.put("response", "999");
									}
									
						    	    myResultArray.put(tempObj);
								} catch (JSONException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
				    	    }else if(currentRelatedType.equals(EDITTEXT_TYPE)&&check1&&seekResultArray1.length>4){
				    	    	
			    				EditText relatedEdittextResult = (EditText) seekResultArray1[6];
			    				String relatedInputValue = relatedEdittextResult.getText().toString();
			    				
					    	    try {
				    				// building JSON response
						    	    JSONObject tempObj = new JSONObject();
									tempObj.put("question_id", "-1");
									tempObj.put("related_question_id", currentRelatedID);
									tempObj.put("question_type", "rt");
									tempObj.put("response", relatedInputValue);
						    	    myResultArray.put(tempObj);
								} catch (JSONException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
				    	    
				    	    }
		    		}else if(currentType.equals(CHECKBOX_TYPE4)){
			    				String localQuestionID = IDIter.next();
			    				String rawOptionId = optionIDIter.next();
			    				String[] resultOptionId = rawOptionId.split(";");
			    				//CheckBox[] checkResult = (CheckBox[]) responseIter.next();
			    				Object[] seekResultArray1 = (Object[]) responseIter.next();
			    				//optionIDIter.next();
			    				boolean check1 = false;	
			    				//System.out.print(seekResultArray1.length);
			    				for(int walk = 1; walk < 5; walk++){
			    					CheckBox Checkbox = (CheckBox) seekResultArray1[walk];
				    				if(Checkbox.isChecked()){
				    					//tempResult += resultOptionId[walk] + ", ";
							    	    try {
						    				// building JSON response
								    	    JSONObject tempObj = new JSONObject();
											tempObj.put("question_id", localQuestionID);
											tempObj.put("related_question_id", "-1");
											tempObj.put("question_type", "s");
											tempObj.put("response", "o_" + resultOptionId[walk]);
								    	    myResultArray.put(tempObj);
								    	   
										} catch (JSONException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
				    				}
				    				
			    				}
			    				CheckBox Checkbox = (CheckBox) seekResultArray1[3];
			    				if(Checkbox.isChecked()){
			    					check1=true;
			    				}else{
			    					check1 = false;
			    				}
			    				// related question
			    			//	Object[] seekResultArray1 = (Object[]) responseIter.next();
			    				String currentRelatedType = relatedTypeIter.next();
					    	    String currentRelatedID = relatedIDIter.next();
					    	    String currentRelatedOptionID = relatedOptionIDIter.next();
					    	 //   CheckBox[] checkResult1 = (CheckBox[]) responseIter.next();
					    	  //  CheckBox[] checkResult2 = (CheckBox[]) responseIter.next();
					    	    if(currentRelatedType.equals(CHECKBOX_TYPE)&&check1&&seekResultArray1.length>4){

				    				String[] resultOptionId1 = currentRelatedOptionID.split(";");
				    				
				    				for(int walk = 6; walk < seekResultArray1.length; walk++){			    	    		
				    					CheckBox relatedCheck = (CheckBox) seekResultArray1[walk];
					    	    		if(relatedCheck.isChecked()){
					    					//tempResult += resultOptionId[walk] + ", ";
								    	    try {
							    				// building JSON response
									    	    JSONObject tempObj = new JSONObject();
												tempObj.put("question_id", "-1");
												tempObj.put("related_question_id", currentRelatedID);
												tempObj.put("question_type", "rs");
												tempObj.put("response", "o_" + resultOptionId1[walk - 1]);
									    	    myResultArray.put(tempObj);
											} catch (JSONException e) {
												// TODO Auto-generated catch block
												e.printStackTrace();
											}
					    	    		}
				    				}
					    	    	
					    	    }else if(currentRelatedType.equals(CHECKBOX_TYPE1)&&check1&&seekResultArray1.length>4){
				    				String[] resultOptionId1 = currentRelatedOptionID.split(";");
				    				for(int walk = 6; walk < seekResultArray1.length; walk++){			    	    		
				    					CheckBox relatedCheck = (CheckBox) seekResultArray1[walk];
					    	    		if(relatedCheck.isChecked()){
					    					//tempResult += resultOptionId[walk] + ", ";
								    	    try {
							    				// building JSON response
									    	    JSONObject tempObj = new JSONObject();
												tempObj.put("question_id", "-1");
												tempObj.put("related_question_id", currentRelatedID);
												tempObj.put("question_type", "rm");
												tempObj.put("response", "o_" + resultOptionId1[walk - 1]);
									    	    myResultArray.put(tempObj);
											} catch (JSONException e) {
												// TODO Auto-generated catch block
												e.printStackTrace();
											}
					    	    		}
				    				}
					    	    	
					    	    }else if(currentRelatedType.equals(LIKERT_TYPE)&&check1&&seekResultArray1.length>4){
			    					SeekBar relatedSeekResult = (SeekBar) seekResultArray1[6];
				    				int relatedSeekValue = relatedSeekResult.getProgress();
				    				boolean relatedSeekEnable = relatedSeekResult.isEnabled();
				    				
						    	    try {
					    				// building JSON response
							    	    JSONObject tempObj = new JSONObject();
										tempObj.put("question_id", "-1");
										tempObj.put("related_question_id", currentRelatedID);
										tempObj.put("question_type", "rl");
										
										if(relatedSeekEnable == true){
											tempObj.put("response", relatedSeekValue);
										}else{
											tempObj.put("response", "999");
										}
										
							    	    myResultArray.put(tempObj);
									} catch (JSONException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
					    	    }else if(currentRelatedType.equals(EDITTEXT_TYPE)&&check1&&seekResultArray1.length>4){
					    	    	
				    				EditText relatedEdittextResult = (EditText) seekResultArray1[6];
				    				String relatedInputValue = relatedEdittextResult.getText().toString();
				    				
						    	    try {
					    				// building JSON response
							    	    JSONObject tempObj = new JSONObject();
										tempObj.put("question_id", "-1");
										tempObj.put("related_question_id", currentRelatedID);
										tempObj.put("question_type", "rt");
										tempObj.put("response", relatedInputValue);
							    	    myResultArray.put(tempObj);
									} catch (JSONException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
					    	    
					    	    }
		    			} else if(currentType.equals(CHECKBOX_TYPE5)){
			    				String localQuestionID = IDIter.next();
			    				String rawOptionId = optionIDIter.next();
			    				String[] resultOptionId = rawOptionId.split(";");
			    				//CheckBox[] checkResult = (CheckBox[]) responseIter.next();
			    				Object[] seekResultArray1 = (Object[]) responseIter.next();
			    				//optionIDIter.next();
			    				boolean check1 = false;	
			    				//System.out.print(seekResultArray1.length);
			    				for(int walk = 1; walk < 5; walk++){
			    					CheckBox Checkbox = (CheckBox) seekResultArray1[walk];
				    				if(Checkbox.isChecked()){
				    					//tempResult += resultOptionId[walk] + ", ";
							    	    try {
						    				// building JSON response
								    	    JSONObject tempObj = new JSONObject();
											tempObj.put("question_id", localQuestionID);
											tempObj.put("related_question_id", "-1");
											tempObj.put("question_type", "s");
											tempObj.put("response", "o_" + resultOptionId[walk]);
								    	    myResultArray.put(tempObj);
								    	   
										} catch (JSONException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
				    				}
				    				
			    				}
			    				CheckBox Checkbox = (CheckBox) seekResultArray1[4];
			    				if(Checkbox.isChecked()){
			    					check1=true;
			    				}else{
			    					check1 = false;
			    				}
			    				// related question
			    			//	Object[] seekResultArray1 = (Object[]) responseIter.next();
			    				String currentRelatedType = relatedTypeIter.next();
					    	    String currentRelatedID = relatedIDIter.next();
					    	    String currentRelatedOptionID = relatedOptionIDIter.next();
					    	 //   CheckBox[] checkResult1 = (CheckBox[]) responseIter.next();
					    	  //  CheckBox[] checkResult2 = (CheckBox[]) responseIter.next();
					    	    if(currentRelatedType.equals(CHECKBOX_TYPE)&&check1&&seekResultArray1.length>4){

				    				String[] resultOptionId1 = currentRelatedOptionID.split(";");
				    				
				    				for(int walk = 6; walk < seekResultArray1.length; walk++){			    	    		
				    					CheckBox relatedCheck = (CheckBox) seekResultArray1[walk];
					    	    		if(relatedCheck.isChecked()){
					    					//tempResult += resultOptionId[walk] + ", ";
								    	    try {
							    				// building JSON response
									    	    JSONObject tempObj = new JSONObject();
												tempObj.put("question_id", "-1");
												tempObj.put("related_question_id", currentRelatedID);
												tempObj.put("question_type", "rs");
												tempObj.put("response", "o_" + resultOptionId1[walk - 1]);
									    	    myResultArray.put(tempObj);
											} catch (JSONException e) {
												// TODO Auto-generated catch block
												e.printStackTrace();
											}
					    	    		}
				    				}
					    	    	
					    	    }else if(currentRelatedType.equals(CHECKBOX_TYPE1)&&check1&&seekResultArray1.length>4){
				    				String[] resultOptionId1 = currentRelatedOptionID.split(";");
				    				for(int walk = 6; walk < seekResultArray1.length; walk++){			    	    		
				    					CheckBox relatedCheck = (CheckBox) seekResultArray1[walk];
					    	    		if(relatedCheck.isChecked()){
					    					//tempResult += resultOptionId[walk] + ", ";
								    	    try {
							    				// building JSON response
									    	    JSONObject tempObj = new JSONObject();
												tempObj.put("question_id", "-1");
												tempObj.put("related_question_id", currentRelatedID);
												tempObj.put("question_type", "rm");
												tempObj.put("response", "o_" + resultOptionId1[walk - 1]);
									    	    myResultArray.put(tempObj);
											} catch (JSONException e) {
												// TODO Auto-generated catch block
												e.printStackTrace();
											}
					    	    		}
				    				}
					    	    	
					    	    }else if(currentRelatedType.equals(LIKERT_TYPE)&&check1&&seekResultArray1.length>4){
			    					SeekBar relatedSeekResult = (SeekBar) seekResultArray1[6];
				    				int relatedSeekValue = relatedSeekResult.getProgress();
				    				boolean relatedSeekEnable = relatedSeekResult.isEnabled();
				    				
						    	    try {
					    				// building JSON response
							    	    JSONObject tempObj = new JSONObject();
										tempObj.put("question_id", "-1");
										tempObj.put("related_question_id", currentRelatedID);
										tempObj.put("question_type", "rl");
										
										if(relatedSeekEnable == true){
											tempObj.put("response", relatedSeekValue);
										}else{
											tempObj.put("response", "999");
										}
										
							    	    myResultArray.put(tempObj);
									} catch (JSONException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
					    	    }else if(currentRelatedType.equals(EDITTEXT_TYPE)&&check1&&seekResultArray1.length>4){
					    	    	
				    				EditText relatedEdittextResult = (EditText) seekResultArray1[6];
				    				String relatedInputValue = relatedEdittextResult.getText().toString();
				    				
						    	    try {
					    				// building JSON response
							    	    JSONObject tempObj = new JSONObject();
										tempObj.put("question_id", "-1");
										tempObj.put("related_question_id", currentRelatedID);
										tempObj.put("question_type", "rt");
										tempObj.put("response", relatedInputValue);
							    	    myResultArray.put(tempObj);
									} catch (JSONException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
					    	    
					    	    }
		    			}else if(currentType.equals(EDITTEXT_TYPE)){
		    				EditText edittextResult = (EditText) responseIter.next();
		    				String inputValue = edittextResult.getText().toString();
		    				optionIDIter.next();
		    				
				    	    try {
			    				// building JSON response
					    	    JSONObject tempObj = new JSONObject();
								tempObj.put("question_id", IDIter.next());
								tempObj.put("related_question_id", "-1");
								tempObj.put("question_type", "t");
								tempObj.put("response", inputValue);
					    	    myResultArray.put(tempObj);
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
		    				
		    				// related question
				    	    relatedTypeIter.next();
				    	    relatedIDIter.next();
				    	    relatedOptionIDIter.next();
		    				//tempResult += "\n";
		    			}
		    		}
		    		
		    		/*
		    		// TODO - PLEASE CHECK
		    		try {
						myJsonResult.put("result", myResultArray);
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		    		
		    		Log.e("JSON", myJsonResult.toString());
					Intent intent = new Intent(MainActivity.this, DisplayActivity.class);
					intent.setType("text/plain");
					intent.putExtra(android.content.Intent.EXTRA_TEXT, myJsonResult.toString());
					startActivity(intent); 
		    		*/
		    		
		        	// update the screen for next question components
					responsePointer = new ArrayList<Object>();
		        	
		        	currentLayout.removeAllViews();
		        	//updateScreen(currentIteration + 1);
		        	
		        	try{
						myJsonResult.put("result", myResultArray);
					}catch (JSONException e){
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		    		
		    		// stop the light sensor activity
		        	// sensorManager.unregisterListener(lightSensorEventListener);
		    		
		    		// send the response to the server
					String strToSent = myJsonResult.toString();
					Log.d("JSONresult", strToSent);
					new SendToServer().execute(strToSent);
					
					Toast.makeText(getApplicationContext(), "Thank you for your participation!", Toast.LENGTH_LONG).show();
					
					
		        	
		        	// TODO - record the user answer for current category
		        }


				/*
				// NOTE - way to interpret the Likert result element
				String outputValue = "";
		        for(int walk = 0; walk < componentQuestion.length; walk++){
		        	if(componentSeek[walk].likertCheckBox.isChecked()){
		        		outputValue += "Q" + walk + ": -1; ";
		        	}else{
		        		outputValue += "Q" + walk + ": " + Integer.toString(componentSeek[walk].likertSeekbar.getProgress()) + "; ";
		        	}
		        }
				Toast.makeText(MainActivity.this, outputValue, Toast.LENGTH_LONG).show();
				
				*/
		        
			}
			
			
		});
        currentLayout.addView(buttonView);
    }
    
    // light sensor listener
    SensorEventListener lightSensorEventListener = new SensorEventListener(){
    	@Override
    	public void onAccuracyChanged(Sensor sensor, int accuracy) {
    		// TODO Auto-generated method stub 
    	}
       
        @Override
        public void onSensorChanged(SensorEvent event) {
        	// TODO Auto-generated method stub
        	if(event.sensor.getType()==Sensor.TYPE_LIGHT){
        		float currentReading = event.values[0];
        		//lightMeter.setProgress((int)currentReading);
        		//textReading.setText("Current Reading: " + String.valueOf(currentReading));
        	}
        }
    };
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
		String tempSurveyID;

        mNotificationManager.cancelAll();
      
        //startService(new Intent(getBaseContext(),NotificationService.class));
		Bundle extras = getIntent().getExtras();
		//	Intent SensorService = new Intent(this,SensorService.class);
		//	this.startService(SensorService);
		
		tempSurveyID=getIntent().getStringExtra("survey_id");
		//System.out.print(tempSurveyID);
		if(tempSurveyID!=null){
			id=Integer.parseInt(tempSurveyID);
			Log.i("survey_id", tempSurveyID);
			tempSurveyID=null;
			//System.out.println(tempSurveyID);
			
			
		}else{
		
			SharedPreferences defalut_prefs = getApplicationContext().getSharedPreferences("DEFAULT_SURVEY", Context.MODE_PRIVATE); // get the email saved in the preference
	        String currentDefaulSurvey = defalut_prefs.getString("DEFAULT_SURVEY", "");
	        if(currentDefaulSurvey.length() != 0){
	        	tempSurveyID = currentDefaulSurvey;
		        id=Integer.parseInt(tempSurveyID);
		        Log.i("survey_id_default", currentDefaulSurvey);
	        }
	        
			
		}
		if (extras != null) {

			String locationSurvey = extras.getString(ProximityService.POINT_LOCATION_SURVEY);
			String locationValue = extras.getString(ProximityService.POINT_LOCATION_KEY);
			
			currentSurveyID = id;
			//Toast.makeText(this, "Location in Main: " + locationValue + " & Survey ID: " + locationSurvey, Toast.LENGTH_LONG).show();
		}else{
			// set to default survey id - FOR DEMO PURPOSE
			currentSurveyID = id;
		}

        
        
        // check if already input the email
        String userEmail = retrieveEmailFromPreferences();
        currentEmailID = retrieveEmailFromPreferences();
        currentUserID = retrieveUseridFromPreferences();
        emailForService = userEmail;
        
        if(userEmail != ""){
        	Toast.makeText(this, userEmail + ", id: " + currentUserID, Toast.LENGTH_SHORT).show();
        	
        	
        	SharedPreferences push_prefs = this.getSharedPreferences("PUSH_TYPE", Context.MODE_PRIVATE); // get the email saved in the preference
            String currentPushType = push_prefs.getString("PUSH_TYPE", "");
            Log.i("push_type", currentPushType);
            if (currentPushType.isEmpty()) {
            	SharedPreferences.Editor editor = push_prefs.edit();      
        	    editor.putString("PUSH_TYPE", "4"); 
        	    editor.commit(); 
			}
            currentPushType = push_prefs.getString("PUSH_TYPE", "");
        	// Request the server for the survey
    		try{
    			String requestTarget = "http://building-occupant-gateway.com/EE579Project/api/get_full_survey.php?survey_id=" 
    					+ currentSurveyID + "&push_id=" + currentPushType + "&email=" + userEmail;
    			new FetchFromServer().execute(requestTarget);
    		}catch(Exception e){
    			e.printStackTrace();
    		}
    		
    		
            Log.i("push_type", currentPushType);
            if (currentPushType.isEmpty()) {
            	SharedPreferences.Editor editor = push_prefs.edit();      
        	    editor.putString("PUSH_TYPE", "4"); 
        	    editor.commit(); 
			}
            currentPushType = push_prefs.getString("PUSH_TYPE", "");
            
            if (Integer.parseInt(currentPushType) == 7) {
            	SharedPreferences.Editor editor = push_prefs.edit();      
        	    editor.putString("PUSH_TYPE", "4"); 
        	    editor.commit(); 
				this.finish();
			}
        }else{
        	// Request user to input the email
            updateScreenforEmail();
        }
    }
    
    private void saveEmailInPreferences(String emailInput) {
        SharedPreferences prefs = this.getSharedPreferences("SAVEDEMAIL", Context.MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = prefs.edit();
        prefsEditor.putString(EMAIL_KEY, emailInput);
        prefsEditor.commit();
    	Toast.makeText(this, "Your email address has been set to " + emailInput, Toast.LENGTH_SHORT).show();
    }
    
    private void saveUseridInPreferences(String useridInput){
    	try {
			JSONObject userJSON = new JSONObject(useridInput);
			String userID = userJSON.getString("message");
	    	SharedPreferences prefs = this.getSharedPreferences(getClass().getSimpleName(), Context.MODE_PRIVATE);
	        SharedPreferences.Editor prefsEditor = prefs.edit();
	        prefsEditor.putString(USERID_KEY, userID);
	        prefsEditor.commit();
	    	Toast.makeText(this, "Your user id has been set to " + userID, Toast.LENGTH_SHORT).show();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}        
    }
    
    private String retrieveEmailFromPreferences() {
        SharedPreferences prefs = this.getSharedPreferences("SAVEDEMAIL", Context.MODE_PRIVATE);
        String tempEmail = new String();
        tempEmail = prefs.getString(EMAIL_KEY, "");
        return tempEmail;
    }
    
    private String retrieveUseridFromPreferences() {
        SharedPreferences prefs = this.getSharedPreferences(getClass().getSimpleName(), Context.MODE_PRIVATE);
        String tempUserid = new String();
        tempUserid = prefs.getString(USERID_KEY, "");
        return tempUserid;
    }
    
    private void removeEmailFromPreferences() {
        SharedPreferences prefs = this.getSharedPreferences("SAVEDEMAIL", Context.MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = prefs.edit();
        prefsEditor.clear();
        prefsEditor.commit();
    	Toast.makeText(this, "Your email address has been deleted.", Toast.LENGTH_SHORT).show();
    }
    
    // WEB REQUEST PART
    public static DefaultHttpClient getThreadSafeClient() {
		DefaultHttpClient client = new DefaultHttpClient();
		ClientConnectionManager mgr = client.getConnectionManager();
		HttpParams params = client.getParams();
		client = new DefaultHttpClient(new ThreadSafeClientConnManager(params, mgr.getSchemeRegistry()), params);
	
		return client;
	}
	
	private class FetchFromServer extends AsyncTask<String, Void, String> {
		private ProgressDialog loadingDialog;

		protected void onPreExecute (){
        	loadingDialog = ProgressDialog.show(MainActivity.this, "Loading the Survey Data", "Please Wait...");
		}
		
		@Override
		protected String doInBackground(String... inputString) {
			// request music from Servlet
        	String resultString = new String();

        	try{
        		int TIMEOUT_MILLISEC = 10000;
        		HttpParams httpParams = new BasicHttpParams(); 
        		HttpConnectionParams.setConnectionTimeout(httpParams, TIMEOUT_MILLISEC); 
        		HttpConnectionParams.setSoTimeout(httpParams, TIMEOUT_MILLISEC);
        		HttpClient client = getThreadSafeClient();
        		HttpGet request = new HttpGet(inputString[0]);
	        	//client.execute(request);
	        		
	        	HttpResponse response = client.execute(request); 
	        	HttpEntity he = response.getEntity();
	        	InputStream is = he.getContent();
	        	BufferedReader br = new BufferedReader(new InputStreamReader(is));
	        	resultString = br.readLine();
	        	response.getEntity().consumeContent();
	        	is.close();
	        	//notification1.start();
        	}catch(Exception e){
        		e.printStackTrace();
        	}
        	
        	return resultString;
		}

		
		@Override
		protected void onPostExecute(String resultString) {
			loadingDialog.dismiss();
    		
        	// check for no result & exception
        	JSONArray myJsonArray = null;
        	totalCategories = 0;
        	try {
        		myJson = new JSONObject(resultString);
      
        		// getting the title
				JSONObject JsonTitle = myJson.getJSONObject("survey");
				JSONObject titleInnerPart = JsonTitle.getJSONObject("data");
				String mySurveyID = titleInnerPart.getString("survey_id");
				Toast.makeText(MainActivity.this, "Survey Title: " + titleInnerPart.getString("survey_title"), Toast.LENGTH_LONG).show();
        		
        		// constructing the survey question
				JSONObject JsonMain = myJson.getJSONObject("survey_details");
				myJsonArray = JsonMain.getJSONArray("data");
	            totalCategories = myJsonArray.length();
	            segmentTitle = new String[totalCategories];
	        	segmentQuestion = new QuestionForCategories[totalCategories];
				
				for(int walk = 0; walk < myJsonArray.length(); walk++){
					JSONObject questionInstance = myJsonArray.getJSONObject(walk);
					JSONObject segmentPart1 = questionInstance.getJSONObject("segment");
		            segmentTitle[walk] = segmentPart1.getString("segment_title");
		            
		            // Determine the survey question
		        	JSONArray myQuestionArray = questionInstance.getJSONArray("segment_questions");
		            segmentQuestion[walk] = new QuestionForCategories();
		            
		            // get the survey type & question
		            for(int innerWalk = 0; innerWalk < myQuestionArray.length(); innerWalk++){
						JSONObject questionIter = myQuestionArray.getJSONObject(innerWalk);
						JSONObject myQuestion = questionIter.getJSONObject("question");
						
						//Log.d("HERE1", "HERE1");
						if(myQuestion.getString("question_type").equals("l")){
							// TYPE1 - LIKERT question type
							segmentQuestion[walk].questionType.add(LIKERT_TYPE);
				            segmentQuestion[walk].questionText.add(myQuestion.getString("question_text"));
				            segmentQuestion[walk].questionID.add(myQuestion.getString("question_id"));
				            segmentQuestion[walk].optionID.add("");
				            
				            // get the related question ======================================================== PLEASE CHECK!!!
				            JSONObject myRelated = questionIter.getJSONObject("related");
				            JSONArray myRelatedQout = myRelated.getJSONArray("relQuestion"); // TODO: NEED TO SERIALIZED so ONLY ADD once!!! VERY IMPORTANT!!!
				            
			            	int iterCount = 0;
				            if(myRelatedQout.length() <= 0){
				            	iterCount = 0;
				            }else{
				            	iterCount = 1;
				            }
							for(int relatedWalk = 0; relatedWalk < iterCount; relatedWalk++){ // TODO: change the loop if want to have more than 1 related question
								JSONObject myRelatedIter = myRelatedQout.getJSONObject(relatedWalk);
					            JSONObject myRelatedQin = myRelatedIter.getJSONObject("question");	
					            
					            if(myRelatedQin.getString("question_type").equals("rs")){
									// CHECKBOX related question type
					            	segmentQuestion[walk].relatedType.add(CHECKBOX_TYPE);
					            	String checkBoxQuestion = myRelatedQin.getString("question_text");
									String optionIDStr = "";
									
					            	// get all the check box option
									JSONObject myRelatedOption = myRelatedIter.getJSONObject("options");
									JSONArray myRelatedOptionArray = myRelatedOption.getJSONArray("data");
									for(int checkBoxWalk = 0; checkBoxWalk < myRelatedOptionArray.length(); checkBoxWalk++){
										JSONObject checkBoxIter = myRelatedOptionArray.getJSONObject(checkBoxWalk);
										checkBoxQuestion += "; " + checkBoxIter.getString("option_text");
										optionIDStr += checkBoxIter.getString("option_question_id") + "; ";
										
									} 
					            	segmentQuestion[walk].relatedText.add(checkBoxQuestion);
					            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
					            	segmentQuestion[walk].relatedOptionID.add(optionIDStr);
					            }else if(myRelatedQin.getString("question_type").equals("rm")){
										// CHECKBOX related question type
						            	segmentQuestion[walk].relatedType.add(CHECKBOX_TYPE1);
						            	String checkBoxQuestion = myRelatedQin.getString("question_text");
										String optionIDStr = "";
										
						            	// get all the check box option
										JSONObject myRelatedOption = myRelatedIter.getJSONObject("options");
										JSONArray myRelatedOptionArray = myRelatedOption.getJSONArray("data");
										for(int checkBoxWalk = 0; checkBoxWalk < myRelatedOptionArray.length(); checkBoxWalk++){
											JSONObject checkBoxIter = myRelatedOptionArray.getJSONObject(checkBoxWalk);
											checkBoxQuestion += "; " + checkBoxIter.getString("option_text");
											optionIDStr += checkBoxIter.getString("option_question_id") + "; ";
											
										} 
										
										//Log.d("HERE2", "HERE2");
										//Log.d("OPTION_ID", optionIDStr);
						            	segmentQuestion[walk].relatedText.add(checkBoxQuestion);
						            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
						            	segmentQuestion[walk].relatedOptionID.add(optionIDStr);
					            }else if(myRelatedQin.getString("question_type").equals("rl")){
					            	// TODO - related question of type LIKERT
					            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
					            	segmentQuestion[walk].relatedType.add(LIKERT_TYPE);
					            	segmentQuestion[walk].relatedText.add(myRelatedQin.getString("question_text"));
					            	segmentQuestion[walk].relatedOptionID.add("");
					            }else if(myRelatedQin.getString("question_type").equals("rt")){
					            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
					            	segmentQuestion[walk].relatedType.add(EDITTEXT_TYPE);
					            	segmentQuestion[walk].relatedText.add(myRelatedQin.getString("question_text"));
					            	segmentQuestion[walk].relatedOptionID.add("");
					            }
							}
							
							// TODO - PLEASE CHECK - escape when the related question is not there
							if(myRelatedQout.length() <= 0){
				            	segmentQuestion[walk].relatedID.add("");
				            	segmentQuestion[walk].relatedType.add("");
				            	segmentQuestion[walk].relatedText.add("");
				            	segmentQuestion[walk].relatedOptionID.add("");
							}
					
						}
						
						
						// Tiantian's Code added here
						else if(myQuestion.getString("question_type").equals("l5")){
							// TYPE1 - LIKERT question type
							segmentQuestion[walk].questionType.add(LIKERT_TYPE_5);
				            segmentQuestion[walk].questionText.add(myQuestion.getString("question_text"));
				            segmentQuestion[walk].questionID.add(myQuestion.getString("question_id"));
				            segmentQuestion[walk].optionID.add("");
				            
				            // get the related question ======================================================== PLEASE CHECK!!!
				            JSONObject myRelated = questionIter.getJSONObject("related");
				            JSONArray myRelatedQout = myRelated.getJSONArray("relQuestion"); // TODO: NEED TO SERIALIZED so ONLY ADD once!!! VERY IMPORTANT!!!
				            
			            	int iterCount = 0;
				            if(myRelatedQout.length() <= 0){
				            	iterCount = 0;
				            }else{
				            	iterCount = 1;
				            }
							for(int relatedWalk = 0; relatedWalk < iterCount; relatedWalk++){ // TODO: change the loop if want to have more than 1 related question
								JSONObject myRelatedIter = myRelatedQout.getJSONObject(relatedWalk);
					            JSONObject myRelatedQin = myRelatedIter.getJSONObject("question");	
					            
					            if(myRelatedQin.getString("question_type").equals("rs")){
									// CHECKBOX related question type
					            	segmentQuestion[walk].relatedType.add(CHECKBOX_TYPE);
					            	String checkBoxQuestion = myRelatedQin.getString("question_text");
									String optionIDStr = "";
									
					            	// get all the check box option
									JSONObject myRelatedOption = myRelatedIter.getJSONObject("options");
									JSONArray myRelatedOptionArray = myRelatedOption.getJSONArray("data");
									for(int checkBoxWalk = 0; checkBoxWalk < myRelatedOptionArray.length(); checkBoxWalk++){
										JSONObject checkBoxIter = myRelatedOptionArray.getJSONObject(checkBoxWalk);
										checkBoxQuestion += "; " + checkBoxIter.getString("option_text");
										optionIDStr += checkBoxIter.getString("option_question_id") + "; ";
										
									} 
					            	segmentQuestion[walk].relatedText.add(checkBoxQuestion);
					            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
					            	segmentQuestion[walk].relatedOptionID.add(optionIDStr);
					            }else if(myRelatedQin.getString("question_type").equals("rm")){
										// CHECKBOX related question type
						            	segmentQuestion[walk].relatedType.add(CHECKBOX_TYPE1);
						            	String checkBoxQuestion = myRelatedQin.getString("question_text");
										String optionIDStr = "";
										
						            	// get all the check box option
										JSONObject myRelatedOption = myRelatedIter.getJSONObject("options");
										JSONArray myRelatedOptionArray = myRelatedOption.getJSONArray("data");
										for(int checkBoxWalk = 0; checkBoxWalk < myRelatedOptionArray.length(); checkBoxWalk++){
											JSONObject checkBoxIter = myRelatedOptionArray.getJSONObject(checkBoxWalk);
											checkBoxQuestion += "; " + checkBoxIter.getString("option_text");
											optionIDStr += checkBoxIter.getString("option_question_id") + "; ";
											
										} 
										
										//Log.d("HERE2", "HERE2");
										//Log.d("OPTION_ID", optionIDStr);
						            	segmentQuestion[walk].relatedText.add(checkBoxQuestion);
						            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
						            	segmentQuestion[walk].relatedOptionID.add(optionIDStr);
					            }else if(myRelatedQin.getString("question_type").equals("rl")){
					            	// TODO - related question of type LIKERT
					            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
					            	segmentQuestion[walk].relatedType.add(LIKERT_TYPE);
					            	segmentQuestion[walk].relatedText.add(myRelatedQin.getString("question_text"));
					            	segmentQuestion[walk].relatedOptionID.add("");
					            }else if(myRelatedQin.getString("question_type").equals("rt")){
					            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
					            	segmentQuestion[walk].relatedType.add(EDITTEXT_TYPE);
					            	segmentQuestion[walk].relatedText.add(myRelatedQin.getString("question_text"));
					            	segmentQuestion[walk].relatedOptionID.add("");
					            }
							}
							
							// TODO - PLEASE CHECK - escape when the related question is not there
							if(myRelatedQout.length() <= 0){
				            	segmentQuestion[walk].relatedID.add("");
				            	segmentQuestion[walk].relatedType.add("");
				            	segmentQuestion[walk].relatedText.add("");
				            	segmentQuestion[walk].relatedOptionID.add("");
							}
							String optionIDStr = "";
							
						}
						
						else if(myQuestion.getString("question_type").equals("b5")){
							// TYPE2 - CHECKBOX question type
							segmentQuestion[walk].questionType.add(BUTTON_TYPE5);
							String buttonQuestion = myQuestion.getString("question_text");
							String optionIDStr = "";
							
							// get all the check box option
							JSONArray ButtonOptionArray = questionIter.getJSONArray("options");
							for(int buttonWalk = 0; buttonWalk < ButtonOptionArray.length(); buttonWalk++){
								JSONObject buttonIter = ButtonOptionArray.getJSONObject(buttonWalk);
								buttonQuestion += "; " + buttonIter.getString("option_text");
								optionIDStr += buttonIter.getString("option_question_id") + "; ";
							}	
							
				            segmentQuestion[walk].optionID.add(optionIDStr);
							segmentQuestion[walk].questionText.add(buttonQuestion);
				            segmentQuestion[walk].questionID.add(myQuestion.getString("question_id"));
				            // TODO - get the related question
				            segmentQuestion[walk].relatedType.add("");
				            segmentQuestion[walk].relatedText.add("");
			            	segmentQuestion[walk].relatedID.add("");
			            	segmentQuestion[walk].relatedOptionID.add("");
					}
						
						
						
						else if(myQuestion.getString("question_type").equals("m")){
								// TYPE2 - CHECKBOX question type
								segmentQuestion[walk].questionType.add(CHECKBOX_TYPE1);
								String checkBoxQuestion = myQuestion.getString("question_text");
								String optionIDStr = "";
								
								// get all the check box option
								JSONArray checkBoxOptionArray = questionIter.getJSONArray("options");
								for(int checkBoxWalk = 0; checkBoxWalk < checkBoxOptionArray.length(); checkBoxWalk++){
									JSONObject checkBoxIter = checkBoxOptionArray.getJSONObject(checkBoxWalk);
									checkBoxQuestion += "; " + checkBoxIter.getString("option_text");
									optionIDStr += checkBoxIter.getString("option_question_id") + "; ";
								}	
								
					            segmentQuestion[walk].optionID.add(optionIDStr);
								segmentQuestion[walk].questionText.add(checkBoxQuestion);
					            segmentQuestion[walk].questionID.add(myQuestion.getString("question_id"));
					            // TODO - get the related question
					            segmentQuestion[walk].relatedType.add("");
					            segmentQuestion[walk].relatedText.add("");
				            	segmentQuestion[walk].relatedID.add("");
				            	segmentQuestion[walk].relatedOptionID.add("");
						}else if(myQuestion.getString("question_type").equals("t")){
							// TYPE3 - EDITTEXT question type - TODO
							segmentQuestion[walk].questionType.add(EDITTEXT_TYPE);
				            segmentQuestion[walk].questionText.add(myQuestion.getString("question_text"));
				            segmentQuestion[walk].questionID.add(myQuestion.getString("question_id"));
				            segmentQuestion[walk].optionID.add("");
							
				            // TODO - get the related question
				            segmentQuestion[walk].relatedType.add("");
				            segmentQuestion[walk].relatedText.add("");
			            	segmentQuestion[walk].relatedID.add("");
			            	segmentQuestion[walk].relatedOptionID.add("");
							//segmentQuestion[walk].questionType.add(LIKERT_TYPE);
				            //segmentQuestion[walk].questionText.add(myQuestion.getString("question_text"));
						}else if(myQuestion.getString("question_type").equals("s")){
							// TYPE2 - CHECKBOX question type
							String threshold=myQuestion.getString("threshold");
							System.out.println(threshold);
							int thresh = Integer.parseInt(threshold);
							if(thresh==0)
							{
								
									segmentQuestion[walk].questionType.add(CHECKBOX_TYPE);
									String checkBoxQuestion = myQuestion.getString("question_text");
									String optionIDStr = "";
									
									// get all the check box option
									JSONArray checkBoxOptionArray = questionIter.getJSONArray("options");
									for(int checkBoxWalk = 0; checkBoxWalk < checkBoxOptionArray.length(); checkBoxWalk++){
										JSONObject checkBoxIter = checkBoxOptionArray.getJSONObject(checkBoxWalk);
										checkBoxQuestion += "; " + checkBoxIter.getString("option_text");
										optionIDStr += checkBoxIter.getString("option_question_id") + "; ";
									}	
									
						            segmentQuestion[walk].optionID.add(optionIDStr);
									segmentQuestion[walk].questionText.add(checkBoxQuestion);
						            segmentQuestion[walk].questionID.add(myQuestion.getString("question_id"));
						           
						            segmentQuestion[walk].relatedType.add("");
						            segmentQuestion[walk].relatedText.add("");
					            	segmentQuestion[walk].relatedID.add("");
					            	segmentQuestion[walk].relatedOptionID.add("");
								}else if(thresh==1)
							{
							segmentQuestion[walk].questionType.add(CHECKBOX_TYPE2);
							String checkBoxQuestion = myQuestion.getString("question_text");
							String optionIDStr = "";
							
							// get all the check box option
							JSONArray checkBoxOptionArray = questionIter.getJSONArray("options");
							for(int checkBoxWalk = 0; checkBoxWalk < checkBoxOptionArray.length(); checkBoxWalk++){
								JSONObject checkBoxIter = checkBoxOptionArray.getJSONObject(checkBoxWalk);
								checkBoxQuestion += "; " + checkBoxIter.getString("option_text");
								optionIDStr += checkBoxIter.getString("option_question_id") + "; ";
							}	
							
				            segmentQuestion[walk].optionID.add(optionIDStr);
							segmentQuestion[walk].questionText.add(checkBoxQuestion);
				            segmentQuestion[walk].questionID.add(myQuestion.getString("question_id"));
				            // TODO - get the related question
				            JSONObject myRelated = questionIter.getJSONObject("related");
				            JSONArray myRelatedQout = myRelated.getJSONArray("relQuestion"); // TODO: NEED TO SERIALIZED so ONLY ADD once!!! VERY IMPORTANT!!!
				            
			            	int iterCount = 0;
				            if(myRelatedQout.length() <= 0){
				            	iterCount = 0;
				            }else{
				            	iterCount = 1;
				            }
							for(int relatedWalk = 0; relatedWalk < iterCount; relatedWalk++){ // TODO: change the loop if want to have more than 1 related question
								JSONObject myRelatedIter = myRelatedQout.getJSONObject(relatedWalk);
					            JSONObject myRelatedQin = myRelatedIter.getJSONObject("question");	
					            //String str=myRelatedQin.getString("threshold");
					            
					            if(myRelatedQin.getString("question_type").equals("rs")){
									// CHECKBOX related question type
					            	segmentQuestion[walk].relatedType.add(CHECKBOX_TYPE);
					            	String checkBoxQuestion1 = myRelatedQin.getString("question_text");
									String optionIDStr1 = "";
									
					            	// get all the check box option
									JSONObject myRelatedOption = myRelatedIter.getJSONObject("options");
									JSONArray myRelatedOptionArray = myRelatedOption.getJSONArray("data");
									for(int checkBoxWalk = 0; checkBoxWalk < myRelatedOptionArray.length(); checkBoxWalk++){
										JSONObject checkBoxIter = myRelatedOptionArray.getJSONObject(checkBoxWalk);
										checkBoxQuestion1 += "; " + checkBoxIter.getString("option_text");
										optionIDStr1 += checkBoxIter.getString("option_question_id") + "; ";
										
									} 
									
									//Log.d("HERE2", "HERE2");
									//Log.d("OPTION_ID", optionIDStr);
					            	segmentQuestion[walk].relatedText.add(checkBoxQuestion1);
					            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
					            	segmentQuestion[walk].relatedOptionID.add(optionIDStr1);
					            }else if(myRelatedQin.getString("question_type").equals("rm")){
										// CHECKBOX related question type
						            	segmentQuestion[walk].relatedType.add(CHECKBOX_TYPE1);
						            	String checkBoxQuestion1 = myRelatedQin.getString("question_text");
										String optionIDStr1 = "";
										
						            	// get all the check box option
										JSONObject myRelatedOption = myRelatedIter.getJSONObject("options");
										JSONArray myRelatedOptionArray = myRelatedOption.getJSONArray("data");
										for(int checkBoxWalk = 0; checkBoxWalk < myRelatedOptionArray.length(); checkBoxWalk++){
											JSONObject checkBoxIter = myRelatedOptionArray.getJSONObject(checkBoxWalk);
											checkBoxQuestion1 += "; " + checkBoxIter.getString("option_text");
											optionIDStr1 += checkBoxIter.getString("option_question_id") + "; ";
											
										} 
										
										//Log.d("HERE2", "HERE2");
										//Log.d("OPTION_ID", optionIDStr);
						            	segmentQuestion[walk].relatedText.add(checkBoxQuestion1);
						            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
						            	segmentQuestion[walk].relatedOptionID.add(optionIDStr1);
					            }else if(myRelatedQin.getString("question_type").equals("rl")){
					            	// TODO - related question of type LIKERT
					            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
					            	segmentQuestion[walk].relatedType.add(LIKERT_TYPE);
					            	segmentQuestion[walk].relatedText.add(myRelatedQin.getString("question_text"));
					            	segmentQuestion[walk].relatedOptionID.add("");
					            }else if(myRelatedQin.getString("question_type").equals("rt")){
					            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
					            	segmentQuestion[walk].relatedType.add(EDITTEXT_TYPE);
					            	segmentQuestion[walk].relatedText.add(myRelatedQin.getString("question_text"));
					            	segmentQuestion[walk].relatedOptionID.add("");
					            }
							}
							
							// TODO - PLEASE CHECK - escape when the related question is not there
							if(myRelatedQout.length() <= 0){
				            	segmentQuestion[walk].relatedID.add("");
				            	segmentQuestion[walk].relatedType.add("");
				            	segmentQuestion[walk].relatedText.add("");
				            	segmentQuestion[walk].relatedOptionID.add("");
							}
							}else if(thresh==2)
							{
								
									segmentQuestion[walk].questionType.add(CHECKBOX_TYPE3);
									String checkBoxQuestion = myQuestion.getString("question_text");
									String optionIDStr = "";
									
									// get all the check box option
									JSONArray checkBoxOptionArray = questionIter.getJSONArray("options");
									for(int checkBoxWalk = 0; checkBoxWalk < checkBoxOptionArray.length(); checkBoxWalk++){
										JSONObject checkBoxIter = checkBoxOptionArray.getJSONObject(checkBoxWalk);
										checkBoxQuestion += "; " + checkBoxIter.getString("option_text");
										optionIDStr += checkBoxIter.getString("option_question_id") + "; ";
									}	
									
						            segmentQuestion[walk].optionID.add(optionIDStr);
									segmentQuestion[walk].questionText.add(checkBoxQuestion);
						            segmentQuestion[walk].questionID.add(myQuestion.getString("question_id"));
						            // TODO - get the related question
						            JSONObject myRelated = questionIter.getJSONObject("related");
						            JSONArray myRelatedQout = myRelated.getJSONArray("relQuestion"); // TODO: NEED TO SERIALIZED so ONLY ADD once!!! VERY IMPORTANT!!!
						            
					            	int iterCount = 0;
						            if(myRelatedQout.length() <= 0){
						            	iterCount = 0;
						            }else{
						            	iterCount = 1;
						            }
									for(int relatedWalk = 0; relatedWalk < iterCount; relatedWalk++){ // TODO: change the loop if want to have more than 1 related question
										JSONObject myRelatedIter = myRelatedQout.getJSONObject(relatedWalk);
							            JSONObject myRelatedQin = myRelatedIter.getJSONObject("question");	
							            //String str=myRelatedQin.getString("threshold");
							            
							            if(myRelatedQin.getString("question_type").equals("rs")){
											// CHECKBOX related question type
							            	segmentQuestion[walk].relatedType.add(CHECKBOX_TYPE);
							            	String checkBoxQuestion1 = myRelatedQin.getString("question_text");
											String optionIDStr1 = "";
											
							            	// get all the check box option
											JSONObject myRelatedOption = myRelatedIter.getJSONObject("options");
											JSONArray myRelatedOptionArray = myRelatedOption.getJSONArray("data");
											for(int checkBoxWalk = 0; checkBoxWalk < myRelatedOptionArray.length(); checkBoxWalk++){
												JSONObject checkBoxIter = myRelatedOptionArray.getJSONObject(checkBoxWalk);
												checkBoxQuestion1 += "; " + checkBoxIter.getString("option_text");
												optionIDStr1 += checkBoxIter.getString("option_question_id") + "; ";
												
											} 
											
											//Log.d("HERE2", "HERE2");
											//Log.d("OPTION_ID", optionIDStr);
							            	segmentQuestion[walk].relatedText.add(checkBoxQuestion1);
							            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
							            	segmentQuestion[walk].relatedOptionID.add(optionIDStr1);
							            }else if(myRelatedQin.getString("question_type").equals("rm")){
												// CHECKBOX related question type
								            	segmentQuestion[walk].relatedType.add(CHECKBOX_TYPE1);
								            	String checkBoxQuestion1 = myRelatedQin.getString("question_text");
												String optionIDStr1 = "";
												
								            	// get all the check box option
												JSONObject myRelatedOption = myRelatedIter.getJSONObject("options");
												JSONArray myRelatedOptionArray = myRelatedOption.getJSONArray("data");
												for(int checkBoxWalk = 0; checkBoxWalk < myRelatedOptionArray.length(); checkBoxWalk++){
													JSONObject checkBoxIter = myRelatedOptionArray.getJSONObject(checkBoxWalk);
													checkBoxQuestion1 += "; " + checkBoxIter.getString("option_text");
													optionIDStr1 += checkBoxIter.getString("option_question_id") + "; ";
													
												} 
												
												//Log.d("HERE2", "HERE2");
												//Log.d("OPTION_ID", optionIDStr);
								            	segmentQuestion[walk].relatedText.add(checkBoxQuestion1);
								            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
								            	segmentQuestion[walk].relatedOptionID.add(optionIDStr1);
							            }else if(myRelatedQin.getString("question_type").equals("rl")){
							            	// TODO - related question of type LIKERT
							            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
							            	segmentQuestion[walk].relatedType.add(LIKERT_TYPE);
							            	segmentQuestion[walk].relatedText.add(myRelatedQin.getString("question_text"));
							            	segmentQuestion[walk].relatedOptionID.add("");
							            }else if(myRelatedQin.getString("question_type").equals("rt")){
							            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
							            	segmentQuestion[walk].relatedType.add(EDITTEXT_TYPE);
							            	segmentQuestion[walk].relatedText.add(myRelatedQin.getString("question_text"));
							            	segmentQuestion[walk].relatedOptionID.add("");
							            }
									}
									
									// TODO - PLEASE CHECK - escape when the related question is not there
									if(myRelatedQout.length() <= 0){
						            	segmentQuestion[walk].relatedID.add("");
						            	segmentQuestion[walk].relatedType.add("");
						            	segmentQuestion[walk].relatedText.add("");
						            	segmentQuestion[walk].relatedOptionID.add("");
									}
									
							}
							else if(thresh==3)
							{
								
								segmentQuestion[walk].questionType.add(CHECKBOX_TYPE4);
								String checkBoxQuestion = myQuestion.getString("question_text");
								String optionIDStr = "";
								
								// get all the check box option
								JSONArray checkBoxOptionArray = questionIter.getJSONArray("options");
								for(int checkBoxWalk = 0; checkBoxWalk < checkBoxOptionArray.length(); checkBoxWalk++){
									JSONObject checkBoxIter = checkBoxOptionArray.getJSONObject(checkBoxWalk);
									checkBoxQuestion += "; " + checkBoxIter.getString("option_text");
									optionIDStr += checkBoxIter.getString("option_question_id") + "; ";
								}	
								
					            segmentQuestion[walk].optionID.add(optionIDStr);
								segmentQuestion[walk].questionText.add(checkBoxQuestion);
					            segmentQuestion[walk].questionID.add(myQuestion.getString("question_id"));
					            // TODO - get the related question
					            JSONObject myRelated = questionIter.getJSONObject("related");
					            JSONArray myRelatedQout = myRelated.getJSONArray("relQuestion"); // TODO: NEED TO SERIALIZED so ONLY ADD once!!! VERY IMPORTANT!!!
					            
				            	int iterCount = 0;
					            if(myRelatedQout.length() <= 0){
					            	iterCount = 0;
					            }else{
					            	iterCount = 1;
					            }
								for(int relatedWalk = 0; relatedWalk < iterCount; relatedWalk++){ // TODO: change the loop if want to have more than 1 related question
									JSONObject myRelatedIter = myRelatedQout.getJSONObject(relatedWalk);
						            JSONObject myRelatedQin = myRelatedIter.getJSONObject("question");	
						            //String str=myRelatedQin.getString("threshold");
						            
						            if(myRelatedQin.getString("question_type").equals("rs")){
										// CHECKBOX related question type
						            	segmentQuestion[walk].relatedType.add(CHECKBOX_TYPE);
						            	String checkBoxQuestion1 = myRelatedQin.getString("question_text");
										String optionIDStr1 = "";
										
						            	// get all the check box option
										JSONObject myRelatedOption = myRelatedIter.getJSONObject("options");
										JSONArray myRelatedOptionArray = myRelatedOption.getJSONArray("data");
										for(int checkBoxWalk = 0; checkBoxWalk < myRelatedOptionArray.length(); checkBoxWalk++){
											JSONObject checkBoxIter = myRelatedOptionArray.getJSONObject(checkBoxWalk);
											checkBoxQuestion1 += "; " + checkBoxIter.getString("option_text");
											optionIDStr1 += checkBoxIter.getString("option_question_id") + "; ";
											
										} 
										
										//Log.d("HERE2", "HERE2");
										//Log.d("OPTION_ID", optionIDStr);
						            	segmentQuestion[walk].relatedText.add(checkBoxQuestion1);
						            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
						            	segmentQuestion[walk].relatedOptionID.add(optionIDStr1);
						            }else if(myRelatedQin.getString("question_type").equals("rm")){
											// CHECKBOX related question type
							            	segmentQuestion[walk].relatedType.add(CHECKBOX_TYPE1);
							            	String checkBoxQuestion1 = myRelatedQin.getString("question_text");
											String optionIDStr1 = "";
											
							            	// get all the check box option
											JSONObject myRelatedOption = myRelatedIter.getJSONObject("options");
											JSONArray myRelatedOptionArray = myRelatedOption.getJSONArray("data");
											for(int checkBoxWalk = 0; checkBoxWalk < myRelatedOptionArray.length(); checkBoxWalk++){
												JSONObject checkBoxIter = myRelatedOptionArray.getJSONObject(checkBoxWalk);
												checkBoxQuestion1 += "; " + checkBoxIter.getString("option_text");
												optionIDStr1 += checkBoxIter.getString("option_question_id") + "; ";
												
											} 
											
											//Log.d("HERE2", "HERE2");
											//Log.d("OPTION_ID", optionIDStr);
							            	segmentQuestion[walk].relatedText.add(checkBoxQuestion1);
							            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
							            	segmentQuestion[walk].relatedOptionID.add(optionIDStr1);
						            }else if(myRelatedQin.getString("question_type").equals("rl")){
						            	// TODO - related question of type LIKERT
						            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
						            	segmentQuestion[walk].relatedType.add(LIKERT_TYPE);
						            	segmentQuestion[walk].relatedText.add(myRelatedQin.getString("question_text"));
						            	segmentQuestion[walk].relatedOptionID.add("");
						            }else if(myRelatedQin.getString("question_type").equals("rt")){
						            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
						            	segmentQuestion[walk].relatedType.add(EDITTEXT_TYPE);
						            	segmentQuestion[walk].relatedText.add(myRelatedQin.getString("question_text"));
						            	segmentQuestion[walk].relatedOptionID.add("");
						            }
								}
								
								// TODO - PLEASE CHECK - escape when the related question is not there
								if(myRelatedQout.length() <= 0){
					            	segmentQuestion[walk].relatedID.add("");
					            	segmentQuestion[walk].relatedType.add("");
					            	segmentQuestion[walk].relatedText.add("");
					            	segmentQuestion[walk].relatedOptionID.add("");
								}
							
								
							}else if(thresh==4)
							{
								
									segmentQuestion[walk].questionType.add(CHECKBOX_TYPE5);
									String checkBoxQuestion = myQuestion.getString("question_text");
									String optionIDStr = "";
									
									// get all the check box option
									JSONArray checkBoxOptionArray = questionIter.getJSONArray("options");
									for(int checkBoxWalk = 0; checkBoxWalk < checkBoxOptionArray.length(); checkBoxWalk++){
										JSONObject checkBoxIter = checkBoxOptionArray.getJSONObject(checkBoxWalk);
										checkBoxQuestion += "; " + checkBoxIter.getString("option_text");
										optionIDStr += checkBoxIter.getString("option_question_id") + "; ";
									}	
									
						            segmentQuestion[walk].optionID.add(optionIDStr);
									segmentQuestion[walk].questionText.add(checkBoxQuestion);
						            segmentQuestion[walk].questionID.add(myQuestion.getString("question_id"));
						            // TODO - get the related question
						            JSONObject myRelated = questionIter.getJSONObject("related");
						            JSONArray myRelatedQout = myRelated.getJSONArray("relQuestion"); // TODO: NEED TO SERIALIZED so ONLY ADD once!!! VERY IMPORTANT!!!
						            
					            	int iterCount = 0;
						            if(myRelatedQout.length() <= 0){
						            	iterCount = 0;
						            }else{
						            	iterCount = 1;
						            }
									for(int relatedWalk = 0; relatedWalk < iterCount; relatedWalk++){ // TODO: change the loop if want to have more than 1 related question
										JSONObject myRelatedIter = myRelatedQout.getJSONObject(relatedWalk);
							            JSONObject myRelatedQin = myRelatedIter.getJSONObject("question");	
							            //String str=myRelatedQin.getString("threshold");
							            
							            if(myRelatedQin.getString("question_type").equals("rs")){
											// CHECKBOX related question type
							            	segmentQuestion[walk].relatedType.add(CHECKBOX_TYPE);
							            	String checkBoxQuestion1 = myRelatedQin.getString("question_text");
											String optionIDStr1 = "";
											
							            	// get all the check box option
											JSONObject myRelatedOption = myRelatedIter.getJSONObject("options");
											JSONArray myRelatedOptionArray = myRelatedOption.getJSONArray("data");
											for(int checkBoxWalk = 0; checkBoxWalk < myRelatedOptionArray.length(); checkBoxWalk++){
												JSONObject checkBoxIter = myRelatedOptionArray.getJSONObject(checkBoxWalk);
												checkBoxQuestion1 += "; " + checkBoxIter.getString("option_text");
												optionIDStr1 += checkBoxIter.getString("option_question_id") + "; ";
												
											} 
											
											//Log.d("HERE2", "HERE2");
											//Log.d("OPTION_ID", optionIDStr);
							            	segmentQuestion[walk].relatedText.add(checkBoxQuestion1);
							            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
							            	segmentQuestion[walk].relatedOptionID.add(optionIDStr1);
							            }else if(myRelatedQin.getString("question_type").equals("rm")){
												// CHECKBOX related question type
								            	segmentQuestion[walk].relatedType.add(CHECKBOX_TYPE1);
								            	String checkBoxQuestion1 = myRelatedQin.getString("question_text");
												String optionIDStr1 = "";
												
								            	// get all the check box option
												JSONObject myRelatedOption = myRelatedIter.getJSONObject("options");
												JSONArray myRelatedOptionArray = myRelatedOption.getJSONArray("data");
												for(int checkBoxWalk = 0; checkBoxWalk < myRelatedOptionArray.length(); checkBoxWalk++){
													JSONObject checkBoxIter = myRelatedOptionArray.getJSONObject(checkBoxWalk);
													checkBoxQuestion1 += "; " + checkBoxIter.getString("option_text");
													optionIDStr1 += checkBoxIter.getString("option_question_id") + "; ";
													
												} 
												
												//Log.d("HERE2", "HERE2");
												//Log.d("OPTION_ID", optionIDStr);
								            	segmentQuestion[walk].relatedText.add(checkBoxQuestion1);
								            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
								            	segmentQuestion[walk].relatedOptionID.add(optionIDStr1);
							            }else if(myRelatedQin.getString("question_type").equals("rl")){
							            	// TODO - related question of type LIKERT
							            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
							            	segmentQuestion[walk].relatedType.add(LIKERT_TYPE);
							            	segmentQuestion[walk].relatedText.add(myRelatedQin.getString("question_text"));
							            	segmentQuestion[walk].relatedOptionID.add("");
							            }else if(myRelatedQin.getString("question_type").equals("rt")){
							            	segmentQuestion[walk].relatedID.add(myRelatedQin.getString("rel_question_id"));
							            	segmentQuestion[walk].relatedType.add(EDITTEXT_TYPE);
							            	segmentQuestion[walk].relatedText.add(myRelatedQin.getString("question_text"));
							            	segmentQuestion[walk].relatedOptionID.add("");
							            }
									}
									
									// TODO - PLEASE CHECK - escape when the related question is not there
									if(myRelatedQout.length() <= 0){
						            	segmentQuestion[walk].relatedID.add("");
						            	segmentQuestion[walk].relatedType.add("");
						            	segmentQuestion[walk].relatedText.add("");
						            	segmentQuestion[walk].relatedOptionID.add("");
									}
								}
							
						}else{
							
							// TODO - add for other question type
						}
		            }
				}
				
				// Displaying the survey question
				responsePointer = new ArrayList<Object>();
				myJsonResult = new JSONObject();
				myJsonResult.put("user_id", currentEmailID);
				myJsonResult.put("survey_id", mySurveyID);
			    myResultArray = new JSONArray();
	    		updateScreen(0);
			} catch (JSONException e) {
    			// TODO - print message - exception happens on the server
				e.printStackTrace();
			}
		}
	}

	private class AddEmailToServer extends AsyncTask<String, Void, String> {
		//private ProgressDialog loadingDialog;

		protected void onPreExecute (){
        	//loadingDialog = ProgressDialog.show(MainActivity.this, "Loading the Survey Data", "Please Wait...");
		}
		
		@Override
		protected String doInBackground(String... inputString) {
			// request music from Servlet
        	String resultString = new String();        		
        	try{
        		int TIMEOUT_MILLISEC = 10000;
        		HttpParams httpParams = new BasicHttpParams(); 
        		HttpConnectionParams.setConnectionTimeout(httpParams, TIMEOUT_MILLISEC); 
        		HttpConnectionParams.setSoTimeout(httpParams, TIMEOUT_MILLISEC);
        		HttpClient client = getThreadSafeClient();
        		HttpGet request = new HttpGet(inputString[0]);
	        	//client.execute(request);
	        		
	        	HttpResponse response = client.execute(request); 
	        	HttpEntity he = response.getEntity();
	        	InputStream is = he.getContent();
	        	BufferedReader br = new BufferedReader(new InputStreamReader(is));
	        	resultString = br.readLine();
	        	response.getEntity().consumeContent();
	        	is.close();
        	}catch(Exception e){
        		e.printStackTrace();
        	}
        	
        	return resultString;
		}

		/*
		protected void onProgressUpdate(Integer... progress) {
			setProgressPercent(progress[0]);
		}
		*/
		
		@Override
		protected void onPostExecute(String resultString) {
			//loadingDialog.dismiss();
			//Intent intent = new Intent(MainActivity.this, DisplayActivity.class);
			//intent.setType("text/plain");
			//intent.putExtra(android.content.Intent.EXTRA_TEXT, resultString);
			//startActivity(intent); 
			saveUseridInPreferences(resultString);
			
			// TODO - check if there is survey associated with the user & location
			
    		try{
    			String requestTarget = "http://building-occupant-gateway.com/EE579Project/api/get_full_survey.php?survey_id=" + currentSurveyID;
    			new FetchFromServer().execute(requestTarget);
    		}catch(Exception e){
    			e.printStackTrace();
    		}
		}
	}
	
	private void activateCamera(){
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        //fileUri = getOutputMediaFileUri(MEDIA_TYPE_IMAGE); // create a file to save the image
        //cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri); // set the image file name
        startActivityForResult(cameraIntent, CAMERA_REQUEST); 
	}
	
	/** Create a file Uri for saving an image or video */
	private static Uri getOutputMediaFileUri(int type){
	      return Uri.fromFile(getOutputMediaFile(type));
	}

	/** Create a File for saving an image or video */
	private static File getOutputMediaFile(int type){
	    // To be safe, you should check that the SDCard is mounted
	    // using Environment.getExternalStorageState() before doing this.
	    File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "MyCameraApp");
	    
	    // This location works best if you want the created images to be shared
	    // between applications and persist after your app has been uninstalled.
	    
	    // Create the storage directory if it does not exist
	    if (! mediaStorageDir.exists()){
	        if (! mediaStorageDir.mkdirs()){
	            Log.d("MyCameraApp", "failed to create directory");
	            return null;
	        }
	    }
	    Log.e("DIR", "CREATED");
	    
	    // Create a media file name
	    String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
	    File mediaFile;
	    if (type == MEDIA_TYPE_IMAGE){
	        mediaFile = new File(mediaStorageDir.getPath() + File.separator + "IMG_"+ timeStamp + ".jpg");
	    } else {
	        return null;
	    }

	    return mediaFile;
	}
	
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
	private class SendToServer extends AsyncTask<String, Void, String> {
		protected void onPreExecute (){
			
		}
		
		@Override
		protected String doInBackground(String... inputString) {
			String sendingString = new String();
	    	String resultString = new String(); 
	    	
	    	// send dummy string for testing
	    	sendingString = inputString[0];
	    	
	    	try{
	    		// POST data to the server
	    		int TIMEOUT_MILLISEC = 10000;
		    	HttpParams httpParams = new BasicHttpParams(); 
		    	HttpConnectionParams.setConnectionTimeout(httpParams,TIMEOUT_MILLISEC); 
		    	HttpConnectionParams.setSoTimeout(httpParams, TIMEOUT_MILLISEC); 
		    	HttpClient client = new DefaultHttpClient();
		    	HttpPost request = new HttpPost("http://building-occupant-gateway.com/EE579Project/api/add_response.php");
		    	List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		    	nameValuePairs.add(new BasicNameValuePair("response", sendingString));

		    	// convert String into InputStream before sending
		    	//InputStream strStream = new ByteArrayInputStream(sendingString.getBytes());
		    	//BasicHttpEntity strEntity = new BasicHttpEntity();
		    	//strEntity.setContent(strStream);
		    	//request.setEntity(strEntity);
		    	request.setEntity(new UrlEncodedFormEntity(nameValuePairs));
		    	HttpResponse response = client.execute(request);
		    	
		    	// RESPOND PART
		    	//HttpResponse response = client.execute(request); 
		    	HttpEntity he = response.getEntity();
		    	InputStream is = he.getContent();
		    	BufferedReader br = new BufferedReader(new InputStreamReader(is));
		    	resultString = br.readLine();
	        	response.getEntity().consumeContent();
	        	is.close();
		    }catch(Exception e){
		    	e.printStackTrace();
	    	} 
	    	
	    	return resultString;
		}
		
		@Override
		protected void onPostExecute(String resultString) {
			
			//Intent intent = new Intent(MainActivity.this, FifthActivity.class);
            //startActivity(intent);
            finish();
            
			
		}
	}

	/*
    private void sendResponseToServer(){
    	String sendingString = new String();
    	String resultString = new String(); 
    	
    	// send dummy string for testing
    	sendingString = "TESTING";
    	
    	try{
    		// POST data to the server
    		int TIMEOUT_MILLISEC = 10000;
	    	HttpParams httpParams = new BasicHttpParams(); 
	    	HttpConnectionParams.setConnectionTimeout(httpParams,TIMEOUT_MILLISEC); 
	    	HttpConnectionParams.setSoTimeout(httpParams, TIMEOUT_MILLISEC); 
	    	HttpClient client = new DefaultHttpClient();
	    	HttpPost request = new HttpPost("http://ee579finalapp.aws.af.cm/api/testPost.php");
	    	List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
	    	nameValuePairs.add(new BasicNameValuePair("test", sendingString));

	    	// convert String into InputStream before sending
	    	//InputStream strStream = new ByteArrayInputStream(sendingString.getBytes());
	    	//BasicHttpEntity strEntity = new BasicHttpEntity();
	    	//strEntity.setContent(strStream);
	    	//request.setEntity(strEntity);
	    	request.setEntity(new UrlEncodedFormEntity(nameValuePairs));
	    	client.execute(request);
	    	
	    	// RESPOND PART
	    	HttpResponse response = client.execute(request); 
	    	HttpEntity he = response.getEntity();
	    	InputStream is = he.getContent();
	    	BufferedReader br = new BufferedReader(new InputStreamReader(is));
	    	resultString = br.readLine();
	    }catch(Exception e){
	    	e.printStackTrace();
    	} 
    	
    	Log.e("POST", resultString);
    	//Toast.makeText(this, resultString, Toast.LENGTH_LONG).show();
    	//receivedInt = Integer.parseInt(resultString);
    }
    */
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
	    // Handle item selection
	    switch (item.getItemId()) {
	    case R.id.action_change_email:
	    	updateScreenforEmail();
	        return true;
	    case R.id.action_remove_email:	    	
	        removeEmailFromPreferences();
	    	updateScreenforEmail();
	        return true;
	    case R.id.action_refresh_location:
			Intent service = new Intent(this, ProximityService.class);
			service.putExtra("STATUS", "VALID+REFRESH");
			this.startService(service);
	    	
			//Intent intent = new Intent(MainActivity.this, WebRequest.class);
			//startActivity(intent);
	    	//startService(new Intent(this, ProximityService.class));
	    	return true;
	    	/*
	    case R.id.action_demo_mode:
	        String userEmail = retrieveEmailFromPreferences();
			if(userEmail != null && userEmail != ""){
	    		try{
	    			String requestTarget = "http://building-occupant-gateway.com/EE579Project/api/get_surveys_for_user.php?email=" + userEmail;
	    			new QueryLocation().execute(requestTarget); // execute the request to the server
	    		}catch(Exception e){
	    			e.printStackTrace();
	    		}
			}
	    	return true;*/
	    
	    default:
	        return super.onOptionsItemSelected(item);
	    }
	}

/*
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		SharedPreferences p = getSharedPreferences(PushService.TAG, MODE_PRIVATE);
  	  	boolean started = p.getBoolean(PushService.PREF_STARTED, false);
	}
	*/
}
        
// ********************************************************************************************

        /*
        Button debugButton = (Button) findViewById(R.id.debugButton);
        debugButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				String outputValue = "";
		        for(int walk = 0; walk < componentQuestion.length; walk++){
		        	outputValue += "Q" + walk + ": " + Integer.toString(componentSeek[walk].getProgress()) + "; ";
		        }
				Toast.makeText(MainActivity.this, outputValue, Toast.LENGTH_LONG).show();
			}
		});
		*/
        
        //View component2View = getLayoutInflater().inflate(R.layout.likert_layout, null);
        //currentLayout.addView(component2View);
        
    	/*
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        titleText = (TextView) findViewById(R.id.textview);
        titleText.setText("Please specify the temperature level:");
        
        progressImage = (ImageView) findViewById(R.id.progressimage);
        
        SeekBar testSeekBar = (SeekBar) findViewById(R.id.seekbar);
        testSeekBar.setProgress(3);
        testSeekBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() 
        {
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				
			}
			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				if(progress == 0){
					progressImage.setImageResource(R.drawable.mood1);
				}else if(progress == 1){
					progressImage.setImageResource(R.drawable.mood2);
				}else if(progress == 2){
					progressImage.setImageResource(R.drawable.mood3);
				}else if(progress == 3){
					progressImage.setImageResource(R.drawable.mood4);
				}else if(progress == 4){
					progressImage.setImageResource(R.drawable.mood5);
				}else if(progress == 5){
					progressImage.setImageResource(R.drawable.mood6);
				}else if(progress == 6){
					progressImage.setImageResource(R.drawable.mood7);
				}
				// progressText.setText(progress + "%");
			}
		});
		*/
    
    /*
    public LikertResult addLikertComponent(LinearLayout currentLayout, String componentQuestion){
    	LikertResult tempResult = new LikertResult();
        View componentView = getLayoutInflater().inflate(R.layout.likert_layout, null);
        final ImageView componentImage = (ImageView) componentView.findViewById(R.id.likertprogressimage);
        TextView componentTitle = (TextView) componentView.findViewById(R.id.likerttextview);
        componentTitle.setText(componentQuestion);
        final SeekBar componentSeekFunc = (SeekBar) componentView.findViewById(R.id.likertseekbar);
        componentSeekFunc.setProgress(3);
        componentSeekFunc.setOnSeekBarChangeListener(new OnSeekBarChangeListener() 
        {
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				
			}
			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				if(progress == 0){
					componentImage.setImageResource(R.drawable.mood1);
				}else if(progress == 1){
					componentImage.setImageResource(R.drawable.mood2);
				}else if(progress == 2){
					componentImage.setImageResource(R.drawable.mood3);
				}else if(progress == 3){
					componentImage.setImageResource(R.drawable.mood4);
				}else if(progress == 4){
					componentImage.setImageResource(R.drawable.mood5);
				}else if(progress == 5){
					componentImage.setImageResource(R.drawable.mood6);
				}else if(progress == 6){
					componentImage.setImageResource(R.drawable.mood7);
				}
				// progressText.setText(progress + "%");
			}
		});
        tempResult.likertSeekbar = componentSeekFunc;
        
        CheckBox componentCheckFunc = (CheckBox) componentView.findViewById(R.id.likertna);
        componentCheckFunc.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				// TODO Auto-generated method stub
				if(isChecked){
					componentSeekFunc.setEnabled(false);
				}else{
					componentSeekFunc.setEnabled(true);
				}
			}
		});
        tempResult.likertCheckBox = componentCheckFunc;
        
        currentLayout.addView(componentView);
		return tempResult;
    }
    */
    
    /*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    */