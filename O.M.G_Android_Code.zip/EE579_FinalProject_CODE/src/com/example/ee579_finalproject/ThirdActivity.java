package com.example.ee579_finalproject;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class ThirdActivity extends Activity {
    String segmentTitle = "Building Features";
    LikertResult[] componentSeek;
    String[] componentQuestion = {"Considering energy use, how efficiently is this building performing in your opinion?"};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_third);
		
		// get the current layout
        ScrollView thirdScroll = (ScrollView)findViewById(R.id.thirdScroll);
        LinearLayout currentLayout = (LinearLayout)thirdScroll.findViewById(R.id.thirdLayout);
        
        // add the title
        View titleView = getLayoutInflater().inflate(R.layout.title_layout, null);
        TextView titleTextView = (TextView) titleView.findViewById(R.id.titletext);
        titleTextView.setText(segmentTitle);
        currentLayout.addView(titleView);
        
        // add the question & likert
        /*
        componentSeek = new LikertResult[componentQuestion.length];
        for(int walk = 0; walk < componentQuestion.length; walk++){
        	componentSeek[walk] = new LikertResult();
        	componentSeek[walk].addLikertComponent(this, currentLayout, componentQuestion[walk]);
        }
        */
        
        // add the edit text
        View edittextView = getLayoutInflater().inflate(R.layout.edittext_layout, null);
        EditText commentEdit = (EditText) edittextView.findViewById(R.id.edittextSpace);
        commentEdit.clearFocus();
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        currentLayout.addView(edittextView);
        
        // add the button
        View buttonView = getLayoutInflater().inflate(R.layout.button_layout, null);
        Button nextsubmitButton = (Button) buttonView.findViewById(R.id.nextsubmitButton);
        nextsubmitButton.setText("Submit");
        nextsubmitButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent goToNextActivity = new Intent(getApplicationContext(), ForthActivity.class);
				startActivity(goToNextActivity);
			}
		});
        currentLayout.addView(buttonView);
	}

	/*
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.third, menu);
		return true;
	}
	*/
}
