package com.example.ee579_finalproject;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class Alarmreceiver extends BroadcastReceiver{
	
	static private int index = 0;

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		if(intent.getAction().equals("arui.alarm.action")){
			Intent i=new Intent();
			i.setClass(context, NotificationService.class);
			context.startService(i);
			Intent b = new Intent();
			index = index + 1;
			Log.i("Index", Integer.toString(index));
			
			if (index == 6) {
				index = 0;
				b.setClass(context, SensorService.class);
				context.startService(b);
				Log.i("Index", Integer.toString(index));
			} else if (index == 5) {
				context.stopService(b);
			}
			//Intent b=new Intent();
			//b.setClass(context, SensorService.class);
			//context.startService(b);
			
		}
	}

}
