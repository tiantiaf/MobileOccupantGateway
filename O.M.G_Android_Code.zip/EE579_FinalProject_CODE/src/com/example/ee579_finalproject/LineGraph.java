package com.example.ee579_finalproject;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.TimeSeries;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint.Align;

public class LineGraph {

private GraphicalView view;



private TimeSeries xSeries = new TimeSeries("X");


private XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();

XYSeriesRenderer xRenderer = new XYSeriesRenderer();


XYMultipleSeriesRenderer multiRenderer = new XYMultipleSeriesRenderer();

public LineGraph() {


    dataset.addSeries(xSeries);


    xRenderer.setColor(Color.RED);
    xRenderer.setLineWidth(1);
    xRenderer.setDisplayChartValues(false);
     multiRenderer.setXLabels(15);
  //  multiRenderer.setYLabels(50);
  //  double maxX=xSeries.getMaxX();
  //  double minX=maxX-60;
    multiRenderer.setYAxisMin(0);
    multiRenderer.setYAxisMax(2000);
    multiRenderer.setLabelsColor(Color.YELLOW);
    multiRenderer.setChartTitle("LIGHT CHANGES OVER TIME");
    multiRenderer.setXTitle("Sensor Data");
    multiRenderer.setYTitle("Values of Light in LUX");
    multiRenderer.setShowGrid(true); 
    multiRenderer.addSeriesRenderer(xRenderer);
    multiRenderer.setXLabelsAlign(Align.LEFT);
  //  multiRenderer.setRange(new double[]{minX,maxX});
}

public GraphicalView getView(Context context) 
{
    view =  ChartFactory.getLineChartView(context, dataset, multiRenderer);
    return view;
}

public void addNewData(Point data, Double x)
{ 
    xSeries.add(data.getY(), data.getX());
if(data.getY()<=60){
	multiRenderer.setXAxisMax(60);
}
else if(data.getY()>60){
	multiRenderer.setXAxisMin(data.getY()-60);
	multiRenderer.setXAxisMax(data.getY());
}
}
}
