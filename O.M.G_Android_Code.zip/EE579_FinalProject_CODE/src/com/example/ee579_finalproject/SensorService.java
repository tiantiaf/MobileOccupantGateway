package com.example.ee579_finalproject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.achartengine.GraphicalView;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

import android.R.integer;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.IBinder;
import android.util.Log;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.robocatapps.thermodosdk.Thermodo;
import com.robocatapps.thermodosdk.ThermodoFactory;
import com.robocatapps.thermodosdk.ThermodoListener;

public class SensorService extends Service implements ThermodoListener,SensorEventListener{
	private Thermodo mThermodo;
	public static final String EMAIL_KEY = "EMAIL_KEY";
	float tGet;
	float lGet;
	float S4Get;
	private float motionCalculation;
	private float xData, yData, zData;
	private int motion;
	private SensorManager sm;
	private Sensor Light, acceSensor, tempSensor;
	private String user;
	private String light, temp, temp_S4;
	int inttemp,intlight;
	int savetemp,savelight;
	int batteryStatus;
	int m;
	private BatteryReceiver batteryReceiver;
	private SensorEventListener mySensorListener;
	private SensorEventListener acceSensorListener;
	private SensorEventListener tempSensorListener;
	private int index, tempIndex = 0, lightIndex, s4Index;
	private boolean isTempSensing, isMotionSensing, isLightSensing, isS4Sensing;
	
	@Override
	public void onErrorOccurred(int arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStartedMeasuring() {
		// TODO Auto-generated method stub
	//	Toast.makeText(this, "Started measuring", Toast.LENGTH_SHORT).show();
		
	}

	@Override
	public void onStoppedMeasuring() {
		// TODO Auto-generated method stub
	//	Toast.makeText(this, "ThermodoSensor unpluged", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onTemperatureMeasured(float temperature) {
		// TODO Auto-generated method stub
		if (isTempSensing) {
			if (tempIndex < 10) {
				tGet += temperature;
				
				tempIndex++;
				Log.i("Temperature", Float.toString(tGet) + ", " + Integer.toString(tempIndex));
			}
			
			else{
	    		
	    		Log.i("Motion", Float.toString(tGet));
	    		tempIndex = 0;
	    		isTempSensing = false;
			}
		}
		
		
	}

	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		// TODO Auto-generated method stub
		
		
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		
		IntentFilter intentFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
		batteryReceiver = new BatteryReceiver();
		registerReceiver(batteryReceiver, intentFilter);

	//	String t= String.valueOf(lGet);
	//	Toast.makeText(this, t, Toast.LENGTH_SHORT).show();
	}
	
	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		
		unregisterReceiver(batteryReceiver);
		sm.unregisterListener(acceSensorListener);
		sm.unregisterListener(mySensorListener);
		sm.unregisterListener(tempSensorListener);
		
		
	}
	private class SendToServer extends AsyncTask<String, Void, String> {
		protected void onPreExecute (){
			
		}
		
		@Override
		protected String doInBackground(String... inputString) {
			String sendingString = new String();
	    	String resultString = new String(); 
	    	
	    	// send dummy string for testing
	    	sendingString = inputString[0];
	    	
	    	try{
	    		// POST data to the server
	    		int TIMEOUT_MILLISEC = 10000;
		    	HttpParams httpParams = new BasicHttpParams(); 
		    	HttpConnectionParams.setConnectionTimeout(httpParams,TIMEOUT_MILLISEC); 
		    	HttpConnectionParams.setSoTimeout(httpParams, TIMEOUT_MILLISEC); 
		    	HttpClient client = new DefaultHttpClient();
		    	
		    	//HttpPost request = new HttpPost("http://building-occupant-gateway.com/EE579Project/api/add_contextual_data.php?userid="+user+"&light="+light+"&temp="+temp+"&battery="+batteryStatus);
		    	List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		    	nameValuePairs.add(new BasicNameValuePair("response", sendingString));
		    	HttpGet request = new HttpGet(inputString[0]);
		    	// convert String into InputStream before sending
		    	//InputStream strStream = new ByteArrayInputStream(sendingString.getBytes());
		    	//BasicHttpEntity strEntity = new BasicHttpEntity();
		    	//strEntity.setContent(strStream);
		    	//request.setEntity(strEntity);
		    	//request.setEntity(new UrlEncodedFormEntity(nameValuePairs));
		    	HttpResponse response = client.execute(request);
		    	
		    	// RESPOND PART
		    	//HttpResponse response = client.execute(request); 
		    	HttpEntity he = response.getEntity();
		    	InputStream is = he.getContent();
		    	BufferedReader br = new BufferedReader(new InputStreamReader(is));
		    	resultString = br.readLine();
	        	response.getEntity().consumeContent();
	        	is.close();
		    }catch(Exception e){
		    	e.printStackTrace();
	    	} 
	    	
	    	return resultString;
		}
	}
	

	@Override
	@Deprecated
	public void onStart(Intent intent, int startId) {
		
		// TODO Auto-generated method stub
		super.onStart(intent, startId);
		
		mThermodo = ThermodoFactory.getThermodoInstance(this);
		mThermodo.setThermodoListener(this);
		mThermodo.start();
		
		sm = (SensorManager) getSystemService(SENSOR_SERVICE);
		Light = sm.getDefaultSensor(Sensor.TYPE_LIGHT);
		acceSensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		tempSensor = sm.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);
		
		
		isTempSensing = true;
		isS4Sensing     = true;
		isMotionSensing = true;
		isLightSensing  = true;
		
		mThermodo.start();
		
		acceSensorListener = new SensorEventListener() {  
			 
	        @Override  
	        public void onSensorChanged(SensorEvent event) { 
	        	
	        	if (isMotionSensing) {
	        		float xMotion = event.values[0];
		        	float yMotion = event.values[1];
		        	float zMotion = event.values[2];
		        	
		        	motionCalculation = motionCalculation + (float) Math.pow(xMotion - xData, 2) 
		        			+ (float) Math.pow(yMotion - yData, 2) + (float) Math.pow(zMotion - zData, 2);
		    		// lightMeter.setProgress((int)currentReading);
		        	
		        	xData = xMotion;
		        	yData = yMotion;
		        	zData = zMotion;
		    		
		        	index++;
		        	
		        	
		        	if (index == 20) {
		        		
		        		motionCalculation = motionCalculation / 20;
		        		Log.i("Motion", Float.toString(motionCalculation));
		        		if (motionCalculation >= 10) {
							motion = 1;
						} else {
							motion = 0;
						}
		        		
		        		motionCalculation = 0;
		        		index = 0;
		        		isMotionSensing = false;
					}
				}
	        	
	    		
	        }  
	        
	        @Override  
	        public void onAccuracyChanged(Sensor sensor, int accuracy) {  
	        }  
		};
		
		mySensorListener = new SensorEventListener() {  
			 
	        @Override  
	        public void onSensorChanged(SensorEvent event) { 
	        	if (isLightSensing) {
		        	float currentReading = event.values[0];
		    		// lightMeter.setProgress((int)currentReading);
		    		lGet += currentReading;
		    		
		    		lightIndex++;
		        	
		        	
		        	if (lightIndex == 5) {
		        		
		        		lGet = lGet / 5;
		        		lightIndex = 0;
		        		isLightSensing = false;
		        		
					}
	        	}
	    		
	        }  
	        
	        @Override  
	        public void onAccuracyChanged(Sensor sensor, int accuracy) {  
	        }  
		};
		
		tempSensorListener = new SensorEventListener() {  
			 
	        @Override  
	        public void onSensorChanged(SensorEvent event) { 
	        	if (isS4Sensing) {
		        	float currentReading = event.values[0];
		    		// lightMeter.setProgress((int)currentReading);
		        	S4Get += currentReading;
		        	
		        	s4Index++;
		        	
		        	
		        	if (s4Index == 5) {
		        		
		        		S4Get = S4Get / 5;
		        		s4Index = 0;
		        		Log.i("S4 Temperature Sensor", String.valueOf(S4Get));
		        		isS4Sensing = false;
					}
	        	}
	    		
	        }  
	        
	        @Override  
	        public void onAccuracyChanged(Sensor sensor, int accuracy) {  
	        }  
		};
		
		sm.registerListener(mySensorListener, Light,
		SensorManager.SENSOR_DELAY_NORMAL);
		
		sm.registerListener(acceSensorListener, acceSensor,
				SensorManager.SENSOR_DELAY_NORMAL);
		
		sm.registerListener(tempSensorListener, tempSensor,
					SensorManager.SENSOR_DELAY_NORMAL);
		
		SharedPreferences prefs = this.getSharedPreferences("SAVEDEMAIL", Context.MODE_PRIVATE); // get the email saved in the preference
        String userEmail = prefs.getString(EMAIL_KEY, "");
        user = userEmail;
        
        Timer timer = new Timer( );
        
        TimerTask task = new TimerTask( ) {
	        	public void run () {
	        		if(user != null && user != ""){
	        			
	        			tGet = tGet / 10;
	        			light = String.valueOf(lGet);
	        			temp  = String.valueOf(tGet);
	        			
	        			temp_S4  = String.valueOf(S4Get);
	        			mThermodo.stop();
	        			
	        			WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
	                    WifiInfo wifiInfo = wifiManager.getConnectionInfo();
	                    String wifi = wifiInfo.getSSID().toString().trim();
	                    wifi = wifi.replace("\"", "");
	                    wifi = wifi.replace(" ", "_");
	        			
	        			System.out.println(user + ", " + temp + ", " 
	        					+ light + ", " + batteryStatus + ", " + motionCalculation + ", " 
	        					+ temp_S4 + ", " + wifi);
	                	new SendToServer().execute("http://building-occupant-gateway.com/EE579Project/api/add_contextual_data.php?userid="+user+"&light="
		        			+light+"&temp="+temp+"&battery="+batteryStatus+"&motion="+motion+"&S4_temp="+temp_S4
		        			+"&wifi="+wifi);
	                	
	                	tGet = 0;
	                	lGet = 0;
	                	S4Get = 0;
	                	
	                }
	        	}
        };
        
        timer.schedule(task, 6000);
        
        Intent LightIntent= new Intent(this,LightActivity.class);
        LightIntent.putExtra("light", light);
        
	}
	
	
	
	class BatteryReceiver extends BroadcastReceiver{

		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			
			if(Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())){
				
				int level = intent.getIntExtra("level", 0);
				int scale = intent.getIntExtra("scale", 100);
				
				batteryStatus = (level*100) / scale;
				
			}
		}
		
	}
	
}
