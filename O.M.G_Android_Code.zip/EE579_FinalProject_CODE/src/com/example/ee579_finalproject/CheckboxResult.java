package com.example.ee579_finalproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CheckboxResult {
	public CheckBox[] componentCheckBox;

	public CheckboxResult(){
		
	}
	
	public CheckBox[] addCheckboxComponent(final Context context, LinearLayout currentLayout, String componentQuestion){        
    	LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View questionView = inflater.inflate(R.layout.checkboxquestion_layout, null);
    // int walk;
	// int walk2;
        // do the question parsing (semicolon delimited)
        String[] questionParsed = componentQuestion.split(";");
        
        // add the check box question
        TextView questionTextView = (TextView) questionView.findViewById(R.id.checkboxQuestion);
        questionTextView.setText(questionParsed[0]);
        currentLayout.addView(questionView);
        
        // add the check box components
        int checkBoxCount = questionParsed.length - 1;
       componentCheckBox = new CheckBox[checkBoxCount];
       for(int walk = 0; walk < componentCheckBox.length; walk++){
        	componentCheckBox[walk] = addCheckBoxComponent(context, currentLayout, questionParsed[walk + 1]);
        	//componentCheckBox[walk].setEnabled(false);
        //	componentCheckBox[walk].setEnabled(true);
        }
 
	
      if(componentCheckBox.length==4)
      {
        componentCheckBox[0].setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub

                if (componentCheckBox[0].isChecked() == true) 
                {
                    for(int num=0;num<0;num++){
                    	componentCheckBox[num].setChecked(false);
                    }
                    for(int num=1;num<componentCheckBox.length;num++){
                    	componentCheckBox[num].setChecked(false);
                    	//componentCheckBox[0].setEnabled(true);
                }
                       
            
            }
                
			}
			
        });
        componentCheckBox[1].setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub

                if (componentCheckBox[1].isChecked() == true) 
                {
                    for(int num=0;num<1;num++){
                    	componentCheckBox[num].setChecked(false);
                    }
                    for(int num=2;num<componentCheckBox.length;num++){
                    	componentCheckBox[num].setChecked(false);
                    	//componentCheckBox[1].setEnabled(true);
                }
                       
            
            }
                
			}
			
        });
        componentCheckBox[2].setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub

                if (componentCheckBox[2].isChecked() == true) 
                {
                    for(int num=0;num<2;num++){
                    	componentCheckBox[num].setChecked(false);
                    }
                    for(int num=3;num<componentCheckBox.length;num++){
                    	componentCheckBox[num].setChecked(false);
                    	//componentCheckBox[1].setEnabled(true);
                }
                       
           
            }
                
			}
			
        });
        componentCheckBox[3].setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub

                if (componentCheckBox[3].isChecked() == true) 
                {
                    for(int num=0;num<3;num++){
                    	componentCheckBox[num].setChecked(false);
                    }
                    for(int num=4;num<componentCheckBox.length;num++){
                    	componentCheckBox[num].setChecked(false);
                    	//componentCheckBox[1].setEnabled(true);
                }
            
            }
                
			}
			
        });
      }
      else  if(componentCheckBox.length==3)
      {
        componentCheckBox[0].setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub

                if (componentCheckBox[0].isChecked() == true) 
                {
                    for(int num=0;num<0;num++){
                    	componentCheckBox[num].setChecked(false);
                    }
                    for(int num=1;num<componentCheckBox.length;num++){
                    	componentCheckBox[num].setChecked(false);
                    	//componentCheckBox[0].setEnabled(true);
                }
                       
           
            }
                
			}
			
        });
        componentCheckBox[1].setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub

                if (componentCheckBox[1].isChecked() == true) 
                {
                    for(int num=0;num<1;num++){
                    	componentCheckBox[num].setChecked(false);
                    }
                    for(int num=2;num<componentCheckBox.length;num++){
                    	componentCheckBox[num].setChecked(false);
                    	//componentCheckBox[1].setEnabled(true);
                }
                       
           
            }
                
			}
			
        });
        componentCheckBox[2].setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
				// TODO Auto-generated method stub

                if (componentCheckBox[2].isChecked() == true) 
                {
                    for(int num=0;num<2;num++){
                    	componentCheckBox[num].setChecked(false);
                    }
                    for(int num=3;num<componentCheckBox.length;num++){
                    	componentCheckBox[num].setChecked(false);
                    	//componentCheckBox[1].setEnabled(true);
                }
                       
            
            }
                
			}
			
        });
       
      }
      else if(componentCheckBox.length==2)
      {
          componentCheckBox[0].setOnCheckedChangeListener(new OnCheckedChangeListener() {

  			@Override
  			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
  				// TODO Auto-generated method stub

                  if (componentCheckBox[0].isChecked() == true) 
                  {
                      for(int num=0;num<0;num++){
                      	componentCheckBox[num].setChecked(false);
                      }
                      for(int num=1;num<componentCheckBox.length;num++){
                      	componentCheckBox[num].setChecked(false);
                      	//componentCheckBox[0].setEnabled(true);
                  }
                         
              
              }
                  
  			}
  			
          });
          componentCheckBox[1].setOnCheckedChangeListener(new OnCheckedChangeListener() {

  			@Override
  			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
  				// TODO Auto-generated method stub

                  if (componentCheckBox[1].isChecked() == true) 
                  {
                      for(int num=0;num<1;num++){
                      	componentCheckBox[num].setChecked(false);
                      }
                      for(int num=2;num<componentCheckBox.length;num++){
                      	componentCheckBox[num].setChecked(false);
                      	//componentCheckBox[1].setEnabled(true);
                  }
                         
              
              }
                  
  			}
  			
          });
         
        }
        return componentCheckBox;
	}
	
    private CheckBox addCheckBoxComponent(Context context, LinearLayout currentLayout, String componentQuestion){
    	LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View componentView = inflater.inflate(R.layout.checkbox_layout, null);
        
        CheckBox componentCheckBox = (CheckBox) componentView.findViewById(R.id.checkboxLayout);
        componentCheckBox.setText(componentQuestion);
        currentLayout.addView(componentView);
        
		return componentCheckBox;
    }
}
