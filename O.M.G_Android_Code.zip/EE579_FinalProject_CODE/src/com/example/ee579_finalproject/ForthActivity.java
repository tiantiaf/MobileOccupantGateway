package com.example.ee579_finalproject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import com.robocatapps.thermodosdk.Thermodo;
import com.robocatapps.thermodosdk.ThermodoFactory;
import com.robocatapps.thermodosdk.ThermodoListener;


import android.R.integer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.Menu;

import android.view.View;

import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;

import android.widget.GridView;

import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class ForthActivity extends Activity implements ThermodoListener,SensorEventListener{
	int[] iconids = new int[] 
			{ R.drawable.notebook,
			};
	float tGet;
	float lGet;
	private Thermodo mThermodo;
	
	private SensorManager sm;
	private Intent SensorService;
	private Sensor Light;
	private String user;
	private String light,temp;
	private int inttemp,intlight;
	private int savetemp,savelight;
	private int m;
	private int index;
	private PowerManager pm;
	private WakeLock wakeLock;
	
	/* No need for Now */
	//private TextView mTemperatureTextView;
	//private TextView mTemperatureTextView1;
	//private TextView LightText;
	//private TextView Tempc;
	
	//private String[] text = { "Profile","Survey","Feedback","Light", "Temperature", "Air Quality"};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_forth);
		//LinearLayout temp=(LinearLayout)findViewById(R.id.root);
		//temp.setBackgroundResource(R.drawable.blue);
		
		/* No need for now */
		//LightText=(TextView) findViewById(R.id.light1);
		
		//LightText.setText("0");
		//mTemperatureTextView1 = (TextView) findViewById(R.id.tempf);
		//mTemperatureTextView = (TextView) findViewById(R.id.tempc);

		//mThermodo = ThermodoFactory.getThermodoInstance(this);
		//mThermodo.setThermodoListener(this);
		//mThermodo.start();
		
		SensorService = new Intent(getApplicationContext(), SensorService.class);
		pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
		wakeLock = null;
		wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, this.getClass().getCanonicalName());
		wakeLock.acquire();
		boolean bo = wakeLock.isHeld();
		
	    if (wakeLock == null || ! bo) {

	    	wakeLock.acquire();       

	    }
		
		Timer timer = new Timer();
		final Handler handler = new Handler(){
        	public void handleMessage(Message msg) {
	        	switch (msg.what) {
	        		case 0:
	        			//getApplicationContext().startService(SensorService);
	        			break;
	        		case 1:
	        			//stopService(SensorService);
	        			break;
		        	case 4:
		        		index = 0;
		        		break;
	        	}
        	}
        	
        };
        
        TimerTask task = new TimerTask() {
	        	public void run () {
	        		Message message = new Message();
	        		message.what = index;
	        		handler.sendMessage(message);
	        		index++;
	        	}
        };
        
        timer.schedule(task, 5000, 6000 * 10);
        
		
		//GridView grid=(GridView) findViewById(R.id.grid01);
		//LightButton=(GridView) findViewById(R.id.grid01);
		//LightButton.setOnClickListener();
		
		List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
		for (int i = 0; i < iconids.length; i++)
		{
			Map<String, Object> listItem = new HashMap<String, Object>();
			//listItem.put("iconbgs" , iconbgids[i]);
			listItem.put("image" , iconids[i]);
			//listItem.put("text", text[i]);

			listItems.add(listItem);
		}

		SimpleAdapter simpleAdapter = new SimpleAdapter(this
				, listItems 
				, R.layout.cell
				, new String[]{"image"}
		, new int[]{R.id.image});
		GridView grid = (GridView)findViewById(R.id.grid01);
		grid.setAdapter(simpleAdapter);
		grid.setNumColumns(GridView.AUTO_FIT);
	    
		final Intent intent = new Intent(this, MainActivity.class);
		
		SharedPreferences push_prefs = getApplicationContext().getSharedPreferences("PUSH_TYPE", Context.MODE_PRIVATE); // get the email saved in the preference
        SharedPreferences.Editor editor = push_prefs.edit();      
    	editor.putString("PUSH_TYPE", "4"); 
    	editor.commit(); 
		
    	SharedPreferences defalut_prefs = getApplicationContext().getSharedPreferences("DEFAULT_SURVEY", Context.MODE_PRIVATE); // get the email saved in the preference
        String currentDefaulSurvey = defalut_prefs.getString("DEFAULT_SURVEY", "");
		
		intent.removeExtra("survey_id");
		intent.putExtra("survey_id", currentDefaulSurvey);
		startActivity(intent);
		finish();
		
		grid.setOnItemClickListener(new OnItemClickListener()
		{

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int position,
					long arg3) {
				
				
				switch (position)
				{
				case 0: 
					SharedPreferences push_prefs = getApplicationContext().getSharedPreferences("PUSH_TYPE", Context.MODE_PRIVATE); // get the email saved in the preference
		            SharedPreferences.Editor editor = push_prefs.edit();      
		        	editor.putString("PUSH_TYPE", "4"); 
		        	editor.commit(); 
					
		        	SharedPreferences defalut_prefs = getApplicationContext().getSharedPreferences("DEFAULT_SURVEY", Context.MODE_PRIVATE); // get the email saved in the preference
		            String currentDefaulSurvey = defalut_prefs.getString("DEFAULT_SURVEY", "");
					
					intent.removeExtra("survey_id");
					intent.putExtra("survey_id", currentDefaulSurvey);
					startActivity(intent);
					break;
				case 1:
					String str1;
					str1="53";
					intent.removeExtra("survey_id");
					intent.putExtra("survey_id", str1);
					startActivity(intent);
					break;
				case 2:
					String str2;
					str2="60";
					intent.removeExtra("survey_id");
					intent.putExtra("survey_id", str2);
					startActivity(intent);
					break;
				case 3:
					String str3;
					str3 ="57";
					intent.removeExtra("survey_id");
					intent.putExtra("survey_id",str3);
					startActivity(intent);
					break;
				case 4: 
					String str4;
					str4 ="58";
					intent.removeExtra("survey_id");
					intent.putExtra("survey_id",str4);
					startActivity(intent);
					break;
				case 5:
					String str5;
					str5 ="59";
					intent.removeExtra("survey_id");
					intent.putExtra("survey_id",str5);
					startActivity(intent);
					break;
				}
			}

		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	/*

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		Intent intent = null;
		switch (item.getItemId()) {
		case R.id.register:
//			intent = new Intent(MainActivity.this, Register.class);
//			startActivity(intent);
			break;

		case R.id.changeemail:
			String webpage = "http://developer.android.com/index.html";

			intent = new Intent(Intent.ACTION_VIEW, Uri.parse(webpage));
			startActivity(intent);
			break;

		case R.id.unsubscribe:
			intent = new Intent();
			intent.setAction(Intent.ACTION_SEND);
			intent.putExtra(Intent.EXTRA_TEXT, "Hello from Hansel and Petal!");
			intent.setType("text/plain");
			startActivity(intent);
			break;

		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}*/


	@Override
	public void onAccuracyChanged(Sensor arg0, int arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		// TODO Auto-generated method stub
		
		float currentReading = event.values[0];
		lGet = currentReading;
		
		/* No need to update Now */
		// lightMeter.setProgress((int)currentReading);
		//LightText.setText(String.valueOf(lGet)+"LUX");
		//LightText.setTextSize(18);
	}

	@Override
	public void onErrorOccurred(int arg0) {
		// TODO Auto-generated method stub

	}
	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
		
	}

	@Override
	public void onStartedMeasuring() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onStoppedMeasuring() {
		// TODO Auto-generated method stub
		// 	Toast.makeText(this, "ThermodoSensor unpluged", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onTemperatureMeasured(float temperature) {
		// TODO Auto-generated method stub
		tGet=temperature;
		int t  = (int) tGet;
		int t2 = (int) (t * 1.8 + 32);
		
		/* No need to update now */
		//mTemperatureTextView.setText(String.valueOf(t2));
		//mTemperatureTextView.setTextSize(22);
		//mTemperatureTextView1.setText(String.valueOf(t));
		//mTemperatureTextView1.setTextSize(22);
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		//mThermodo.start();
		//sm = (SensorManager) getSystemService(SENSOR_SERVICE);
		//Light = sm.getDefaultSensor(Sensor.TYPE_LIGHT);
		//sm.registerListener(this, Light,
		//		SensorManager.SENSOR_DELAY_NORMAL);
		//light=String.valueOf(lGet);
		
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		//mThermodo.stop();
		
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		wakeLock.release();
	}

}

