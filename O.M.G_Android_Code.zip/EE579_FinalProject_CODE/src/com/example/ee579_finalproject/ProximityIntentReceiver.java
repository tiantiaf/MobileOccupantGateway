package com.example.ee579_finalproject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN)
public class ProximityIntentReceiver extends BroadcastReceiver {
    private static final int NOTIFICATION_ID = 1000;
    private static final String POINT_LOCATION_KEY = "POINT_LOCATION_KEY";
    public static final String POINT_LOCATION_SURVEY = "POINT_LOCATION_SURVEY";

	@Override
    public void onReceive(Context context, Intent intent) {
    	String keyEntering = LocationManager.KEY_PROXIMITY_ENTERING;
    	Boolean entering = intent.getBooleanExtra(keyEntering, false);
    	String locationForMain = intent.getStringExtra(POINT_LOCATION_KEY);
    	String surveyIDforMain = intent.getStringExtra(POINT_LOCATION_SURVEY);
    	String location = "Location: " + intent.getStringExtra(POINT_LOCATION_KEY);
    	if (entering) {
    		location += "; Status: entering";
    		Log.d(getClass().getSimpleName(), "entering");
    		
            // Notification feature
            Intent openMainIntent = new Intent(context, MainActivity.class);
            openMainIntent.putExtra(POINT_LOCATION_KEY, locationForMain); // Put the location on the intent
            openMainIntent.putExtra(POINT_LOCATION_SURVEY, surveyIDforMain); // Put the survey ID on the intent
        	PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, openMainIntent, PendingIntent.FLAG_ONE_SHOT);

            // Build notification
        	Bitmap myIcon = BitmapFactory.decodeResource(context.getResources(), R.drawable.ic_launcher);
            Notification myNotification = new Notification.Builder(context)
                .setContentTitle("New survey is available")
                //.setContentText("")
                .setContentIntent(pendingIntent)
                .setTicker("New survey is available")
                .setLargeIcon(myIcon)
                .setAutoCancel(true)
                .setSmallIcon(R.drawable.ic_notif).build();
                //.addAction(0, "Open", pendingIntent)
                //.addAction(0, "Ignore", pendingIntent)
                //.addAction(0, "Snooze", pendingIntent).build();
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            
            // Hide the notification after its selected
            myNotification.defaults |= Notification.DEFAULT_ALL;
            //myNotification.flags |= Notification.FLAG_AUTO_CANCEL;
            notificationManager.notify(0, myNotification);
    	}else{
    		location += "; Status: exiting";
    		Log.d(getClass().getSimpleName(), "exiting");
    	}
	
	
}
	
}
    //NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
    //Notification notification = createNotification();
    //notification.setLatestEventInfo(context, "Proximity Alert!", "You are near your point of interest.", pendingIntent);
    //notificationManager.notify(NOTIFICATION_ID, notification);

    /*
    private Notification createNotification() {
    	Notification notification = new Notification();
    	notification.icon = R.drawable.ic_launcher;
    	notification.when = System.currentTimeMillis();
    	notification.flags |= Notification.FLAG_AUTO_CANCEL;
    	notification.flags |= Notification.FLAG_SHOW_LIGHTS;
    	notification.defaults |= Notification.DEFAULT_VIBRATE;
    	notification.defaults |= Notification.DEFAULT_LIGHTS;
    	notification.ledARGB = Color.WHITE;
    	notification.ledOnMS = 1500;
    	notification.ledOffMS = 1500;
    	return notification;
    }
    */