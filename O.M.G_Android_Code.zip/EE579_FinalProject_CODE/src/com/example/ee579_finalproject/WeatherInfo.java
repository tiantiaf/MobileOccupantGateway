package com.example.ee579_finalproject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLEncoder;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.EditText;
import android.widget.Toast;

public class WeatherInfo {
	AlertDialog noconnBox;

	public WeatherInfo(){
		
	}
	
	/*
	// URL encode
	try{
		// check is Internet connection is available/not
		if(isInternetAvailable()){
			// TODO - check the URLencoding
			String finalInputEncoded = URLEncoder.encode(finalInput, "UTF-8");
	
			// execute AsynTask
			String requestTarget = "http://cs-server.usc.edu:35091/hw8/musicsearch?title=" + finalInputEncoded + "&type=" + typeSelected;
			new FetchFromServlet().execute(requestTarget);
		}else{
			noconnBox.show();
		}
	}catch(Exception e){
		e.printStackTrace();
	}
	*/
	
	public void findTemperatureForLocation(float latitude, float longitude){
		Log.d("WEATHERTAG", "CALLED!");

		try{
			// check is Internet connection is available/not
			//if(isInternetAvailable()){
				// TODO - check the URLencoding
				//String finalInputEncoded = URLEncoder.encode("Hello", "UTF-8");
		
				// execute AsynTask
				//String requestTarget = "http://cs-server.usc.edu:35091/hw8/musicsearch?title=" + "Hello" + "&type=" + "Songs";
				String requestTarget = "http://a5451774593.api.wxbug.net/getLiveCompactWeatherRSS.aspx?ACode=A5451774593&lat=34.158852&long=-118.31298&UnitType=1";
				new FetchFromServer().execute(requestTarget);
			//}else{
			//	noconnBox.show();
			//}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	/*
	public boolean isInternetAvailable() {
	    ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
	    NetworkInfo netInfo = cm.getActiveNetworkInfo();
	    if (netInfo != null && netInfo.isConnectedOrConnecting()) {
	        return true;
	    }else{
	    	return false;
	    }
	}
	*/
	
	public static DefaultHttpClient getThreadSafeClient() {
		DefaultHttpClient client = new DefaultHttpClient();
		ClientConnectionManager mgr = client.getConnectionManager();
		HttpParams params = client.getParams();
		client = new DefaultHttpClient(new ThreadSafeClientConnManager(params, mgr.getSchemeRegistry()), params);
	
		return client;
	}
	
	public Document getDomElement(String xml){
        Document doc = null;
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder db = dbf.newDocumentBuilder();
 
            InputSource is = new InputSource();
                is.setCharacterStream(new StringReader(xml));
                doc = db.parse(is); 
            } catch (Exception e) {
                Log.e("Error: ", e.getMessage());
                return null;
            }
        
            // return DOM
            return doc;
    }
	
	public String getValue(Element item, String str) {      
	    NodeList n = item.getElementsByTagName(str);        
	    return this.getElementValue(n.item(0));
	}
	 
	public final String getElementValue( Node elem ) {
		Node child;
		if( elem != null){
			if (elem.hasChildNodes()){
				for( child = elem.getFirstChild(); child != null; child = child.getNextSibling() ){
					if( child.getNodeType() == Node.TEXT_NODE  ){
						return child.getNodeValue();
					}
				}
			}
		}
		return "";
	} 
	
	private class FetchFromServer extends AsyncTask<String, Void, String> {
		//private ListView resultList = (ListView) findViewById(R.id.listViewResult);
		private ProgressDialog loadingDialog;
		
		protected void onPreExecute (){
        	//loadingDialog = ProgressDialog.show(MainActivity.this, "Loading the Discography Data", "Please Wait...");
       }
		
		@Override
		protected String doInBackground(String... inputString) {
			// request music from Server
			Log.d("WEATHERTAG", "FETCHING! - " + inputString[0]);
        	String resultString = new String();
        	
        	try{
        		// do the request
        		int TIMEOUT_MILLISEC = 10000;
        		HttpParams httpParams = new BasicHttpParams(); 
        		HttpConnectionParams.setConnectionTimeout(httpParams, TIMEOUT_MILLISEC); 
        		HttpConnectionParams.setSoTimeout(httpParams, TIMEOUT_MILLISEC);
        		HttpClient client = getThreadSafeClient();
        		HttpGet request = new HttpGet(inputString[0]);
	        	client.execute(request);

	        	// getting the response
	        	HttpResponse response = client.execute(request); 
	        	HttpEntity he = response.getEntity();
	        	resultString = EntityUtils.toString(he);
	    
	        	// getting DOM element
	        	Document doc = getDomElement(resultString); 
	        	 
	        	// parsing the XML response & get the temperature
	        	NodeList nodeList = doc.getElementsByTagName("aws:weather");
	        	Element element = (Element) nodeList.item(0);
        	    String temp = getValue(element, "aws:temp");
        	    resultString = temp;
    			Log.d("WEATHERTAG", "TEMP: " + temp);

	        	/*
	        	InputStream is = he.getContent();
	        	BufferedReader br = new BufferedReader(new InputStreamReader(is));
	        	resultString = br.readLine();
	        	response.getEntity().consumeContent();
	        	is.close();
	        	*/
        	}catch(Exception e){
    			Log.d("WEATHERTAG", "EXCEPTION!");
        		e.printStackTrace();
        	}
        	
			return resultString;
        	//return inputString[0];
		}

		/*
	  	protected void onProgressUpdate(Integer... progress) {
	    	setProgressPercent(progress[0]);
	  	}
		 */
		
		@Override
		protected void onPostExecute(String resultString) {
			Log.d("WEATHERTAG", "POST!");
			Log.d("WEATHERTAG", resultString);
		}
	}
}
