package com.example.ee579_finalproject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLEncoder;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class WebRequest extends Activity{	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.web_activity);
        
		try{
			String requestTarget = "http://building-occupant-gateway.com/api/get_full_survey.php?survey_id=1";
			new FetchFromServer().execute(requestTarget);
		}catch(Exception e){
			e.printStackTrace();
		}
    }
	
	public static DefaultHttpClient getThreadSafeClient() {
		DefaultHttpClient client = new DefaultHttpClient();
		ClientConnectionManager mgr = client.getConnectionManager();
		HttpParams params = client.getParams();
		client = new DefaultHttpClient(new ThreadSafeClientConnManager(params, mgr.getSchemeRegistry()), params);
	
		return client;
	}
	
	private class FetchFromServer extends AsyncTask<String, Void, String> {
		private ProgressDialog loadingDialog;

		protected void onPreExecute (){
        	loadingDialog = ProgressDialog.show(WebRequest.this, "Loading the Survey Data", "Please Wait...");
		}
		
		@Override
		protected String doInBackground(String... inputString) {
			// request music from Servlet
        	String resultString = new String();        		
        	try{
        		int TIMEOUT_MILLISEC = 10000;
        		HttpParams httpParams = new BasicHttpParams(); 
        		HttpConnectionParams.setConnectionTimeout(httpParams, TIMEOUT_MILLISEC); 
        		HttpConnectionParams.setSoTimeout(httpParams, TIMEOUT_MILLISEC);
        		HttpClient client = getThreadSafeClient();
        		HttpGet request = new HttpGet(inputString[0]);
	        	client.execute(request);
	        		
	        	HttpResponse response = client.execute(request); 
	        	HttpEntity he = response.getEntity();
	        	InputStream is = he.getContent();
	        	BufferedReader br = new BufferedReader(new InputStreamReader(is));
	        	resultString = br.readLine();
	        	response.getEntity().consumeContent();
	        	is.close();
        	}catch(Exception e){
        		e.printStackTrace();
        	}
        	
        	return resultString;
		}

		/*
		protected void onProgressUpdate(Integer... progress) {
			setProgressPercent(progress[0]);
		}
		*/
		
		@Override
		protected void onPostExecute(String resultString) {
    		loadingDialog.dismiss();
    		
    		// temporary show the result
    		TextView tempTextView = (TextView) findViewById(R.id.webTextView);
    		
        	// check for no result & exception
        	JSONArray myJsonArray = null;
        	try {
        		JSONObject myJson = new JSONObject(resultString);
				JSONObject JsonMain = myJson.getJSONObject("questions");
				myJsonArray = JsonMain.getJSONArray("data");
				        		
	    		// Launch result activity if there is match found
				if(myJsonArray.length() > 0){
					//Intent intent = new Intent(WebRequest.this, MainActivity.class);
					
					String tempStr = "";
					JSONObject result = myJsonArray.getJSONObject(0);
					JSONObject innerPart1 = result.getJSONObject("question");
					tempStr = innerPart1.getString("question_text");
		    		tempTextView.setText(tempStr);
					
					/*
					JSONObject result = myJsonArray.getJSONObject(0);
					if(result.getString("cover") != null){
						Intent intent = new Intent(MainActivity.this, ResultActivity.class);
		    			intent.putExtra("ResultString", resultString);
		    			//String requestType = (String) spinner.getSelectedItem();
		    			//intent.putExtra("RequestType", requestType);
		    			intent.putExtra("RequestType", typeSpinner);
		    			startActivity(intent);
					}else{
		    			// TODO - print message - exception happens on the server
					}
					*/
	    		}else{
	    			// TODO - print message - no result found
	    		}
			} catch (JSONException e) {
    			// TODO - print message - exception happens on the server
				e.printStackTrace();
			}
		}
	}
}
