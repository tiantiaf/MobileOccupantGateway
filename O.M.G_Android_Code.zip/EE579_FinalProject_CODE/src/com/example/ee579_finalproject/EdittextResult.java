package com.example.ee579_finalproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class EdittextResult {
	public EditText commentEdit;
	
	public EdittextResult(){
		
	}
	
	public EditText addEdittextComponent(final Context context, LinearLayout currentLayout, String componentQuestion){        
    	LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View edittextView = inflater.inflate(R.layout.edittext_layout, null);
		
        TextView editTextview = (TextView) edittextView.findViewById(R.id.edittextQuestion);
        editTextview.setText(componentQuestion);
        
        commentEdit = (EditText) edittextView.findViewById(R.id.edittextSpace);
        commentEdit.clearFocus();
        //this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        currentLayout.addView(edittextView);
        
        return commentEdit;
	}
}
