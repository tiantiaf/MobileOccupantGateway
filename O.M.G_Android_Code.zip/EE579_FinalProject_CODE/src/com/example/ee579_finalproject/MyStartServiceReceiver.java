package com.example.ee579_finalproject;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class MyStartServiceReceiver extends BroadcastReceiver {
	@Override
	public void onReceive(Context context, Intent intent) {
		Intent service = new Intent(context, ProximityService.class);
		service.putExtra("STATUS", "VALID-ALARM");
		context.startService(service);
	}
} 