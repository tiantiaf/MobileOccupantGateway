package com.example.ee579_finalproject;

import java.util.ArrayList;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.CompoundButton.OnCheckedChangeListener;

public class RelatedCheckboxResult {
	public CheckBox[] componentCheckBox;
	
	public RelatedCheckboxResult(){
		
	}
	
	public void addCheckboxComponent(final Context context, View encloseView, String componentQuestion, Object[] resultPointer){  
    	LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    	View checkboxEncloseView = inflater.inflate(R.layout.enclose_layout, null);
        View questionView = inflater.inflate(R.layout.checkboxquestion_layout, null);
        
        // get the enclosed component - FOR INSERTION
        LinearLayout checkboxInnerLayout = (LinearLayout) checkboxEncloseView.findViewById(R.id.encloseLayout);
		LinearLayout testingAdd = (LinearLayout) encloseView.findViewById(R.id.encloseLayout);
		
        // do the question parsing (semicolon delimited)
        String[] questionParsed = componentQuestion.split(";");
        
        // add the check box question
        TextView questionTextView = (TextView) questionView.findViewById(R.id.checkboxQuestion);
        questionTextView.setText(questionParsed[0]);
        
        // check for previous view
		int count = testingAdd.getChildCount();
		for(int walk = 1; walk < count; walk++){
			testingAdd.removeViewAt(walk);
		}

  		//for(int walk = 1; walk < resultPointer.size(); walk++){
		//	resultPointer.remove(walk);
		//}
        
		// add the component to the inner view
		checkboxInnerLayout.addView(questionView);
        //currentLayout.addView(questionView);
        
        // add the check box components
        int checkBoxCount = questionParsed.length - 1;
        componentCheckBox = new CheckBox[checkBoxCount];
        for(int walk = 0; walk < componentCheckBox.length; walk++){
        	componentCheckBox[walk] = addCheckBoxComponent(context, checkboxInnerLayout, questionParsed[walk + 1]);
        	resultPointer[walk + 1] = componentCheckBox[walk];
        }
       // if(componentCheckBox[0].isChecked()){
        if(componentCheckBox.length==4)
        {
          componentCheckBox[0].setOnCheckedChangeListener(new OnCheckedChangeListener() {

  			@Override
  			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
  				// TODO Auto-generated method stub

                  if (componentCheckBox[0].isChecked() == true) 
                  {
                	  componentCheckBox[1].setChecked(false);
                	  componentCheckBox[2].setChecked(false);
                	  componentCheckBox[3].setChecked(false); 
              
              }
                  
  			}
  			
          });
          componentCheckBox[1].setOnCheckedChangeListener(new OnCheckedChangeListener() {

  			@Override
  			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
  				// TODO Auto-generated method stub

                  if (componentCheckBox[1].isChecked() == true) 
                  {
                	  componentCheckBox[0].setChecked(false);
                	  componentCheckBox[2].setChecked(false);
                	  componentCheckBox[3].setChecked(false); 
                  }
                  
  			}
  			
          });
          componentCheckBox[2].setOnCheckedChangeListener(new OnCheckedChangeListener() {

  			@Override
  			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
  				// TODO Auto-generated method stub

                  if (componentCheckBox[2].isChecked() == true) 
                  {
                	  componentCheckBox[1].setChecked(false);
                	  componentCheckBox[0].setChecked(false);
                	  componentCheckBox[3].setChecked(false); 
              }    
  			}
  			
          });
          componentCheckBox[3].setOnCheckedChangeListener(new OnCheckedChangeListener() {

  			@Override
  			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
  				// TODO Auto-generated method stub

                  if (componentCheckBox[3].isChecked() == true) 
                  {
                	  componentCheckBox[1].setChecked(false);
                	  componentCheckBox[2].setChecked(false);
                	  componentCheckBox[0].setChecked(false); 
                  }
                  
  			}
  			
          });
        }
        else  if(componentCheckBox.length==3)
        {
          componentCheckBox[0].setOnCheckedChangeListener(new OnCheckedChangeListener() {

  			@Override
  			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
  				// TODO Auto-generated method stub

                  if (componentCheckBox[0].isChecked() == true) 
                  {
                	  componentCheckBox[1].setChecked(false);
                	  componentCheckBox[2].setChecked(false);
                	
                  }
                  
  			}
  			
          });
          componentCheckBox[1].setOnCheckedChangeListener(new OnCheckedChangeListener() {

  			@Override
  			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
  				// TODO Auto-generated method stub

                  if (componentCheckBox[1].isChecked() == true) 
                  {
                	  componentCheckBox[0].setChecked(false);
                	  componentCheckBox[2].setChecked(false);
                	  
                  }
                  
  			}
  			
          });
          componentCheckBox[2].setOnCheckedChangeListener(new OnCheckedChangeListener() {

  			@Override
  			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
  				// TODO Auto-generated method stub

                  if (componentCheckBox[2].isChecked() == true) 
                  {
                	  componentCheckBox[1].setChecked(false);
                	  componentCheckBox[0].setChecked(false);
                	
                } 
                  
  			}
  			
          });
         
        }
        else
        {
            componentCheckBox[0].setOnCheckedChangeListener(new OnCheckedChangeListener() {

    			@Override
    			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
    				// TODO Auto-generated method stub

                    if (componentCheckBox[0].isChecked() == true) 
                    {
                    	componentCheckBox[1].setChecked(false);
                  	 
                } 
                    
    			}
    			
            });
            componentCheckBox[1].setOnCheckedChangeListener(new OnCheckedChangeListener() {

    			@Override
    			public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
    				// TODO Auto-generated method stub

                    if (componentCheckBox[1].isChecked() == true) 
                    {
                    	componentCheckBox[0].setChecked(false);
                  	  
                } 
                    
    			}
    			
            });
        }
    
        
		//Log.d("SIZE", componentCheckBox.length + "");
        
		// add the component to the main view
        testingAdd.addView(checkboxInnerLayout);
       // }
	}
	
    private CheckBox addCheckBoxComponent(Context context, LinearLayout currentLayout, String componentQuestion){
    	LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View componentView = inflater.inflate(R.layout.checkbox_layout, null);
		
        CheckBox componentCheckBox = (CheckBox) componentView.findViewById(R.id.checkboxLayout);
        componentCheckBox.setText(componentQuestion);
        currentLayout.addView(componentView);
		return componentCheckBox;
    }
}
