package com.example.ee579_finalproject;


import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.widget.Toast;

public class NotificationIntentReceiver extends BroadcastReceiver{

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		//Toast.makeText(context, "broad", Toast.LENGTH_LONG).show();
		 if(Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())){
			 Intent intent1=new Intent(context, Alarmreceiver.class);
			 intent1.setAction("arui.alarm.action");
			 PendingIntent sender = PendingIntent.getBroadcast(context, 0, intent1, 0);
			 long firsttime  = SystemClock.elapsedRealtime();
			 AlarmManager am = (AlarmManager) context.getSystemService(context.ALARM_SERVICE);
			 am.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, firsttime, 10*1000, sender);
			 //Toast.makeText(context, "first Broad", Toast.LENGTH_LONG).show();
		 }
	}

}
