package com.example.ee579_finalproject;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class SnoozeReceiver extends BroadcastReceiver{

	@SuppressLint("NewApi")
	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		if(intent.getAction().equals("snooze.alarm.action")){
			String survey_id = intent.getStringExtra("survey_id");
			if (survey_id.isEmpty()) {
				survey_id = "63";
			}
			Intent i = new Intent();
			i.setClass(context, Snooze.class);
			i.putExtra("survey_id", survey_id);
			context.startService(i);
			
		}
	}

}
