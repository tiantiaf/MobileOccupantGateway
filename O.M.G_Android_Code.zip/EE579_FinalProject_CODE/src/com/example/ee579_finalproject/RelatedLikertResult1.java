package com.example.ee579_finalproject;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class RelatedLikertResult1{
	public SeekBar likertSeekbar;
	public CheckBox likertCheckBox;
	
	public RelatedLikertResult1(){
		
	}
	
	public void addLikertComponent(final Context context, View encloseView, String componentQuestion, Object[] resultComponent){
    	LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View componentView = inflater.inflate(R.layout.likert_layout, null);
        
        // get the enclosed component - FOR INSERTION
		LinearLayout testingAdd = (LinearLayout) encloseView.findViewById(R.id.encloseLayout);
        
        // get the imageView
        final ImageView componentImage = (ImageView) componentView.findViewById(R.id.likertprogressimage);
        TextView componentTitle = (TextView) componentView.findViewById(R.id.likerttextview);
        componentTitle.setText(componentQuestion);
        
        // get the seekBar
        final SeekBar componentSeekFunc = (SeekBar) componentView.findViewById(R.id.likertseekbar);
        componentSeekFunc.setProgress(3);
        componentSeekFunc.setOnSeekBarChangeListener(new OnSeekBarChangeListener() 
        {
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				
			}
			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				if(progress == 0){
					componentImage.setImageResource(R.drawable.mood1);
				}else if(progress == 1){
					componentImage.setImageResource(R.drawable.mood2);
				}else if(progress == 2){
					componentImage.setImageResource(R.drawable.mood3);
				}else if(progress == 3){
					componentImage.setImageResource(R.drawable.mood4);
				}else if(progress == 4){
					componentImage.setImageResource(R.drawable.mood5);
				}else if(progress == 5){
					componentImage.setImageResource(R.drawable.mood6);
				}else if(progress == 6){
					componentImage.setImageResource(R.drawable.mood7);
				}
			}
		});
        likertSeekbar = componentSeekFunc;
        resultComponent[5] = componentSeekFunc;
        
        // get the checkBox
        CheckBox componentCheckFunc = (CheckBox) componentView.findViewById(R.id.likertna);
        componentCheckFunc.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if(isChecked){
					componentSeekFunc.setEnabled(false);
					componentImage.setImageResource(R.drawable.na_mood);
				}else{
					componentSeekFunc.setEnabled(true);
					componentSeekFunc.setProgress(3);
					componentImage.setImageResource(R.drawable.mood4);
				}
			}
		});
        likertCheckBox = componentCheckFunc;
        
        // check for previous view
		int count = testingAdd.getChildCount();
		for(int walk = 1; walk < count; walk++){
			testingAdd.removeViewAt(walk);
		}
        
        // add the component to the view
		testingAdd.addView(componentView);
    }
}
