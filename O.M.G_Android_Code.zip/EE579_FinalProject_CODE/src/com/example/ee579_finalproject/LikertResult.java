package com.example.ee579_finalproject;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class LikertResult{
	public SeekBar likertSeekbar;
	public CheckBox likertCheckBox;
	
	public LikertResult(){
		
	}
	
	public Object[] addLikertComponent(final Context context, final View encloseView, final LinearLayout currentLayout, String componentQuestion, final String relatedType, final String relatedText){
		int resultLength = 0;
		if(!relatedText.equals("")){
			if(relatedType.equals(MainActivity.CHECKBOX_TYPE)||relatedType.equals(MainActivity.CHECKBOX_TYPE1)){
				String[] questionParsed = relatedText.split(";");
				resultLength = questionParsed.length;
			}else if(relatedType.equals(MainActivity.LIKERT_TYPE) || relatedType.equals(MainActivity.EDITTEXT_TYPE)){
				//String[] questionParsed = relatedText.split(";");
				resultLength = 2;
			}
		}else{
			resultLength = 1;
		}
		Log.d("LENGTH", resultLength + "");
		final Object[] resultPointer = new Object[resultLength];
		
    	LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View componentView = inflater.inflate(R.layout.likert_layout, null);
        
        // get the encloseLayout
        final LinearLayout encloseLayout = (LinearLayout) encloseView.findViewById(R.id.encloseLayout);
        
        // get the imageView
        final ImageView componentImage = (ImageView) componentView.findViewById(R.id.likertprogressimage);
        TextView componentTitle = (TextView) componentView.findViewById(R.id.likerttextview);
        componentTitle.setText(componentQuestion);
        
        // get the seekBar
        final SeekBar componentSeekFunc = (SeekBar) componentView.findViewById(R.id.likertseekbar);
        componentSeekFunc.setProgress(3);
        componentSeekFunc.setOnSeekBarChangeListener(new OnSeekBarChangeListener() 
        {
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				
			}
			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				if(progress == 0){
					componentImage.setImageResource(R.drawable.mood1);
				}else if(progress == 1){
					componentImage.setImageResource(R.drawable.mood2);
				}else if(progress == 2){
					componentImage.setImageResource(R.drawable.mood3);
				}else if(progress == 3){
					componentImage.setImageResource(R.drawable.mood4);
				}else if(progress == 4){
					componentImage.setImageResource(R.drawable.mood5);
				}else if(progress == 5){
					componentImage.setImageResource(R.drawable.mood6);
				}else if(progress == 6){
					componentImage.setImageResource(R.drawable.mood7);
				}
				
				// add related question
				if(relatedType.equals("") && relatedText.equals("")){
					// NO related question asked - not adding anything else to the response
				}else{
					addRelatedComponent(context, progress, encloseView, currentLayout, relatedType, relatedText, resultPointer);
				}
			}
		});
        likertSeekbar = componentSeekFunc;
        resultPointer[0] = componentSeekFunc;
        
        // get the checkBox
        CheckBox componentCheckFunc = (CheckBox) componentView.findViewById(R.id.likertna);
        componentCheckFunc.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if(isChecked){
					componentSeekFunc.setEnabled(false);
					componentImage.setImageResource(R.drawable.na_mood);
		        	
					// remove the related question
		    		LinearLayout testingAdd = (LinearLayout) encloseView.findViewById(R.id.encloseLayout);
		    		int count = testingAdd.getChildCount();
		    		for(int walk = 1; walk < count; walk++){
		    			testingAdd.removeViewAt(walk);
		    		}
				}else{
					componentSeekFunc.setEnabled(true);
					componentSeekFunc.setProgress(2);
					componentImage.setImageResource(R.drawable.mood4);
				}
			}
		});
        likertCheckBox = componentCheckFunc;
        
        // add the component to the view
        encloseLayout.addView(componentView);
        currentLayout.addView(encloseView);
        
        return resultPointer;
    }
	
    public void addRelatedComponent(Context context, int progress, View encloseView, LinearLayout currentLayout, String relatedType, String relatedText, Object[] resultPointer){
    	// BELOW is the code to add title component as Related question
    	//LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        //View titleView = inflater.inflate(R.layout.title_layout, null);
        //TextView titleTextView = (TextView) titleView.findViewById(R.id.titletext);
		//LinearLayout testingAdd = (LinearLayout) encloseView.findViewById(R.id.encloseLayout);
		
		// TODO - adding likert & check box as related question
		//CheckboxResult myCheckbox = new CheckboxResult();
		//myCheckbox.addCheckboxComponent(context, currentLayout, "Hello; 1;2;3");
		//RelatedLikertResult myRelatedLikert = new RelatedLikertResult();
		//myRelatedLikert.addLikertComponent(context, encloseView, "Testing Related");
		
		/*
		int count = testingAdd.getChildCount();
		for(int walk = 1; walk < count; walk++){
			testingAdd.removeViewAt(walk);
		}
		*/
        if(progress < 3){
        	//titleTextView.setText("Related Question to Bad Response");
    		//testingAdd.addView(titleView);
        	if(relatedType.equals(MainActivity.CHECKBOX_TYPE)){
        		RelatedCheckboxResult myRelatedCheckbox = new RelatedCheckboxResult();
        		myRelatedCheckbox.addCheckboxComponent(context, encloseView, relatedText, resultPointer);
        	}else if(relatedType.equals(MainActivity.CHECKBOX_TYPE1)){
            		RelatedCheckboxResult1 myRelatedCheckbox1 = new RelatedCheckboxResult1();
            		myRelatedCheckbox1.addCheckboxComponent(context, encloseView, relatedText, resultPointer);
        	}else if(relatedType.equals(MainActivity.LIKERT_TYPE)){
        		RelatedLikertResult myRelatedLikert = new RelatedLikertResult();
        		myRelatedLikert.addLikertComponent(context, encloseView, relatedText, resultPointer);
        	}else if(relatedType.equals(MainActivity.EDITTEXT_TYPE)){
        		RelatedEdittextResult myRelatedEdittext = new RelatedEdittextResult();
        		myRelatedEdittext.addEdittextComponent(context, encloseView, relatedText, resultPointer);
        	}
    		//RelatedLikertResult myRelatedLikert = new RelatedLikertResult();
    		//myRelatedLikert.addLikertComponent(context, encloseView, "Bad");
        }else{
        	// remove the related question
    		LinearLayout testingAdd = (LinearLayout) encloseView.findViewById(R.id.encloseLayout);
    		int count = testingAdd.getChildCount();
    		for(int walk = 1; walk < count; walk++){
    			testingAdd.removeViewAt(walk);
    		}
    		
    		//Log.d("SIZE", resultPointer.size() + "");
    		//for(int walk = 1; walk < resultPointer.size(); walk++){
    		//	resultPointer.remove(walk);
    		//}
        }
        /*
        else{
        	//titleTextView.setText("Related Question to Good Response");
    		//testingAdd.addView(titleView);
        	if(relatedType.equals(MainActivity.CHECKBOX_TYPE)){
        		RelatedCheckboxResult myRelatedCheckbox = new RelatedCheckboxResult();
        		myRelatedCheckbox.addCheckboxComponent(context, encloseView, relatedText);
        	}else if(relatedType.equals(MainActivity.LIKERT_TYPE)){
        		RelatedLikertResult myRelatedLikert = new RelatedLikertResult();
        		myRelatedLikert.addLikertComponent(context, encloseView, relatedText);
        	}
    		//RelatedLikertResult myRelatedLikert = new RelatedLikertResult();
    		//myRelatedLikert.addLikertComponent(context, encloseView, "Good");
        }
        */
    }
}
