package com.example.ee579_finalproject;

public class Point {
private Double x;
private int y;
	public Point(Double x2, int y){
		this.x=x2;
		this.y=y;
	}
	public Double getX(){
		return x;
	}
	public int getY(){
		return y;
	}
}
