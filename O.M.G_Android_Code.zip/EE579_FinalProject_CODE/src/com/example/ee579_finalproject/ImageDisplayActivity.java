package com.example.ee579_finalproject;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.Menu;
import android.widget.ImageView;
import android.widget.TextView;

public class ImageDisplayActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_image_display);
		
		Bundle extras = getIntent().getExtras();
		if (extras == null) {
		    return;
		}
		
		// Get data via the key
		//Bitmap photo = (Bitmap) data.getExtras().get("data"); 
		Bitmap photo = (Bitmap) extras.get("data");
		if (photo != null) {
			// Do something with the data
			ImageView displayImageView = (ImageView) findViewById(R.id.testImageView);
			displayImageView.setImageBitmap(photo);
		} 
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.image_display, menu);
		return true;
	}

}
