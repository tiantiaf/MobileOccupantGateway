/** Automatically generated file. DO NOT MODIFY */
package com.example.ee579_finalproject;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}